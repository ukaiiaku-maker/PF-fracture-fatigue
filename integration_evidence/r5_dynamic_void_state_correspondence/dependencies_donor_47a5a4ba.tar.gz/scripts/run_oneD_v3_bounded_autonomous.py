#!/usr/bin/env python3
"""Autonomous fixed-load OneD pilot using the bounded measured closure."""
from __future__ import annotations

from dataclasses import asdict, replace
import json
import math
import os
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from reduced_fracture_v2 import CanonicalParameters
from reduced_fracture_v2.adapters import PFProcessZoneStateAdapter
from reduced_fracture_v2.mechanics import PFMechanicsProvider
from reduced_fracture_v2.native_closure import PFNativeStateClosure
from reduced_fracture_v2.state import ReducedState
from reduced_fracture_v3.aligned_subgrid_closure import load_bounded_subgrid_closure
from reduced_fracture_v3.fracture_adapter import initialize_v2_fracture_owner
from reduced_fracture_v3.physical import (
    LineNormalization, PhysicalIncrement, ReducedSiteState, SitePhase,
    advance_physical_time, initialize_executable_state,
)
from reduced_fracture_v3.production_growth_adapter import HybridEmissionSourceState
from reduced_fracture_v3.state import no_void_upgrade
from run_oneD_v3_physical_voiding_demo import rows_from_declared
from scripts.run_oneD_v2_native_source_shadow import (
    OUT as V2_MAPS, pf_engine, rows as production_rows,
)


TWO_D = Path("/Volumes/Data/Data/Nanopillar_calculation/voiding/recovered-pr63")
DATA = TWO_D/"artifacts/aligned_subgrid_closure_v1/observations.json"
JOB = TWO_D/"runs/managed_natural_void_v1_20260919/output"
PF_REPO = Path(
    "/Volumes/Data/Data/Nanopillar_calculation/"
    "PF-fracture-fatigue_v10_2_21_persistent_sites_top1")
OUT = ROOT/"analysis_outputs/oneD_v3_bounded_autonomous/result.json"


def _fracture_owner(opening_m: float):
    row = next(item for item in production_rows(PF_REPO)
               if item["candidate_id"] == "v913_zeroD_sobol_0202500")
    closure = PFNativeStateClosure(
        PFMechanicsProvider.from_csv(
            V2_MAPS/"oneD_v2_pf_mechanics_map.csv", "pinned"),
        pf_engine(PF_REPO, row, exact=False), PFProcessZoneStateAdapter(),
        CanonicalParameters.from_mapping(row),
    )
    return initialize_v2_fracture_owner(closure, opening_m=opening_m)


def _source_owners(payload):
    observation = next(row for row in payload["rows"]
                       if row["checkpoint"] == "restart_002200ms.json")
    sources = observation["growth"][0]["source_states"]
    return tuple(HybridEmissionSourceState(
        source_id=item["source_id"], orientation_rad=item["orientation_rad"],
        random_measure_seed=item["random_measure_seed"],
    ) for item in sources)


def _initial_state(closure, payload, *, void_enabled: bool):
    start = next(row for row in payload["rows"]
                 if row["checkpoint"] == "restart_001900ms.json")
    declared = json.loads((JOB/"declared_inputs.json").read_text())
    rows = rows_from_declared(declared)
    edges = tuple(np.linspace(0.0, 1.0e-3, 65))
    normalization = LineNormalization(
        edges, (1.0e-3,)*64, thickness_m=1.0,
        exterior_surface_multiplier=(2.0,)*64)
    threshold = (2.478977171068976, 4.3371792343359115, 5.49103389229482)
    by_site = {item["site_id"]: item for item in start["direct_opportunity"]}
    site = ReducedSiteState(
        site_id="site-1", x_m=6.0e-4, support_half_width_m=5.0e-5,
        vacancy_thresholds=(1.0e100, 2.0e100), direct_thresholds=threshold,
        phase=(SitePhase.AVAILABLE if void_enabled else SitePhase.HEALED),
        direct_action=(5.137045367960206 if void_enabled else 0.0),
        direct_hits=(2 if void_enabled else 0),
        direct_free_volume_area_m2=(2*rows.direct_hit_area_m2 if void_enabled else 0.0),
        stabilization_threshold=0.47222864329483355,
        healing_threshold=0.0722889158143623,
        emission_sources=_source_owners(payload),
        emission_source_availability=(1.0,)*rows.emission_source_count,
    )
    site2_threshold = (4.110064149241676, 4.146298237212335, 5.539499232509707)
    site2 = ReducedSiteState(
        site_id="site-2", x_m=7.5e-4, support_half_width_m=5.0e-5,
        vacancy_thresholds=(1.0e100, 2.0e100), direct_thresholds=site2_threshold,
        phase=(SitePhase.AVAILABLE if void_enabled else SitePhase.HEALED),
        direct_action=(4.110064149241676 if void_enabled else 0.0),
        direct_hits=(1 if void_enabled else 0),
        direct_free_volume_area_m2=(rows.direct_hit_area_m2 if void_enabled else 0.0),
        stabilization_threshold=3.843065409702464,
        healing_threshold=1.8511525104397153,
    )
    start_time = float(start["accepted_time_s"])
    core = no_void_upgrade(ReducedState(time_s=start_time))
    state = initialize_executable_state(
        core, normalization, rows, sites=(site, site2),
        initial_vacancy_fraction=float(start["transport"]["vacancy_fraction_min"]),
        initial_forest_density_m2=float(by_site["site-1"][
            "rho_forest_support_average_m2"]),
        temperature_K=1200.0,
        fracture_adapter_state=_fracture_owner(closure.opening_m),
        fracture_front_origin_m=float(start["tip"]["x_tip_m"]),
    )
    initial_history = float(start["plastic_history"][
        "maximum_equivalent_plastic_strain"])
    fields = replace(
        state.fields,
        equivalent_plastic_strain=(initial_history,)+(0.0,)*63,
    )
    return replace(state, fields=fields, physical_time_s=start_time,
                   core=replace(state.core, fracture_state=replace(
                       state.core.fracture_state, time_s=start_time)))


def main() -> None:
    wall_start = time.perf_counter()
    native_backend_calls = 0
    original_native_advance = PFNativeStateClosure.advance_interval

    def counted_native_advance(self, *args, **kwargs):
        nonlocal native_backend_calls
        native_backend_calls += 1
        return original_native_advance(self, *args, **kwargs)

    PFNativeStateClosure.advance_interval = counted_native_advance
    closure, payload = load_bounded_subgrid_closure(DATA)
    start_time = 1.89999
    stop_time = 2.59999
    history_rate = ((closure.history_domain[1]-closure.history_domain[0])
                    /(stop_time-start_time))
    fracture_G_anchor = float(closure.evaluate(
        opening_m=closure.opening_m,
        maximum_equivalent_plastic_strain=closure.history_domain[0],
        site_id=None, radius_m=None,
    ).G_kinetic)

    def mechanics(state, signed_load, duration_s):
        history = max(state.fields.equivalent_plastic_strain)
        history = min(max(history, closure.history_domain[0]), closure.history_domain[1])
        active = next((site for site in state.sites if site.radius_m is not None), None)
        response = closure.evaluate(
            opening_m=closure.opening_m,
            maximum_equivalent_plastic_strain=history,
            site_id=(None if active is None else active.site_id),
            radius_m=(None if active is None else active.radius_m),
        )
        n = len(state.normalization.cell_lengths_m)
        centers = state.normalization.centers_m
        dep = np.zeros(n)
        dep[0] = history_rate*duration_s
        loop_rho = np.asarray(
            state.fields.loop_deposited_forest_density_m2
            or np.zeros(len(state.fields.forest_density_m2)), float)
        rho = np.asarray(state.fields.forest_density_m2, float)-loop_rho
        mobile = np.asarray(state.fields.mobile_density_m2, float).copy()
        means = np.zeros(n); opening = np.zeros(n)
        opportunities = {}; support_means = {}; tensor_map = {}; zz_map = {}
        for site in state.sites:
            controls = closure.site_direct_controls(
                site_id=site.site_id, opening_m=closure.opening_m,
                maximum_equivalent_plastic_strain=history)
            xx, yy, xy, zz, mean = closure.source_tensor_xy_sigma_zz(
                site_id=site.site_id, opening_m=closure.opening_m,
                maximum_equivalent_plastic_strain=history)
            support = np.abs(centers-site.x_m) <= site.support_half_width_m
            dep[support] = controls["accepted_epdot_eq_support_average_s"]*duration_s
            rho[support] = controls["rho_forest_support_average_m2"]
            mobile[support] = controls["rho_mobile_support_average_m2"]
            means[support] = mean; opening[support] = yy
            opportunities[site.site_id] = controls[
                "support_integrated_interaction_rate_s"]
            support_means[site.site_id] = controls["mean_stress_support_Pa"]
            tensors = tuple((((xx, xy), (xy, yy)))
                            for _ in site.emission_sources)
            tensor_map[site.site_id] = tensors
            zz_map[site.site_id] = (zz,)*len(tensors)
        return PhysicalIncrement(
            duration_s=duration_s, signed_load=signed_load,
            equivalent_plastic_strain_increment=tuple(dep),
            forest_density_m2=tuple(rho), mobile_density_m2=tuple(mobile),
            mean_stress_Pa=tuple(means), opening_stress_Pa=tuple(opening),
            mechanics_response=response, fracture_opening_m=closure.opening_m,
            fracture_native_K_scale=math.sqrt(
                max(float(response.G_kinetic), 0.0)/fracture_G_anchor),
            fracture_mechanics_binding_identity=(
                "BOUNDED_ALIGNED_HISTORY:"+closure.dataset_sha256),
            prescribed_direct_opportunity_rate_s_by_site=opportunities,
            prescribed_direct_mean_stress_Pa_by_site=support_means,
            cavity_source_tensors_xy_Pa_by_site=tensor_map,
            cavity_source_sigma_zz_Pa_by_site=zz_map,
        )

    def hold_mechanics(state, signed_load, duration_s):
        observed = mechanics(state, signed_load, duration_s)
        n = len(state.normalization.cell_lengths_m)
        loop_rho = np.asarray(
            state.fields.loop_deposited_forest_density_m2 or np.zeros(n), float)
        return replace(
            observed,
            equivalent_plastic_strain_increment=(0.0,)*n,
            forest_density_m2=tuple(
                np.asarray(state.fields.forest_density_m2)-loop_rho),
            prescribed_direct_opportunity_rate_s_by_site={
                site.site_id: 0.0 for site in state.sites},
        )

    def simulate(enabled: bool, cadence_s: float, hold_duration_s: float = 0.0):
        state = _initial_state(closure, payload, void_enabled=enabled)
        initial_exposure = max(state.fields.equivalent_plastic_strain)
        trace = []
        terminal_time = stop_time+hold_duration_s
        while state.physical_time_s < terminal_time-1.0e-12:
            # Reporting cadence only; internal events retain the remaining
            # physical exposure and rebuild mechanics without resetting it.
            in_hold = state.physical_time_s >= stop_time-1.0e-12
            dt = min(cadence_s, terminal_time-state.physical_time_s,
                     (terminal_time if in_hold else stop_time)-state.physical_time_s)
            provider = hold_mechanics if in_hold else mechanics
            state = advance_physical_time(
                state, provider(state, 1.0, dt), mechanics_refresh=provider)
            trace.append({
                "time_s": state.physical_time_s,
                "phase": state.sites[0].phase.value,
                "radius_m": state.sites[0].radius_m,
                "direct_action": state.sites[0].direct_action,
                "direct_hits": state.sites[0].direct_hits,
                "loop_count": state.sites[0].emitted_loop_count,
                "fracture_extension_m": state.core.fracture_state.crack_extension_m,
                "fracture_event_count": state.core.fracture_state.event_count,
                "site2_direct_action": state.sites[1].direct_action,
                "site2_direct_hits": state.sites[1].direct_hits,
                "site2_phase": state.sites[1].phase.value,
                "site2_radius_m": state.sites[1].radius_m,
                "site2_loop_count": state.sites[1].emitted_loop_count,
                "growth_representation": state.sites[0].growth_representation,
            })
        first_passage = {
            site_id: next((float(event["physical_time_s"])
                           for event in state.event_history
                           if event["event"] == "DIRECT_BIRTH_HIT"
                           and event["site_id"] == site_id), None)
            for site_id in ("site-1", "site-2")
        }
        return {
            "terminal": trace[-1], "events": list(state.event_history),
            "fracture_adapter_intervals": state.fracture_adapter_state.accepted_intervals,
            "native_backend_calls": state.fracture_adapter_state.native_backend_calls,
            "last_mechanics_binding": state.fracture_adapter_state.last_mechanics_binding,
            "accumulated_plastic_exposure": (
                max(state.fields.equivalent_plastic_strain)-initial_exposure),
            "direct_birth_first_passage_s": first_passage,
            "reporting_cadence_s": cadence_s,
            "trace": trace,
        }

    outcomes = {
        "no_void": simulate(False, 0.1),
        "void_enabled": simulate(True, 0.1),
    }
    partition_runs = {str(cadence): simulate(True, cadence)
                      for cadence in (0.05, 0.01)}
    hold_prediction = simulate(True, 0.05, 0.10)
    observed = next(row for row in payload["rows"]
                    if row["checkpoint"] == "restart_002600ms.json")
    predicted = outcomes["void_enabled"]["terminal"]
    observed_growth = observed["growth"][0]
    birth_index = next(
        index for index, item in enumerate(outcomes["void_enabled"]["trace"])
        if item["direct_hits"] == 3)
    oneD_birth_upper_s = outcomes["void_enabled"]["trace"][birth_index]["time_s"]
    oneD_birth_lower_s = (
        start_time if birth_index == 0
        else outcomes["void_enabled"]["trace"][birth_index-1]["time_s"])
    result = {
        "schema": "oneD.v3.bounded-autonomous-aligned/1",
        "closure_dataset_sha256": closure.dataset_sha256,
        "external_inputs": {
            "opening_m": closure.opening_m, "temperature_K": 1200.0,
            "initial_time_s": start_time, "terminal_time_s": stop_time,
            "material": "DBTT",
            "site_population": "TWO_SITES_STOP_BEFORE_SECOND_CAVITY_PUBLICATION",
        },
        "outcomes": outcomes,
        "matched_terminal_comparison": {
            "twoD_third_hit_bracket_s": [2.09999, 2.19999],
            "oneD_third_hit_bracket_s": [oneD_birth_lower_s, oneD_birth_upper_s],
            "third_hit_macro_interval_match": (
                oneD_birth_lower_s >= 2.09999-1.0e-12
                and oneD_birth_upper_s <= 2.19999+1.0e-12),
            "twoD_radius_m": observed_growth["radius_m"],
            "oneD_radius_m": predicted["radius_m"],
            "radius_relative_error": abs(predicted["radius_m"]
                                         -observed_growth["radius_m"])
                                     /observed_growth["radius_m"],
            "twoD_loop_count": observed_growth["emitted_loop_count_effective"],
            "oneD_loop_count": predicted["loop_count"],
            "loop_count_relative_error": abs(predicted["loop_count"]
                                             -observed_growth[
                                                 "emitted_loop_count_effective"])
                                         /observed_growth[
                                             "emitted_loop_count_effective"],
            "twoD_growth_representation": observed_growth["representation"],
            "oneD_growth_representation": predicted["growth_representation"],
            "residual_classification_match": (
                observed_growth["representation"]
                == predicted["growth_representation"]),
            "far_field_void_delta_G_J_per_m2": 0.0,
        },
        "fracture_backend_execution": {
            "no_void_accepted_intervals": outcomes["no_void"][
                "fracture_adapter_intervals"],
            "void_enabled_accepted_intervals": outcomes["void_enabled"][
                "fracture_adapter_intervals"],
            "full_FEM_calls": 0,
            "native_backend_calls": native_backend_calls,
            "runtime_s": time.perf_counter()-wall_start,
            "accepted_fracture_events": predicted["fracture_event_count"],
            "outcome": "NO_FRACTURE_EVENT_AT_MEASURED_FIXED_LOAD",
        },
        "partition_convergence": {
            "0.1": {
                key: outcomes["void_enabled"][key] for key in (
                    "accumulated_plastic_exposure",
                    "direct_birth_first_passage_s")},
            **{key: {name: value[name] for name in (
                "accumulated_plastic_exposure",
                "direct_birth_first_passage_s")}
               for key, value in partition_runs.items()},
            "ownership": "ONE_ACCEPTED_INCREMENT_SLICED_EXACTLY_ONCE",
        },
        "prospective_out_of_training_hold_prediction": {
            "history": "FIXED_OPENING_ZERO_NEW_ACCEPTED_PLASTIC_INCREMENT",
            "start_time_s": stop_time,
            "end_time_s": stop_time+0.10,
            "terminal": hold_prediction["terminal"],
            "direct_birth_first_passage_s": hold_prediction[
                "direct_birth_first_passage_s"],
            "accumulated_plastic_exposure": hold_prediction[
                "accumulated_plastic_exposure"],
            "status": "PREDICTION_FROZEN_BEFORE_INDEPENDENT_2D_HOLD",
        },
        "scope_stop": "RESOLVED_CAVITY_UNQUALIFIED_FAIL_CLOSED",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    temporary = OUT.with_suffix(OUT.suffix+".tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    os.replace(temporary, OUT)
    print(OUT)
    print(json.dumps(result["matched_terminal_comparison"], sort_keys=True))
    print("VOID_EVENTS", len(outcomes["void_enabled"]["events"]))
    print("FRACTURE_INTERVALS", outcomes["void_enabled"]["fracture_adapter_intervals"])


if __name__ == "__main__":
    main()
