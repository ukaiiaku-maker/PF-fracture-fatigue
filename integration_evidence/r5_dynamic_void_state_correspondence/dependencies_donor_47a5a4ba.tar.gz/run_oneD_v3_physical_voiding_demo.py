#!/usr/bin/env python3
"""Executable V3 physical-line trajectory and shared-input comparison."""
from __future__ import annotations

from dataclasses import asdict, replace
import csv
from enum import Enum
import json
import math
import os
from pathlib import Path
import sys
import time

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from reduced_fracture_v2.state import ReducedState
from reduced_fracture_v2.parameters import CanonicalParameters
from arrhenius_fracture.fatigue_v1 import FatigueWaveform
from reduced_fracture_v3 import (
    LineNormalization,
    FractureProcessRow,
    PhysicalIncrement,
    ReducedSiteState,
    SitePhase,
    TwoMechanismRows,
    advance_existing_fatigue_waveform,
    advance_physical_time,
    direct_successful_rate_from_integrated_opportunity_s,
    initialize_executable_state,
    no_void_downgrade,
    no_void_upgrade,
    physical_fingerprint,
    restore_physical_checkpoint,
    write_physical_checkpoint,
)


TWO_D_ROOT = Path(os.environ.get(
    "TWO_D_ROOT", "/Volumes/Data/Data/Nanopillar_calculation/voiding/recovered-pr63"
))
TWO_D_JOB = TWO_D_ROOT / "runs/managed_natural_void_v1_20260919"
OUT = ROOT / "analysis_outputs/oneD_v3_physical_voiding"


def finite(value):
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {str(key): finite(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [finite(item) for item in value]
    if isinstance(value, np.ndarray):
        return finite(value.tolist())
    if isinstance(value, np.generic):
        return finite(value.item())
    return value


def rows_from_declared(declared):
    direct = declared["direct_parameter_row"]
    emission = declared["cavity_emission_parameter_row"]
    b = float(direct["burgers_m"])
    atomic = 4.0*b**3/(3.0*math.sqrt(3.0))
    temperature = float(declared["temperature_K"])
    diffusivity = 1.0e-6*math.exp(-0.9*1.602176634e-19/(1.380649e-23*temperature))
    return TwoMechanismRows(
        row_id=(direct["row_id"] + "+" + emission["row_id"]
                + "+oneD-line-closure-v1"),
        atomic_volume_m3=atomic, vacancy_formation_volume_m3=atomic,
        vacancy_diffusivity_m2_s=diffusivity,
        vacancy_stress_coupling_volume_m3=atomic,
        plastic_vacancy_coefficient_per_strain=3.0e-5,
        climb_sink_rate_s=1.0e-2,
        exterior_sink_efficiency=1.0,
        site_capture_factor=1.0,
        vacancy_birth_barrier_J=1.2e-19,
        vacancy_hit_area_m2=2.0e-20,
        vacancy_required_hits=2,
        direct_geometry_factor=float(direct["interaction_geometry_factor_C_dd"]),
        taylor_factor=float(direct["taylor_factor_M"]),
        burgers_m=b,
        direct_success_fraction=float(direct["successful_direct_outcome_fraction"]),
        direct_barrier_eV=float(direct["interaction_barrier_eV"]),
        direct_activation_volume_m3=float(direct["stress_activation_volume_m3"]),
        direct_hit_area_m2=(float(direct["chi_loop"])*2.0*math.pi
                            *float(direct["embryo_reference_radius_m"])*b),
        direct_required_hits=int(direct["required_interaction_hits"]),
        stabilization_rate_s=2.0,
        healing_rate_s=0.1,
        lifecycle_attempt_frequency_s=1.0e12,
        stabilization_barrier_J=0.8e-19,
        healing_barrier_J=1.0e-19,
        stabilization_activation_volume_m3=1.0e-29,
        healing_activation_volume_m3=1.0e-29,
        emission_attempt_frequency_s=float(emission["attempt_frequency_s"]),
        emission_barrier_J=float(emission["zero_stress_barrier_J"]),
        emission_stress_volume_m3=atomic,
        emission_area_per_loop_m2=float(emission["chi_loop"])*2.0*math.pi*1.0e-9*b,
        emission_surface_source_density_per_m=float(emission["surface_source_density_per_m"]),
        emission_source_count=len(emission["source_orientations_rad"]),
        emission_critical_stress_Pa=float(emission["barrier_critical_stress_Pa"]),
        emission_barrier_exp_a=float(emission["barrier_exp_a"]),
        emission_barrier_exp_n=float(emission["barrier_exp_n"]),
        emission_barrier_floor_fraction=float(emission["barrier_floor_fraction"]),
        emission_barrier_floor_min_J=float(emission["barrier_floor_min_J"]),
        emission_surface_energy_J_m2=float(emission["surface_energy_J_m2"]),
        emission_chi_loop=float(emission["chi_loop"]),
        emission_depletion_per_loop=float(emission["depletion_per_loop"]),
        emission_recovery_rate_s=float(emission["recovery_rate_s"]),
        vacancy_formation_energy_eV=2.4,
        vacancy_formation_entropy_over_kB=0.0,
        vacancy_migration_energy_eV=0.9,
        vacancy_diffusivity_prefactor_m2_s=1.0e-6,
        dislocation_production_boost=0.20,
        interaction_mobile_vacancy_fraction=float(declared["population_partition"][0]),
        interaction_direct_cavitation_fraction=float(declared["population_partition"][1]),
        interaction_benign_fraction=float(declared["population_partition"][2]),
        dislocation_climb_capture_efficiency=1.0,
        rho_reference_m2=1.0e12,
        bulk_accommodation_coefficient=1.0,
    )


def retained_dbtt_fracture_row():
    registry = (ROOT / "analysis_outputs/oneD_v2_predictive_model"
                / "oneD_v2_new_four_class_registry.csv")
    with registry.open(newline="") as handle:
        source = next(row for row in csv.DictReader(handle)
                      if row["candidate_id"] == "v913_zeroD_sobol_0202500")
    keys = (
        "Tref_K", "cleave_G00_eV", "cleave_gT_eV_per_K",
        "cleave_sigc0_GPa", "cleave_sT_GPa_per_K", "cleave_exp_a",
        "cleave_exp_n", "cleave_floor_frac", "emit_G00_eV",
        "emit_gT_eV_per_K", "emit_sigc0_GPa", "emit_sT_GPa_per_K",
        "emit_exp_a", "emit_exp_n", "emit_floor_frac", "peierls_H0_eV",
        "peierls_nu0_s", "taylor_H0_eV", "taylor_nu0_s",
    )
    parameters = CanonicalParameters(
        source["candidate_id"], {key: float(source[key]) for key in keys})
    return FractureProcessRow.from_parameters(
        parameters, cleavage_advance_m=2.0e-5)


def mechanics_increment(state, signed_load, dt):
    x = state.normalization.centers_m
    # Prescribed physical strain-rate history.  Refining time or waveform
    # phase sampling changes quadrature only; it cannot create extra plastic
    # activity merely by making more calls.
    activity_rate_s = (abs(float(signed_load))*1.0e-2
                       *np.exp(-((x-6.0e-4)/1.5e-4)**2))
    activity = activity_rate_s*float(dt)
    tensile = max(float(signed_load), 0.0)
    opening = 3.0e9*tensile*np.exp(-((x-6.0e-4)/2.0e-4)**2)
    mean = 1.8e9*tensile*np.exp(-((x-6.0e-4)/2.5e-4)**2)
    return PhysicalIncrement(
        duration_s=float(dt), signed_load=float(signed_load),
        equivalent_plastic_strain_increment=tuple(activity),
        forest_density_m2=tuple(np.full(len(x), 1.0e12)),
        mobile_density_m2=tuple(np.full(len(x), 1.0e10)),
        mean_stress_Pa=tuple(mean), opening_stress_Pa=tuple(opening),
        crack_surface_sink_rate_s=tuple(np.where(x < 4.0e-4, 0.1, 0.0)),
        fracture_cleavage_stress_Pa=float(np.max(opening)),
        fracture_emission_stress_Pa=float(np.max(opening)),
    )


def accepted_history_comparison(progress, mechanism_rows, template_state):
    """Independently evolve one reduced state through the accepted 2-D chain."""
    # Step 1 and step 2 are alternative initial ramp resolutions.  Recover the
    # actual parent chain backward from the latest accepted endpoint instead
    # of replaying both overlapping rows.
    remaining = list(progress.get("history", []))
    chain = []
    endpoint = max((float(row["end_time_s"]) for row in remaining), default=0.0)
    while endpoint > 1.0e-15:
        candidates = [row for row in remaining if math.isclose(
            float(row["end_time_s"]), endpoint, rel_tol=0.0, abs_tol=1.0e-14)]
        if not candidates:
            raise RuntimeError("accepted 2-D history is not a contiguous parent chain")
        row = max(candidates, key=lambda item: int(item["step"]))
        chain.append(row)
        endpoint = float(row["start_time_s"])
    chain.reverse()

    # These immutable thresholds and RNG identities are read from the valid
    # restart_002100ms accepted owner.  They are inputs to this prescribed-
    # opportunity comparison, not refitted quantities.
    accepted_thresholds = {
        "site-1": (2.478977171068976, 4.3371792343359115, 5.49103389229482),
        "site-2": (4.110064149241676, 4.146298237212335, 5.539499232509707),
    }
    mapped_sites = tuple(replace(
        site, direct_thresholds=accepted_thresholds[site.site_id],
        vacancy_thresholds=(1.0e100, 2.0e100),
        direct_action=0.0, direct_hits=0, direct_free_volume_area_m2=0.0,
        vacancy_action=0.0, vacancy_hits=0, reserved_vacancy_area_m2=0.0,
    ) for site in template_state.sites)
    predicted = replace(
        template_state, sites=mapped_sites, fracture_process_row=None,
        event_history=())
    records = []
    n = len(predicted.normalization.cell_lengths_m)
    for entry in chain:
        opportunities = {row["site_id"]: row[
            "support_integrated_interaction_rate_s"]
            for row in entry["direct_opportunity"]}
        stresses = {row["site_id"]: row["mean_stress_support_Pa"]
                    for row in entry["direct_opportunity"]}
        dt = float(entry["accepted_duration_s"])
        loop_rho = np.asarray(
            predicted.fields.loop_deposited_forest_density_m2
            or np.zeros(n), float)
        increment = PhysicalIncrement(
            duration_s=dt, signed_load=0.0,
            equivalent_plastic_strain_increment=(0.0,)*n,
            forest_density_m2=tuple(
                np.asarray(predicted.fields.forest_density_m2)-loop_rho),
            mobile_density_m2=predicted.fields.mobile_density_m2,
            mean_stress_Pa=(0.0,)*n, opening_stress_Pa=(0.0,)*n,
            prescribed_direct_opportunity_rate_s_by_site=opportunities,
            prescribed_direct_mean_stress_Pa_by_site=stresses,
        )
        event_count_before = len(predicted.event_history)
        predicted = advance_physical_time(predicted, increment)
        for site in predicted.sites:
            observed_action = float(entry["state"]["direct_action"][site.site_id])
            observed_hits = int(entry["state"]["direct_hits"][site.site_id])
            records.append({
                "step": entry["step"], "site_id": site.site_id,
                "start_time_s": entry["start_time_s"],
                "end_time_s": entry["end_time_s"],
                "oneD_evolved_action": site.direct_action,
                "twoD_accepted_action": observed_action,
                "oneD_evolved_hits": site.direct_hits,
                "twoD_accepted_hits": observed_hits,
                "event_interval": bool(entry["selected_events"]),
                "oneD_events_committed": len(predicted.event_history)-event_count_before,
                "absolute_error": abs(site.direct_action-observed_action),
                "relative_error": abs(site.direct_action-observed_action)
                                  /max(abs(observed_action), 1.0e-300),
            })
    return records


def write_plots(trace):
    times = np.asarray([row["time_s"] for row in trace])
    figures = []
    specifications = (
        ("radius_history.png", "radii_m", "Cavity radius (m)"),
        ("fracture_length_history.png", "fracture_length_m", "Fracture front position (m)"),
        ("action_history.png", "direct_action", "Direct action"),
        ("inventory_history.png", "owned_vacancy_area_m2", "Owned vacancy area (m²)"),
        ("plasticity_history.png", "maximum_plastic_strain", "Maximum equivalent plastic strain"),
    )
    for filename, key, ylabel in specifications:
        fig, ax = plt.subplots(figsize=(6.4, 3.8))
        if isinstance(trace[0][key], dict):
            for site_id in trace[0][key]:
                ax.plot(times, [row[key][site_id] for row in trace], marker="o",
                        ms=2.5, label=site_id)
            ax.legend()
        else:
            ax.plot(times, [row[key] for row in trace], marker="o", ms=2.5)
        ax.set(xlabel="Physical time (s)", ylabel=ylabel)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(OUT / filename, dpi=160)
        plt.close(fig)
        figures.append(filename)
    return figures


def fixed_history_refinement_checks(base_state):
    """Time/phase and coupled-growth refinement at fixed physical histories."""
    time_rows = []
    for count in (50, 100, 200):
        trial = base_state
        for _ in range(count):
            trial = advance_physical_time(
                trial, mechanics_increment(trial, 1.0, 1.0/count))
        time_rows.append({
            "time_steps": count,
            "maximum_accumulated_plastic_strain": max(
                trial.fields.equivalent_plastic_strain),
        })

    waveform = FatigueWaveform(
        Kmax=1.0, R=-0.5, frequency_Hz=100.0, closure_clip=False)
    phase_rows = []
    for phases in (8, 16, 32):
        trial = advance_existing_fatigue_waveform(
            base_state, waveform, mechanics_increment, cycles=1,
            n_phase=phases)
        phase_rows.append({
            "phase_samples": phases,
            "elapsed_time_s": trial.physical_time_s,
            "maximum_accumulated_plastic_strain": max(
                trial.fields.equivalent_plastic_strain),
        })

    radius0 = 1.0e-9
    seed_area = math.pi*radius0**2
    growth_rows = []
    terminals = {}
    for partitions in (1, 2, 4, 8):
        owner = replace(
            base_state.sites[0], phase=SitePhase.STABLE, radius_m=radius0,
            direct_hits=base_state.rows.direct_required_hits,
            direct_free_volume_area_m2=seed_area,
            direct_action=base_state.sites[0].direct_thresholds[-1],
        )
        inactive = replace(base_state.sites[1], phase=SitePhase.HEALED)
        trial = replace(
            base_state, sites=(owner, inactive), fracture_process_row=None,
            rows=replace(
                base_state.rows, site_capture_factor=0.0,
                plastic_vacancy_coefficient_per_strain=0.0),
            event_history=())
        n = len(trial.normalization.cell_lengths_m)
        for _ in range(partitions):
            dt = 1.0e-6/partitions
            trial = advance_physical_time(trial, PhysicalIncrement(
                duration_s=dt, signed_load=1.0,
                equivalent_plastic_strain_increment=(0.0,)*n,
                forest_density_m2=trial.fields.forest_density_m2,
                mobile_density_m2=trial.fields.mobile_density_m2,
                mean_stress_Pa=(3.0e9,)*n,
                opening_stress_Pa=(5.0e9,)*n,
            ))
        terminal = trial.sites[0]
        terminals[partitions] = trial
        growth_rows.append({
            "partitions": partitions,
            "radius_m": terminal.radius_m,
            "realized_loop_count": terminal.realized_emitted_loop_count,
            "continuum_moment_loop_count": terminal.continuum_moment_loop_count,
            "emission_packet_count": terminal.emission_packet_count,
            "source_availability": terminal.emission_source_availability,
        })
    checkpoint_path = OUT / "coupled_growth_midpoint_restart.json"
    midpoint = terminals[2]
    write_physical_checkpoint(midpoint, checkpoint_path)
    restored_midpoint = restore_physical_checkpoint(checkpoint_path)
    rare_radius = 1.0e-8
    rare_area = math.pi*rare_radius**2
    rare_owner = replace(
        base_state.sites[0], phase=SitePhase.EMBRYO, radius_m=rare_radius,
        direct_hits=base_state.rows.direct_required_hits,
        direct_free_volume_area_m2=rare_area,
        direct_action=base_state.sites[0].direct_thresholds[-1],
        healing_action=0.95,
    )
    rare = replace(
        base_state, sites=(rare_owner, replace(
            base_state.sites[1], phase=SitePhase.HEALED)),
        fracture_process_row=None, temperature_K=300.0,
        rows=replace(base_state.rows, site_capture_factor=0.0,
                     plastic_vacancy_coefficient_per_strain=0.0),
        event_history=())
    n = len(rare.normalization.cell_lengths_m)
    rare = advance_physical_time(rare, PhysicalIncrement(
        duration_s=1.0, signed_load=1.0,
        equivalent_plastic_strain_increment=(0.0,)*n,
        forest_density_m2=rare.fields.forest_density_m2,
        mobile_density_m2=rare.fields.mobile_density_m2,
        mean_stress_Pa=(0.0,)*n, opening_stress_Pa=(0.0,)*n,
    ))
    rare_terminal = rare.sites[0]
    return {
        "time_refinement": time_rows,
        "time_refinement_relative_spread": (
            (max(row["maximum_accumulated_plastic_strain"] for row in time_rows)
             -min(row["maximum_accumulated_plastic_strain"] for row in time_rows))
            /max(row["maximum_accumulated_plastic_strain"] for row in time_rows)),
        "phase_refinement": phase_rows,
        "growth_partition_refinement": growth_rows,
        "growth_radius_relative_spread": (
            (max(row["radius_m"] for row in growth_rows)
             -min(row["radius_m"] for row in growth_rows))
            /max(row["radius_m"] for row in growth_rows)),
        "growth_restart_exact": (
            physical_fingerprint(midpoint) == physical_fingerprint(restored_midpoint)),
        "growth_owner": "unified-2d.embryo-growth/1 mesh-free adapter",
        "rare_emission_healing_control": {
            "temperature_K": 300.0,
            "realized_loop_count": rare_terminal.realized_emitted_loop_count,
            "continuum_moment_loop_count": rare_terminal.continuum_moment_loop_count,
            "integrated_low_count_action": math.fsum(
                source.integrated_action for source in rare_terminal.emission_sources),
            "terminal_phase": rare_terminal.phase.value,
            "events": list(rare.event_history),
            "fractional_expectation_did_not_create_residual_defect": (
                rare_terminal.realized_emitted_loop_count == 0
                and rare_terminal.phase == SitePhase.HEALED),
        },
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    declared = json.loads((TWO_D_JOB / "output/declared_inputs.json").read_text())
    progress = json.loads((TWO_D_JOB / "output/progress.json").read_text())
    mechanics_readiness = json.loads((
        ROOT / "analysis_outputs/oneD_v3_stateful_voiding/v5_retained_oracle_export.json"
    ).read_text())["readiness"]
    mechanism_rows = rows_from_declared(declared)
    edges = tuple(np.linspace(0.0, 1.0e-3, 33))
    normalization = LineNormalization(
        cell_edges_m=edges, transverse_width_m=(1.0e-3,)*32,
        thickness_m=1.0, exterior_surface_multiplier=(2.0,)*32,
    )
    rng = np.random.default_rng(int(declared["stochastic_seed"]))
    sites = tuple(ReducedSiteState(
        site_id=f"site-{index+1}", x_m=float(point[0]),
        support_half_width_m=5.0e-5,
        vacancy_thresholds=tuple(np.cumsum(rng.exponential(size=2))),
        direct_thresholds=tuple(np.cumsum(rng.exponential(size=3))),
    ) for index, point in enumerate(declared["site_centers_m"]))
    core_v2 = ReducedState()
    core_v3 = no_void_upgrade(core_v2)
    assert no_void_downgrade(core_v3) == core_v2
    state = initialize_executable_state(
        core_v3, normalization, mechanism_rows, sites=sites,
        initial_vacancy_fraction=1.0e-10,
        initial_forest_density_m2=1.0e12,
        temperature_K=float(declared["temperature_K"]),
        fracture_process_row=retained_dbtt_fracture_row(),
        fracture_front_origin_m=float(progress["history"][0]["state"]["crack_length_m"]),
    )
    started = time.perf_counter()
    trace = []
    for step in range(100):
        state = advance_physical_time(state, mechanics_increment(state, 1.0, 0.01))
        if step % 10 == 9 or len(state.event_history) != (len(trace[-1]["events"])
                                                           if trace else 0):
            trace.append({
                "time_s": state.physical_time_s,
                "phases": {site.site_id: site.phase.value for site in state.sites},
                "radii_m": {site.site_id: site.radius_m for site in state.sites},
                "direct_hits": {site.site_id: site.direct_hits for site in state.sites},
                "direct_action": {site.site_id: site.direct_action for site in state.sites},
                "vacancy_hits": {site.site_id: site.vacancy_hits for site in state.sites},
                "owned_vacancy_area_m2": {
                    site.site_id: (site.reserved_vacancy_area_m2
                                   +site.vacancy_growth_area_m2
                                   +site.captured_unaccommodated_vacancy_area_m2)
                    for site in state.sites},
                "maximum_plastic_strain": max(state.fields.equivalent_plastic_strain),
                "fracture_length_m": (state.fracture_front_origin_m
                                      +state.core.fracture_state.crack_extension_m),
                "events": list(state.event_history),
            })
    monotonic_runtime = time.perf_counter()-started
    monotonic = state
    checkpoint = OUT / "monotonic_restart.json"
    write_physical_checkpoint(monotonic, checkpoint)
    restored = restore_physical_checkpoint(checkpoint)

    # Existing fatigue waveform owns signed loading. The adapter supplies
    # actual phase duration and never clears the monotonic state.
    fatigue_waveform = FatigueWaveform(
        Kmax=1.0, R=-0.5, frequency_Hz=100.0, closure_clip=False,
    )
    fatigue = advance_existing_fatigue_waveform(
        restored, fatigue_waveform, mechanics_increment, cycles=3, n_phase=16,
    )
    fatigue_checkpoint = OUT / "fatigue_interface_restart.json"
    write_physical_checkpoint(fatigue, fatigue_checkpoint)

    comparison = None
    if progress.get("history"):
        audit = progress["history"][0]["direct_opportunity"][0]
        one_d_rate = direct_successful_rate_from_integrated_opportunity_s(
            mechanism_rows,
            support_integrated_opportunity_rate_s=audit[
                "support_integrated_interaction_rate_s"],
            mean_stress_Pa=audit["mean_stress_support_Pa"],
            temperature_K=audit["temperature_K"],
        )
        two_d_rate = float(audit["successful_direct_interaction_rate_s"])
        comparison = {
            "kind": "IDENTICAL_PRESCRIBED_SUPPORT_INTEGRAL",
            "two_d_rate_s": two_d_rate,
            "one_d_rate_s": one_d_rate,
            "relative_error": abs(one_d_rate-two_d_rate)/max(abs(two_d_rate), 1.0e-300),
            "parameter_row_id": audit["parameter_row_id"],
            "parameter_row_fingerprint_2d": audit["parameter_row_fingerprint"],
            "parameter_row_fingerprint_1d": mechanism_rows.fingerprint,
            "interpretation": "kinetic parity; not free mechanics transfer",
        }
    history_comparison = accepted_history_comparison(
        progress, mechanism_rows,
        initialize_executable_state(
            core_v3, normalization, replace(
                mechanism_rows, site_capture_factor=0.0,
                plastic_vacancy_coefficient_per_strain=0.0), sites=sites,
            initial_vacancy_fraction=1.0e-10,
            initial_forest_density_m2=1.0e12,
            temperature_K=float(declared["temperature_K"]),
        ),
    )
    refinement = fixed_history_refinement_checks(initialize_executable_state(
        core_v3, normalization, mechanism_rows, sites=sites,
        initial_vacancy_fraction=1.0e-10,
        initial_forest_density_m2=1.0e12,
        temperature_K=float(declared["temperature_K"]),
        fracture_process_row=retained_dbtt_fracture_row(),
        fracture_front_origin_m=float(
            progress["history"][0]["state"]["crack_length_m"]),
    ))
    plot_files = write_plots(trace)
    result = finite({
        "schema": "oneD.v3.executable-physical-voiding-demo/1",
        "source_2d_job": str(TWO_D_JOB),
        "two_d_progress_time_s_at_comparison": progress.get("accepted_time_s"),
        "no_void_v2_v3_exact_parity": True,
        "shared_input_direct_kinetic_comparison": comparison,
        "accepted_history_direct_action_comparison": {
            "interval_count": len(history_comparison),
            "maximum_relative_error": max(
                (row["relative_error"] for row in history_comparison), default=None),
            "rows": history_comparison,
            "event_interval_count": sum(
                row["event_interval"] for row in history_comparison)//2,
            "hit_mismatch_count": sum(
                row["oneD_evolved_hits"] != row["twoD_accepted_hits"]
                for row in history_comparison),
            "scope": ("one mapped initial state, independently evolved through the "
                      "contiguous accepted parent chain including direct-hit boundaries"),
        },
        "fixed_physical_history_refinement": refinement,
        "production_fracture_transaction_status": {
            "instantaneous_shared_barrier_core": "CONNECTED",
            "full_v2_commit_renewal_wake_update": "CAPABILITY_STOP_NOT_AVAILABLE_AS_PURE_STATE_API",
            "wrapper_cleavage_commit_is_not_claimed_equivalent": True,
        },
        "bounded_predictive_mechanics": {
            "status": "CAPABILITY_STOP_FAIL_CLOSED_NO_MAP_READY_ROWS",
            "readiness": mechanics_readiness,
            "autonomous_void_trajectory_run": False,
            "reason": ("retained evidence has no complete mechanics row; source tensor, "
                       "G, compliance and/or energy coordinates are missing, so a feedback "
                       "closure cannot be constructed without inference or a new 2-D solve"),
        },
        "normalization": asdict(normalization),
        "mechanism_rows": asdict(mechanism_rows),
        "monotonic": {
            "physical_time_s": monotonic.physical_time_s,
            "runtime_s": monotonic_runtime,
            "phases": {site.site_id: site.phase.value for site in monotonic.sites},
            "events": list(monotonic.event_history),
            "ledgers": asdict(monotonic.ledgers),
            "restart_exact": physical_fingerprint(restored) == physical_fingerprint(monotonic),
            "trace": trace,
            "fracture_parameter_row": monotonic.fracture_process_row.candidate_id,
            "fracture_action_advanced": (
                monotonic.core.fracture_state.cleavage_action > 0.0
                and monotonic.core.fracture_state.emission_action > 0.0),
            "canonical_v3_void_state": asdict(monotonic.core.void_state),
            "single_void_owner_consistent": (
                monotonic.core.void_state is not None
                and sum(site.phase.value not in {"AVAILABLE_SITE", "HEALED_SITE"}
                        for site in monotonic.sites) == 1
                and monotonic.core.void_state.site_id == next(
                    site.site_id for site in monotonic.sites
                    if site.phase.value not in {"AVAILABLE_SITE", "HEALED_SITE"})
            ),
            "unsupported_competing_site_birth_complete": any(
                site.site_id != monotonic.core.void_state.site_id
                and site.direct_hits >= monotonic.rows.direct_required_hits
                for site in monotonic.sites),
            "single_cavity_capability_stop": (
                "SECOND_BIRTH_COMPLETE_BUT_NOT_COMMITTED_WHILE_FIRST_CAVITY_ACTIVE"
            ),
        },
        "fatigue_interface": {
            "driver": "arrhenius_fracture.fatigue_v1.FatigueWaveform",
            "Kmax": fatigue_waveform.Kmax,
            "R": fatigue_waveform.R,
            "frequency_Hz": fatigue_waveform.frequency_Hz,
            "closure_clip": fatigue_waveform.closure_clip,
            "phase_samples_per_cycle": 16,
            "physical_time_s": fatigue.physical_time_s,
            "cycle_count": fatigue.cycle_count,
            "state_preserved_from_monotonic": (
                fatigue.physical_time_s > monotonic.physical_time_s
                and len(fatigue.event_history) >= len(monotonic.event_history)
            ),
            "signed_terminal_load": fatigue.core.fracture_state.external_control,
            "restart": fatigue_checkpoint.name,
        },
        "mechanics_transfer_status": (
            "PRELIMINARY_CONTROLLED_INPUT_ONLY_PENDING_QUALIFIED_ALIGNED_MAPS"
        ),
        "missing_closures": [
            "qualified plastic-history-dependent preconnection mechanics response",
            "connected-cavity downstream surface response over selected geometry",
            "2-D-derived transverse surface-exchange coefficients for free prediction",
        ],
        "plots": plot_files,
    })
    (OUT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("ONED_V3_EXECUTABLE_PHYSICAL_VOIDING = PASS")
    print("NO_VOID_PARITY = PASS")
    print("DIRECT_KINETIC_PARITY_RELATIVE_ERROR", comparison["relative_error"])
    print("DIRECT_HISTORY_INTERVALS", len(history_comparison))
    print("DIRECT_HISTORY_MAX_RELATIVE_ERROR",
          result["accepted_history_direct_action_comparison"]["maximum_relative_error"])
    print("FRACTURE_HAZARD_CORE_INTERFACE = PASS")
    print("FULL_V2_FRACTURE_TRANSACTION = CAPABILITY_STOP")
    print("BOUNDED_PREDICTIVE_MECHANICS = CAPABILITY_STOP_NO_MAP_READY_ROWS")
    print("MONOTONIC_PHASES", result["monotonic"]["phases"])
    print("FATIGUE_INTERFACE = PASS")


if __name__ == "__main__":
    main()
