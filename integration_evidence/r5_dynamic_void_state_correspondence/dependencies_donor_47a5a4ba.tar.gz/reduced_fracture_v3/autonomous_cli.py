"""Installed, repository-independent OneD V3 monotonic reference command.

This is the retained functional-control trajectory from the executable physical
voiding demonstration.  It is an autonomous reduced calculation: it invokes no
FEM solver and consumes no sibling checkout.  It is not labelled as a calibrated
2-D-to-1-D predictive closure.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
from importlib import metadata
import json
import math
from pathlib import Path
import time

import numpy as np

from reduced_fracture_v2.parameters import CanonicalParameters
from reduced_fracture_v2.state import ReducedState
from .physical import (
    FractureProcessRow, LineNormalization, PhysicalIncrement, ReducedSiteState,
    TwoMechanismRows, advance_physical_time, initialize_executable_state,
)
from .state import no_void_upgrade


CASE_ID = "oneD-v3-retained-monotonic-functional-control-v1"


def _mechanism_rows() -> TwoMechanismRows:
    b = 2.74e-10
    atomic = 4.0*b**3/(3.0*math.sqrt(3.0))
    temperature = 1200.0
    diffusivity = 1.0e-6*math.exp(
        -0.9*1.602176634e-19/(1.380649e-23*temperature))
    return TwoMechanismRows(
        row_id=("hypothesis.elevated-mixed-v1:Cdd=1e-08:barrier-eV=0.25+"
                "hypothesis.elevated-emission-v1:G0-J=1.8e-19+"
                "oneD-line-closure-v1"),
        atomic_volume_m3=atomic, vacancy_formation_volume_m3=atomic,
        vacancy_diffusivity_m2_s=diffusivity,
        vacancy_stress_coupling_volume_m3=atomic,
        plastic_vacancy_coefficient_per_strain=3.0e-5,
        climb_sink_rate_s=1.0e-2, exterior_sink_efficiency=1.0,
        site_capture_factor=1.0, vacancy_birth_barrier_J=1.2e-19,
        vacancy_hit_area_m2=2.0e-20, vacancy_required_hits=2,
        direct_geometry_factor=1.0e-8, taylor_factor=3.06, burgers_m=b,
        direct_success_fraction=0.1, direct_barrier_eV=0.25,
        direct_activation_volume_m3=1.6e-29,
        direct_hit_area_m2=2.0*math.pi*1.0e-9*b,
        direct_required_hits=3, stabilization_rate_s=2.0,
        healing_rate_s=0.1, lifecycle_attempt_frequency_s=1.0e12,
        stabilization_barrier_J=0.8e-19, healing_barrier_J=1.0e-19,
        stabilization_activation_volume_m3=1.0e-29,
        healing_activation_volume_m3=1.0e-29,
        emission_attempt_frequency_s=1.0e11, emission_barrier_J=1.8e-19,
        emission_stress_volume_m3=atomic,
        emission_area_per_loop_m2=2.0*math.pi*1.0e-9*b,
        emission_surface_source_density_per_m=2.0e8,
        emission_source_count=3, emission_critical_stress_Pa=3.0e9,
        emission_barrier_exp_a=1.0, emission_barrier_exp_n=1.0,
        emission_barrier_floor_fraction=0.05,
        emission_barrier_floor_min_J=1.0e-23,
        emission_surface_energy_J_m2=2.5, emission_chi_loop=1.0,
        emission_depletion_per_loop=0.02, emission_recovery_rate_s=1.0e-3,
        vacancy_formation_energy_eV=2.4,
        vacancy_formation_entropy_over_kB=0.0,
        vacancy_migration_energy_eV=0.9,
        vacancy_diffusivity_prefactor_m2_s=1.0e-6,
        dislocation_production_boost=0.20,
        interaction_mobile_vacancy_fraction=0.5,
        interaction_direct_cavitation_fraction=0.1,
        interaction_benign_fraction=0.4,
        dislocation_climb_capture_efficiency=1.0,
        rho_reference_m2=1.0e12, bulk_accommodation_coefficient=1.0,
    )


def _fracture_row() -> FractureProcessRow:
    values = {
        "Tref_K": 481.33,
        "cleave_G00_eV": 2.357721022795886,
        "cleave_gT_eV_per_K": 0.0056085130451247,
        "cleave_sigc0_GPa": 6.7501407796517015,
        "cleave_sT_GPa_per_K": -0.0012041387008503,
        "cleave_exp_a": 0.4968366474844515,
        "cleave_exp_n": 2.618804107885808,
        "cleave_floor_frac": 0.026239358201278,
        "emit_G00_eV": 3.344896922819316,
        "emit_gT_eV_per_K": 0.0061668124636635,
        "emit_sigc0_GPa": 2.7143102660775185,
        "emit_sT_GPa_per_K": -0.0052233074344694,
        "emit_exp_a": 0.1572539726179093,
        "emit_exp_n": 0.5156166724395007,
        "emit_floor_frac": 0.0103682254353579,
        "peierls_H0_eV": 3.525720003992319,
        "peierls_nu0_s": 1.0e12,
        "taylor_H0_eV": 1.4998139148950578,
        "taylor_nu0_s": 1.0e11,
    }
    return FractureProcessRow.from_parameters(
        CanonicalParameters("v913_zeroD_sobol_0202500", values),
        cleavage_advance_m=2.0e-5,
    )


def _increment(state, duration_s: float) -> PhysicalIncrement:
    x = state.normalization.centers_m
    activity = (1.0e-2*np.exp(-((x-6.0e-4)/1.5e-4)**2))*duration_s
    opening = 3.0e9*np.exp(-((x-6.0e-4)/2.0e-4)**2)
    mean = 1.8e9*np.exp(-((x-6.0e-4)/2.5e-4)**2)
    return PhysicalIncrement(
        duration_s=duration_s, signed_load=1.0,
        equivalent_plastic_strain_increment=tuple(activity),
        forest_density_m2=tuple(np.full(len(x), 1.0e12)),
        mobile_density_m2=tuple(np.full(len(x), 1.0e10)),
        mean_stress_Pa=tuple(mean), opening_stress_Pa=tuple(opening),
        crack_surface_sink_rate_s=tuple(np.where(x < 4.0e-4, 0.1, 0.0)),
        fracture_cleavage_stress_Pa=float(np.max(opening)),
        fracture_emission_stress_Pa=float(np.max(opening)),
    )


def run_reference_case(*, steps: int = 1000, duration_s: float = 0.001) -> dict:
    if steps <= 0 or duration_s <= 0.0:
        raise ValueError("steps and duration must be positive")
    rows = _mechanism_rows()
    edges = tuple(np.linspace(0.0, 1.0e-3, 33))
    normalization = LineNormalization(
        edges, (1.0e-3,)*32, thickness_m=1.0,
        exterior_surface_multiplier=(2.0,)*32,
    )
    rng = np.random.default_rng(3621)
    sites = tuple(ReducedSiteState(
        site_id=f"site-{index+1}", x_m=x_m,
        support_half_width_m=5.0e-5,
        vacancy_thresholds=tuple(np.cumsum(rng.exponential(size=2))),
        direct_thresholds=tuple(np.cumsum(rng.exponential(size=3))),
    ) for index, x_m in enumerate((6.0e-4, 7.5e-4)))
    state = initialize_executable_state(
        no_void_upgrade(ReducedState()), normalization, rows, sites=sites,
        initial_vacancy_fraction=1.0e-10,
        initial_forest_density_m2=1.0e12, temperature_K=1200.0,
        fracture_process_row=_fracture_row(), fracture_front_origin_m=5.0e-4,
    )
    started = time.perf_counter()
    history = []
    for step in range(steps):
        state = advance_physical_time(state, _increment(state, duration_s))
        history.append({
            "step": step+1, "time_s": state.physical_time_s,
            "void_phase": {site.site_id: site.phase.value for site in state.sites},
            "radius_m": {site.site_id: site.radius_m for site in state.sites},
            "direct_action": {site.site_id: site.direct_action for site in state.sites},
            "direct_hits": {site.site_id: site.direct_hits for site in state.sites},
            "vacancy_action": {site.site_id: site.vacancy_action for site in state.sites},
            "owned_vacancy_area_m2": {
                site.site_id: (site.reserved_vacancy_area_m2
                               +site.vacancy_growth_area_m2
                               +site.captured_unaccommodated_vacancy_area_m2)
                for site in state.sites},
            "fracture_front_m": (state.fracture_front_origin_m
                                  +state.core.fracture_state.crack_extension_m),
            "fracture_extension_m": state.core.fracture_state.crack_extension_m,
            "event_count": len(state.event_history),
        })
    module_path = Path(__file__).resolve()
    try:
        version = metadata.version("arrhenius-fem-czm")
    except metadata.PackageNotFoundError:
        version = "not-installed"
    terminal = history[-1]
    return {
        "schema": "oneD.v3.installed-autonomous-reference/1",
        "case_id": CASE_ID,
        "classification": "AUTONOMOUS_REDUCED_FUNCTIONAL_CONTROL_NOT_CALIBRATED_2D_TRANSFER",
        "runtime": {
            "elapsed_s": time.perf_counter()-started,
            "full_FEM_calls": 0,
            "native_FEM_calls": 0,
            "module_origin": str(module_path),
            "module_sha256": hashlib.sha256(module_path.read_bytes()).hexdigest(),
            "distribution_version": version,
        },
        "configuration": {
            "steps": steps, "duration_s": duration_s,
            "temperature_K": 1200.0, "stochastic_seed": 3621,
            "mechanism_row_id": rows.row_id,
            "mechanism_row_fingerprint": rows.fingerprint,
            "fracture_row_id": state.fracture_process_row.candidate_id,
            "fracture_row_fingerprint": state.fracture_process_row.fingerprint,
            "mechanics": "DECLARED_ANALYTIC_MONOTONIC_FUNCTIONAL_CONTROL",
        },
        "history": history,
        "events": list(state.event_history),
        "terminal": terminal,
        "terminal_ledgers": asdict(state.ledgers),
        "termination_reason": "COMPLETED_DECLARED_MONOTONIC_TIME_WINDOW",
        "capability_limits": [
            "not a fitted aligned 2-D mechanics closure",
            "uses the reduced shared-barrier fracture owner, not the complete V2 PF adapter",
            "resolved multi-cavity topology is not qualified",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("oneD_v3_result.json"))
    parser.add_argument("--steps", type=int, default=1000)
    parser.add_argument("--duration-s", type=float, default=0.001)
    args = parser.parse_args(argv)
    result = run_reference_case(steps=args.steps, duration_s=args.duration_s)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print("ONED_V3_INSTALLED_AUTONOMOUS = PASS")
    print("CLASSIFICATION", result["classification"])
    print("TERMINATION_REASON", result["termination_reason"])
    print("FULL_FEM_CALLS", result["runtime"]["full_FEM_calls"])
    print("RESULT", args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
