"""State-owned adapter to the established full-order incremental physics.

This is deliberately a reference adapter, not a fast one-dimensional claim.
It retains the native accepted state in its ordinary atomic checkpoint and
projects observations into the V3 state only after native constitutive,
equilibrium, transport, growth, fracture, and event scheduling have committed.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
import time
from typing import Any

import numpy as np

from .compact_mechanics import CompactMechanicalState
from .compact_transport import project_compact_state
from .mechanics import MechanicsResponse, TopologyRegime


@dataclass(frozen=True)
class NativeIncrementalOwnerState:
    checkpoint_path: str
    accepted_state_fingerprint: str
    source_commit: str
    constitutive_call_count: int = 0
    full_equilibrium_solve_count: int = 0
    native_transport_solve_count: int = 0
    observer_call_count: int = 0
    retained_mechanics_element_count: int = 0
    retained_transport_element_count: int = 0
    retained_displacement_dof_count: int = 0
    schema: str = "oneD.v3.native-incremental-owner/1"


@dataclass(frozen=True)
class NativeIncrementalAdvanceAudit:
    opening_ratio: float
    duration_s: float
    same_start_fingerprint: str
    mechanical_fingerprint: str
    final_fingerprint: str
    constitutive_audit: dict[str, Any]
    scheduler_audit: dict[str, Any]
    mechanics: dict[str, float]
    vacancy_budget: dict[str, float]
    selected_events: tuple[Any, ...]
    wall_profile_s: dict[str, float]
    classification: str = "FULL_ORDER_NATIVE_REFERENCE_ADAPTER"


def _native_imports():
    from arrhenius_fracture.bulk_plasticity_v104 import (
        PlasticityScope, accepted_bulk_load_step)
    from arrhenius_fracture.checkpoint_v11 import restore_checkpoint, write_checkpoint
    from arrhenius_fracture.crack_network_v11 import ROOT_BRANCH_ID
    from arrhenius_fracture.embryo_growth_v1 import source_local_fem_tensors
    from arrhenius_fracture.global_physical_scheduler_v1 import (
        advance_global_physical_interval)
    from arrhenius_fracture.topology_transaction_v11 import (
        complete_accepted_state_fingerprint,
        equilibrate_fixed_load_with_production_fem)
    from arrhenius_fracture.vacancy_transport_phase_field_v2 import (
        _capture_weights, accepted_elastoplastic_stress_3d)
    from scripts.run_active_two_mechanism_natural_void_study import (
        canonical_drive_check)
    return locals()


def _mechanical_observables(state):
    eq=state.equilibrium_observables
    if eq is None:
        raise RuntimeError("native accepted state has no equilibrium observation")
    return {
        "top_reaction_N_per_m":float(eq.top_normal_resultant_N_per_m),
        "bottom_reaction_N_per_m":float(eq.bottom_normal_resultant_N_per_m),
        "mean_reaction_magnitude_N_per_m":float(eq.mean_reaction_magnitude_N_per_m),
        "compliance_m2_per_N":float(eq.compliance_m2_per_N),
        "recoverable_energy_J_per_m":float(eq.recoverable_elastic_energy_J_per_m),
        "total_internal_energy_J_per_m":float(eq.total_stored_internal_energy_J_per_m)}


def initialize_native_incremental_owner(checkpoint_path: str | Path):
    api=_native_imports(); path=Path(checkpoint_path).resolve()
    state=api["restore_checkpoint"](path)
    fingerprint=api["complete_accepted_state_fingerprint"](state)
    support=state.v12_support_state
    return NativeIncrementalOwnerState(
        str(path),fingerprint,str(support.source_commit),
        retained_mechanics_element_count=int(state.mesh.ne),
        retained_transport_element_count=int(
            state.vacancy_transport_state_v2.transport_mesh.ne),
        retained_displacement_dof_count=int(np.asarray(state.displacement).size))


def observe_same_native_state(owner: NativeIncrementalOwnerState) -> dict[str, Any]:
    """Re-equilibrate without time advance and report reconstruction error."""
    api=_native_imports(); state=api["restore_checkpoint"](owner.checkpoint_path)
    if api["complete_accepted_state_fingerprint"](state) != owner.accepted_state_fingerprint:
        raise RuntimeError("native owner checkpoint fingerprint mismatch")
    before=_mechanical_observables(state)
    stress_before=api["accepted_elastoplastic_stress_3d"](state)
    source_before={item.site_id:api["source_local_fem_tensors"](state,item)
                   for item in state.void_state.embryo_growth_states}
    wall=time.perf_counter()
    observed=api["equilibrate_fixed_load_with_production_fem"](state)
    elapsed=time.perf_counter()-wall
    after=_mechanical_observables(observed)
    stress_after=api["accepted_elastoplastic_stress_3d"](observed)
    source_after={item.site_id:api["source_local_fem_tensors"](observed,item)
                  for item in observed.void_state.embryo_growth_states}
    keys=("top_reaction_N_per_m","bottom_reaction_N_per_m",
          "compliance_m2_per_N","recoverable_energy_J_per_m",
          "total_internal_energy_J_per_m")
    relative={key:abs(float(after[key])-float(before[key]))/
              max(abs(float(before[key])),1.0e-300) for key in keys}
    relative["mean_stress_field_l2"]=(
        float(np.linalg.norm(np.asarray(stress_after["mean_stress_Pa"])
                             -np.asarray(stress_before["mean_stress_Pa"])))
        /max(float(np.linalg.norm(stress_before["mean_stress_Pa"])),1.0e-300))
    relative["opening_stress_field_l2"]=(
        float(np.linalg.norm(np.asarray(stress_after["sigma_yy_Pa"])
                             -np.asarray(stress_before["sigma_yy_Pa"])))
        /max(float(np.linalg.norm(stress_before["sigma_yy_Pa"])),1.0e-300))
    for site_id in source_before:
        tensor_before,zz_before=source_before[site_id]
        tensor_after,zz_after=source_after[site_id]
        relative[f"{site_id}_source_tensor_l2"]=(float(np.linalg.norm(
            np.asarray(tensor_after)-np.asarray(tensor_before)))
            /max(float(np.linalg.norm(tensor_before)),1.0e-300))
        relative[f"{site_id}_source_sigma_zz_l2"]=(float(np.linalg.norm(
            np.asarray(zz_after)-np.asarray(zz_before)))
            /max(float(np.linalg.norm(zz_before)),1.0e-300))
    return {"checkpoint":owner.checkpoint_path,"relative_errors":relative,
            "wall_time_s":elapsed,"before":before,"after":after}


def _at_opening(state, opening_m: float, equilibrate):
    displacement=np.asarray(state.displacement,float).copy()
    top,bottom=0.5*float(opening_m),-0.5*float(opening_m)
    displacement[2*np.asarray(state.boundary.top_nodes,int)+1]=top
    displacement[2*np.asarray(state.boundary.bot_nodes,int)+1]=bottom
    displacement[2*int(state.boundary.left_bot)+1]=bottom
    return equilibrate(replace(state,displacement=displacement))


def _budget(before, after):
    keys=("plastic_production_area_m2","dislocation_climb_annihilation_area_m2",
          "dislocation_climb_emission_area_m2","external_surface_absorption_area_m2",
          "crack_surface_absorption_area_m2","subgrid_capture_area_m2",
          "reserved_embryo_inventory_area_m2","active_cavity_inventory_area_m2")
    first=before.vacancy_transport_state_v2.ledgers
    second=after.vacancy_transport_state_v2.ledgers
    return {key:float(second[key]-first[key]) for key in keys}


def _project_native_into_reduced(reduced, native, response, api):
    """Publish native accepted fields without making the projection an owner."""
    from .conservative_projection import triangle_compartment_overlap_areas
    from .physical import LineFields, LineLedgers, SitePhase
    from .production_growth_adapter import HybridEmissionSourceState
    old=reduced.compact_transport_state
    if old is None:
        raise RuntimeError("native adapter requires a declared compact observation grid")
    transport=native.vacancy_transport_state_v2; mesh=transport.transport_mesh
    parent=np.asarray(transport.parent_mechanics_element_ids,int)
    stress=api["accepted_elastoplastic_stress_3d"](native)
    ep=np.sqrt(native.ep_gp[0]**2+native.ep_gp[1]**2+2.0*native.ep_gp[2]**2)
    capture={site.site_id:api["_capture_weights"](mesh,site)
             for site in transport.site_states}
    compact=project_compact_state(
        nodes_xy_m=np.asarray(mesh.nodes),elements=np.asarray(mesh.elems),
        axial_edges_m=np.asarray(old.axial_edges_m),
        transverse_edges_m=np.asarray(old.transverse_edges_m),
        fields_by_name={
            "vacancy_fraction":np.asarray(transport.vacancy_fraction_gp),
            "equivalent_plastic_strain":ep[parent],
            "forest_density_m2":np.asarray(native.rho_gp)[parent],
            "mobile_density_m2":np.zeros(mesh.ne),
            "mean_stress_Pa":np.asarray(stress["mean_stress_Pa"])[parent],
            "opening_stress_Pa":np.asarray(stress["sigma_yy_Pa"])[parent]},
        boundary_faces=transport.surface_registry.faces,
        capture_weights_by_site=capture,
        crack_tip_m=float(transport.surface_registry.crack_physical_length_m),
        initialization_identity="NATIVE_ACCEPTED_STATE_OBSERVATION")
    compact=replace(
        compact,rt0_diffusion_operator_factor=old.rt0_diffusion_operator_factor,
        rt0_consistent_mass_m2=old.rt0_consistent_mass_m2,
        rt0_exterior_flux_response=old.rt0_exterior_flux_response,
        rt0_crack_flux_response=old.rt0_crack_flux_response)
    overlap=triangle_compartment_overlap_areas(
        np.asarray(mesh.nodes),np.asarray(mesh.elems),
        np.asarray(old.axial_edges_m),np.asarray(old.transverse_edges_m))
    flat=overlap.reshape((-1,overlap.shape[-1])); area=np.asarray(compact.solid_area_m2)
    plastic=np.column_stack(tuple(
        flat@np.asarray(native.ep_gp[index])[parent]/area for index in range(3)))
    mechanical=CompactMechanicalState(
        tuple(map(tuple,plastic)),tuple(map(tuple,np.zeros_like(plastic))),
        compact.mean_stress_Pa,compact.opening_stress_Pa,compact.solid_area_m2,
        "NATIVE_ACCEPTED_SIGNED_TENSOR_OBSERVATION")
    line=lambda values:compact.line_average(values)
    fields=LineFields(
        tuple(line(compact.equivalent_plastic_strain)),
        tuple(line(compact.forest_density_m2)),tuple(line(compact.mobile_density_m2)),
        tuple(line(compact.vacancy_fraction)),tuple(line(compact.mean_stress_Pa)),
        tuple(line(compact.opening_stress_Pa)),
        reduced.fields.loop_deposited_forest_density_m2)
    growth={item.site_id:item for item in native.void_state.embryo_growth_states}
    sites=[]
    for site in reduced.sites:
        item=growth[site.site_id]
        sources=tuple(HybridEmissionSourceState(
            source.source_id,source.orientation_rad,source.random_measure_seed,
            source.available_fraction,source.integrated_action,
            source.realized_loop_count,source.continuum_moment_loop_count,
            source.availability_flow_regime,source.regime_epoch)
            for source in item.cavity_emission_state.sources)
        sites.append(replace(
            site,phase=SitePhase.STABLE,radius_m=item.radius_m,
            vacancy_growth_area_m2=item.vacancy_derived_area_m2,
            captured_unaccommodated_vacancy_area_m2=(
                item.captured_unaccommodated_vacancy_area_m2),
            emission_growth_area_m2=item.dislocation_derived_area_m2,
            emitted_loop_count=item.emitted_loop_count_effective,
            emission_sources=sources,
            emission_source_availability=tuple(x.available_fraction for x in sources),
            realized_emitted_loop_count=sum(x.realized_loop_count for x in sources),
            continuum_moment_loop_count=sum(x.continuum_moment_loop_count for x in sources),
            growth_representation=item.representation,
            retained_loop_count_effective=item.retained_loop_count_effective,
            escaped_loop_count_effective=item.escaped_loop_count_effective,
            cumulative_emitted_burgers_m=item.cumulative_emitted_burgers_m))
    native_ledger=transport.ledgers
    field_inventory=float(np.dot(np.asarray(mesh.area_e),
                                 np.asarray(transport.vacancy_fraction_gp)))
    crack_exchange=float(native_ledger["crack_surface_absorption_area_m2"])
    exterior_exchange=float(native_ledger["external_surface_absorption_area_m2"])
    ledgers=LineLedgers(
        initial_field_inventory_area_m2=field_inventory,
        plastic_source_area_m2=float(native_ledger["plastic_production_area_m2"]),
        climb_loss_area_m2=float(native_ledger["dislocation_climb_annihilation_area_m2"]),
        climb_emission_area_m2=float(native_ledger["dislocation_climb_emission_area_m2"]),
        exterior_loss_area_m2=max(exterior_exchange,0.0),
        exterior_gain_area_m2=max(-exterior_exchange,0.0),
        crack_surface_loss_area_m2=max(crack_exchange,0.0),
        crack_surface_gain_area_m2=max(-crack_exchange,0.0),
        site_capture_area_m2=float(native_ledger["subgrid_capture_area_m2"]),
        cavity_vacancy_area_m2=float(
            native_ledger["subgrid_cavity_inventory_area_m2"]
            +native_ledger["active_cavity_inventory_area_m2"]),
        cavity_emission_area_m2=float(sum(
            item.dislocation_derived_area_m2 for item in growth.values())),
        site_reserved_area_m2=float(native_ledger["reserved_embryo_inventory_area_m2"]),
        site_unaccommodated_area_m2=float(sum(
            item.captured_unaccommodated_vacancy_area_m2 for item in growth.values())))
    time_s=float(transport.transport_time_s)
    return replace(
        reduced,fields=fields,sites=tuple(sites),ledgers=ledgers,
        compact_transport_state=compact,
        compact_mechanical_state=mechanical,last_mechanics_response=response,
        physical_time_s=time_s,
        core=replace(reduced.core,fracture_state=replace(
            reduced.core.fracture_state,time_s=time_s)))


def synchronize_reduced_to_native_owner(reduced):
    """Initialize reduced observations from the owner's exact accepted state."""
    api=_native_imports(); owner=reduced.native_incremental_owner_state
    if owner is None:
        raise RuntimeError("native incremental owner is not configured")
    native=api["restore_checkpoint"](owner.checkpoint_path)
    if api["complete_accepted_state_fingerprint"](native) != owner.accepted_state_fingerprint:
        raise RuntimeError("native incremental owner fingerprint mismatch")
    mechanics=_mechanical_observables(native)
    response=MechanicsResponse(
        TopologyRegime.PRECONNECTION,None,None,
        float(mechanics["compliance_m2_per_N"]),
        float(mechanics["recoverable_energy_J_per_m"]),
        (owner.checkpoint_path,),"FULL_ORDER_NATIVE_SAME_STATE_OBSERVATION")
    return _project_native_into_reduced(reduced,native,response,api)


def advance_native_incremental_physics(
    reduced, *, opening_ratio: float, duration_s: float, temperature_K: float,
    baseline_opening_m: float, output_checkpoint_path: str | Path,
):
    """Execute one connected interval with the existing production owners."""
    api=_native_imports(); owner=reduced.native_incremental_owner_state
    if owner is None:
        raise RuntimeError("native incremental owner is not configured")
    native=api["restore_checkpoint"](owner.checkpoint_path)
    fingerprint=api["complete_accepted_state_fingerprint"](native)
    if fingerprint != owner.accepted_state_fingerprint:
        raise RuntimeError("native incremental owner fingerprint mismatch")
    wall=time.perf_counter(); equilibrium_wall=time.perf_counter()
    stepped=_at_opening(native,baseline_opening_m*opening_ratio,
                        api["equilibrate_fixed_load_with_production_fem"])
    opening_equilibrium_s=time.perf_counter()-equilibrium_wall
    mechanical,plastic=api["accepted_bulk_load_step"](
        stepped,scope=api["PlasticityScope"].FULL_FIELD_PT_EVOLVING_RHO,
        load_factor=1.0,duration_s=duration_s,temperature_K=temperature_K,
        maximum_stagger_iterations=80)
    tensor,K,canonical,load_rows=api["canonical_drive_check"](mechanical)
    scheduler_wall=time.perf_counter()
    final,scheduler=api["advance_global_physical_interval"](
        stepped,mechanical,duration_s,
        {"kind":"hold","temperature_K":temperature_K,
         "stress_tensor_Pa":tensor,
         "K_effective_by_front":{api["ROOT_BRANCH_ID"]:K},
         "directional_load_rows_by_front":{api["ROOT_BRANCH_ID"]:load_rows},
         "maximum_events":64})
    scheduler_s=time.perf_counter()-scheduler_wall
    destination=Path(output_checkpoint_path).resolve()
    api["write_checkpoint"](final,destination,compression="gzip")
    final_fingerprint=api["complete_accepted_state_fingerprint"](final)
    mechanics=_mechanical_observables(mechanical)
    available=next(row for row in canonical["canonical_directional_rows"]
                   if row["directional_drive_status"] == "AVAILABLE")
    response=MechanicsResponse(
        TopologyRegime.PRECONNECTION,
        float(available["G_kinetic_used_J_per_m2"]),None,
        float(mechanics["compliance_m2_per_N"]),
        float(mechanics["recoverable_energy_J_per_m"]),
        (str(destination),),"FULL_ORDER_NATIVE_INCREMENTAL_PHYSICS")
    updated=_project_native_into_reduced(reduced,final,response,api)
    selected=tuple(event["selected_event"] for event in scheduler.get("events",())
                   if event.get("selected_event") is not None)
    native_events=tuple({"event":event,"owner":"FULL_ORDER_NATIVE_SCHEDULER",
                         "physical_time_s":updated.physical_time_s}
                        for event in selected)
    transport_iterations=sum(
        int(event.get("transport",{}).get("nonlinear_iteration_count",0))
        for event in scheduler.get("events",()))
    new_owner=replace(
        owner,checkpoint_path=str(destination),
        accepted_state_fingerprint=final_fingerprint,
        constitutive_call_count=owner.constitutive_call_count+1,
        full_equilibrium_solve_count=(owner.full_equilibrium_solve_count
                                      +1+int(plastic["stagger_iterations"])),
        native_transport_solve_count=owner.native_transport_solve_count+max(
            1,len(scheduler.get("events",()))),
        observer_call_count=owner.observer_call_count+1)
    updated=replace(updated,native_incremental_owner_state=new_owner,
                    event_history=reduced.event_history+native_events)
    audit=NativeIncrementalAdvanceAudit(
        float(opening_ratio),float(duration_s),fingerprint,
        api["complete_accepted_state_fingerprint"](mechanical),final_fingerprint,
        plastic,dict(scheduler),mechanics,_budget(stepped,final),
        selected,
        {"opening_equilibrium":opening_equilibrium_s,
         "constitutive_and_stagger":plastic["wall_profile_s"][
             "accepted_bulk_load_step_total"],
         "scheduler_transport_growth":scheduler_s,
         "total":time.perf_counter()-wall,
         "transport_nonlinear_iterations":float(transport_iterations)})
    return updated,audit


__all__=["NativeIncrementalAdvanceAudit","NativeIncrementalOwnerState",
         "advance_native_incremental_physics","initialize_native_incremental_owner",
         "observe_same_native_state","synchronize_reduced_to_native_owner"]
