"""Conservative P0 triangle-to-line projection for reduced transport.

The overlap is geometric: every triangle is clipped against every intersected
line strip.  Consequently the projected solid measure and every extensive P0
quantity close to roundoff even on cut, skew, or locally refined meshes.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np


def _clip_axis(
    polygon: np.ndarray, bound: float, keep_greater: bool, axis: int,
) -> np.ndarray:
    if len(polygon) == 0:
        return polygon
    result: list[np.ndarray] = []
    previous = polygon[-1]
    previous_inside = ((previous[axis] >= bound) if keep_greater
                       else (previous[axis] <= bound))
    for current in polygon:
        current_inside = ((current[axis] >= bound) if keep_greater
                          else (current[axis] <= bound))
        if current_inside != previous_inside:
            fraction = (bound-previous[axis])/(current[axis]-previous[axis])
            result.append(previous+fraction*(current-previous))
        if current_inside:
            result.append(current)
        previous, previous_inside = current, current_inside
    return np.asarray(result, float).reshape((-1, 2))


def _clip_x(polygon: np.ndarray, bound: float, keep_greater: bool) -> np.ndarray:
    return _clip_axis(polygon, bound, keep_greater, 0)


def _clip_y(polygon: np.ndarray, bound: float, keep_greater: bool) -> np.ndarray:
    return _clip_axis(polygon, bound, keep_greater, 1)


def _polygon_area(polygon: np.ndarray) -> float:
    if len(polygon) < 3:
        return 0.0
    return 0.5*abs(float(np.dot(polygon[:, 0], np.roll(polygon[:, 1], -1))
                         -np.dot(polygon[:, 1], np.roll(polygon[:, 0], -1))))


def triangle_strip_overlap_areas(
    nodes_xy_m: np.ndarray, elements: np.ndarray, line_edges_m: np.ndarray,
) -> np.ndarray:
    """Return ``[line cell, triangle]`` intersection areas in square metres."""
    nodes = np.asarray(nodes_xy_m, float)
    elems = np.asarray(elements, int)
    edges = np.asarray(line_edges_m, float)
    if (nodes.ndim != 2 or nodes.shape[1] != 2 or elems.ndim != 2
            or elems.shape[1] != 3 or len(edges) < 2
            or np.any(np.diff(edges) <= 0.0)):
        raise ValueError("invalid triangle mesh or line grid")
    overlap = np.zeros((len(edges)-1, len(elems)))
    for eid, triangle in enumerate(nodes[elems]):
        first = max(int(np.searchsorted(edges, np.min(triangle[:, 0]), side="right")-1), 0)
        last = min(int(np.searchsorted(edges, np.max(triangle[:, 0]), side="left")), len(edges)-2)
        for cell in range(first, last+1):
            clipped = _clip_x(triangle, edges[cell], True)
            clipped = _clip_x(clipped, edges[cell+1], False)
            overlap[cell, eid] = _polygon_area(clipped)
    return overlap


def triangle_compartment_overlap_areas(
    nodes_xy_m: np.ndarray, elements: np.ndarray, line_edges_m: np.ndarray,
    transverse_edges_m: np.ndarray,
) -> np.ndarray:
    """Return ``[x cell, y compartment, triangle]`` exact overlap areas."""
    nodes = np.asarray(nodes_xy_m, float)
    elems = np.asarray(elements, int)
    x_edges = np.asarray(line_edges_m, float)
    y_edges = np.asarray(transverse_edges_m, float)
    if (nodes.ndim != 2 or nodes.shape[1] != 2 or elems.ndim != 2
            or elems.shape[1] != 3 or len(x_edges) < 2 or len(y_edges) < 2
            or np.any(np.diff(x_edges) <= 0.0)
            or np.any(np.diff(y_edges) <= 0.0)):
        raise ValueError("invalid triangle mesh or compartment grid")
    overlap = np.zeros((len(x_edges)-1, len(y_edges)-1, len(elems)))
    for eid, triangle in enumerate(nodes[elems]):
        x_first = max(int(np.searchsorted(
            x_edges, np.min(triangle[:, 0]), side="right")-1), 0)
        x_last = min(int(np.searchsorted(
            x_edges, np.max(triangle[:, 0]), side="left")), len(x_edges)-2)
        y_first = max(int(np.searchsorted(
            y_edges, np.min(triangle[:, 1]), side="right")-1), 0)
        y_last = min(int(np.searchsorted(
            y_edges, np.max(triangle[:, 1]), side="left")), len(y_edges)-2)
        for ix in range(x_first, x_last+1):
            clipped_x = _clip_x(triangle, x_edges[ix], True)
            clipped_x = _clip_x(clipped_x, x_edges[ix+1], False)
            for iy in range(y_first, y_last+1):
                clipped = _clip_y(clipped_x, y_edges[iy], True)
                clipped = _clip_y(clipped, y_edges[iy+1], False)
                overlap[ix, iy, eid] = _polygon_area(clipped)
    return overlap


@dataclass(frozen=True)
class ConservativeLineProjection:
    overlap_area_m2: np.ndarray
    geometric_cell_area_m2: np.ndarray

    def __post_init__(self) -> None:
        overlap = np.asarray(self.overlap_area_m2, float)
        geometric = np.asarray(self.geometric_cell_area_m2, float)
        if (overlap.ndim != 2 or geometric.shape != (overlap.shape[0],)
                or np.any(overlap < 0.0) or np.any(geometric <= 0.0)):
            raise ValueError("invalid conservative projection measures")
        if np.any(np.sum(overlap, axis=1) <= 0.0):
            raise ValueError("every reduced cell must overlap accepted solid")

    @property
    def solid_area_m2(self) -> np.ndarray:
        return np.sum(self.overlap_area_m2, axis=1)

    @property
    def solid_fraction(self) -> np.ndarray:
        value = self.solid_area_m2/self.geometric_cell_area_m2
        if np.any(value > 1.0+2.0e-12):
            raise RuntimeError("triangle strips overlap more than the reduced cell measure")
        return np.minimum(value, 1.0)

    def intensive(self, element_values: np.ndarray) -> np.ndarray:
        values = np.asarray(element_values, float)
        if values.shape != (self.overlap_area_m2.shape[1],):
            raise ValueError("P0 field must own one value per triangle")
        return self.overlap_area_m2@values/self.solid_area_m2

    def extensive_density(self, element_values: np.ndarray) -> np.ndarray:
        """Density on geometric cells; its line integral equals the 2-D integral."""
        values = np.asarray(element_values, float)
        if values.shape != (self.overlap_area_m2.shape[1],):
            raise ValueError("P0 field must own one value per triangle")
        return self.overlap_area_m2@values/self.geometric_cell_area_m2

    def conservation_error(self, element_values: np.ndarray, projected: np.ndarray) -> float:
        source = math.fsum(float(x) for x in self.overlap_area_m2@np.asarray(element_values, float))
        target = float(np.dot(self.solid_area_m2, np.asarray(projected, float)))
        return target-source


__all__ = [
    "ConservativeLineProjection", "triangle_compartment_overlap_areas",
    "triangle_strip_overlap_areas",
]
