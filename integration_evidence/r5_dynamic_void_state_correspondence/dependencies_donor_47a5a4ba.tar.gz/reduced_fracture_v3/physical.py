"""Executable conservative line reduction for stateful two-mechanism voiding.

This module reduces spatial transport and mechanics inputs, not the physical
owners.  Vacancy clustering and direct interaction keep distinct actions and
inventories; vacancy absorption and loop emission keep distinct growth ledgers.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
import hashlib
import json
import math
from typing import Callable, Mapping, Sequence

import numpy as np

from .mechanics import MechanicsResponse, TopologyRegime
from .state import (
    HazardClock, LengthLedgers, MechanicsRepresentation, OneDStateV3,
    OneDVoidState, VoidPhase,
)
from reduced_fracture_v2.parameters import CanonicalParameters
from reduced_fracture_v2.kinetics import SharedBarrierHazardCore
from .production_growth_adapter import (
    HEALED_AVAILABLE_SITE, RESIDUAL_LOOP_BEARING_DEFECT,
    HybridEmissionSourceState, advance_sources, initialize_sources,
    next_exact_crossing_time, production_healing_representation,
    production_series_limited_vacancy_rate,
)
from .fracture_adapter import (
    ReducedMechanicsDriveBinding, V2FractureOwnerState, commit_v2_fracture_preview,
    first_v2_fracture_event_time, preview_v2_fracture_interval,
    project_v2_fracture_state,
)
from .compact_transport import (
    CompactTransportIncrement, CompactTransportResult, CompactTransportState,
    advance_compact_transport,
)
from .compact_mechanics import (
    CompactMechanicalIncrement, CompactMechanicalState, advance_compact_mechanics,
)
from .native_incremental_adapter import NativeIncrementalOwnerState


KB = 1.380649e-23
EV_J = 1.602176634e-19
SCHEMA = "oneD.v3.physical-line-voiding/1"


class SitePhase(str, Enum):
    AVAILABLE = "AVAILABLE_SITE"
    EMBRYO = "EMBRYO"
    STABLE = "STABLE_SUBGRID_VOID"
    RESOLVED = "RESOLVED_VOID"
    CONNECTED = "CONNECTED_VOID"
    CHILD = "DOWNSTREAM_FRONT_ACTIVE"
    HEALED = "HEALED_SITE"


@dataclass(frozen=True)
class FractureProcessRow:
    """State-owned adapter configuration for the existing V2 hazard core."""
    candidate_id: str
    parameter_values: tuple[tuple[str, float], ...]
    cleavage_advance_m: float
    threshold_policy: str = "REUSE_STATE_OWNED_THRESHOLD"

    def __post_init__(self) -> None:
        if not self.candidate_id or self.cleavage_advance_m <= 0.0:
            raise ValueError("fracture process identity and advance are required")
        if self.threshold_policy != "REUSE_STATE_OWNED_THRESHOLD":
            raise ValueError("unsupported fracture threshold policy")

    @classmethod
    def from_parameters(cls, parameters: CanonicalParameters, *, cleavage_advance_m: float):
        return cls(parameters.candidate_id, tuple(sorted(
            (str(key), float(value)) for key, value in parameters.values.items()
        )), float(cleavage_advance_m))

    @property
    def parameters(self) -> CanonicalParameters:
        return CanonicalParameters(self.candidate_id, dict(self.parameter_values))

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(
            self.__dict__, sort_keys=True, separators=(",", ":"),
        ).encode()).hexdigest()


@dataclass(frozen=True)
class LineNormalization:
    cell_edges_m: tuple[float, ...]
    transverse_width_m: tuple[float, ...]
    thickness_m: float = 1.0
    exterior_surface_multiplier: tuple[float, ...] = ()
    # Fraction of each rectangular line cell that is accepted solid.  This is
    # normally one.  A conservative projection of a cut 2-D transport mesh
    # supplies the actual strip measure so crack/cavity area is not silently
    # recreated as vacancy-bearing material in the reduction.
    solid_fraction: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        edges = np.asarray(self.cell_edges_m, float)
        width = np.asarray(self.transverse_width_m, float)
        if len(edges) < 2 or np.any(~np.isfinite(edges)) or np.any(np.diff(edges) <= 0.0):
            raise ValueError("line cell edges must be finite and strictly increasing")
        if width.shape != (len(edges)-1,) or np.any(width <= 0.0):
            raise ValueError("every line cell requires a positive transverse width")
        if not math.isfinite(self.thickness_m) or self.thickness_m <= 0.0:
            raise ValueError("line-model thickness must be finite and positive")
        if self.exterior_surface_multiplier:
            surface = np.asarray(self.exterior_surface_multiplier, float)
            if surface.shape != width.shape or np.any(surface < 0.0):
                raise ValueError("exterior surface multipliers must be nonnegative per-cell data")
        if self.solid_fraction:
            solid = np.asarray(self.solid_fraction, float)
            if (solid.shape != width.shape or np.any(~np.isfinite(solid))
                    or np.any(solid <= 0.0) or np.any(solid > 1.0+1.0e-12)):
                raise ValueError("solid fractions must lie in (0,1] per line cell")

    @property
    def cell_lengths_m(self) -> np.ndarray:
        return np.diff(np.asarray(self.cell_edges_m, float))

    @property
    def cell_areas_m2(self) -> np.ndarray:
        area = self.cell_lengths_m*np.asarray(self.transverse_width_m, float)
        solid = getattr(self, "solid_fraction", ())
        return area*(np.asarray(solid, float) if solid else 1.0)

    @property
    def geometric_cell_areas_m2(self) -> np.ndarray:
        return self.cell_lengths_m*np.asarray(self.transverse_width_m, float)

    @property
    def centers_m(self) -> np.ndarray:
        edge = np.asarray(self.cell_edges_m, float)
        return 0.5*(edge[:-1]+edge[1:])


@dataclass(frozen=True)
class TwoMechanismRows:
    row_id: str
    atomic_volume_m3: float
    vacancy_formation_volume_m3: float
    vacancy_diffusivity_m2_s: float
    vacancy_stress_coupling_volume_m3: float
    plastic_vacancy_coefficient_per_strain: float
    climb_sink_rate_s: float
    exterior_sink_efficiency: float
    site_capture_factor: float
    vacancy_birth_barrier_J: float
    vacancy_hit_area_m2: float
    vacancy_required_hits: int
    direct_geometry_factor: float
    taylor_factor: float
    burgers_m: float
    direct_success_fraction: float
    direct_barrier_eV: float
    direct_activation_volume_m3: float
    direct_hit_area_m2: float
    direct_required_hits: int
    stabilization_rate_s: float
    healing_rate_s: float
    emission_attempt_frequency_s: float
    emission_barrier_J: float
    emission_stress_volume_m3: float
    emission_area_per_loop_m2: float
    emission_surface_source_density_per_m: float = 2.0e8
    emission_source_count: int = 3
    emission_critical_stress_Pa: float = 3.0e9
    emission_barrier_exp_a: float = 1.0
    emission_barrier_exp_n: float = 1.0
    emission_barrier_floor_fraction: float = 0.05
    emission_barrier_floor_min_J: float = 1.0e-23
    emission_surface_energy_J_m2: float = 2.5
    emission_chi_loop: float = 0.25
    emission_depletion_per_loop: float = 0.02
    emission_recovery_rate_s: float = 1.0e-3
    emission_low_count_mu_max: float = 0.25
    emission_continuum_mu_min: float = 25.0
    emission_maximum_packet_area_fraction: float = 0.02
    emission_model_thickness_m: float = 1.0
    emission_retained_loop_fraction: float = 0.8
    emission_escaped_loop_fraction: float = 0.2
    lifecycle_attempt_frequency_s: float | None = None
    stabilization_barrier_J: float | None = None
    healing_barrier_J: float | None = None
    stabilization_activation_volume_m3: float = 0.0
    healing_activation_volume_m3: float = 0.0
    vacancy_formation_energy_eV: float = 3.2
    vacancy_formation_entropy_over_kB: float = 0.0
    vacancy_migration_energy_eV: float = 1.7
    vacancy_diffusivity_prefactor_m2_s: float = 1.0e-6
    dislocation_production_boost: float = 0.20
    interaction_mobile_vacancy_fraction: float = 1.0
    interaction_direct_cavitation_fraction: float = 0.0
    interaction_benign_fraction: float = 0.0
    dislocation_climb_capture_efficiency: float = 1.0
    rho_reference_m2: float = 1.0e12
    bulk_accommodation_coefficient: float = 1.0
    calibration_status: str = "PROSPECTIVE_UNCALIBRATED_HYPOTHESIS"

    def __post_init__(self) -> None:
        if not self.row_id or self.calibration_status not in {
            "REFERENCE_UNCALIBRATED", "PROSPECTIVE_UNCALIBRATED_HYPOTHESIS"
        }:
            raise ValueError("mechanism row requires explicit uncalibrated identity")
        positive = (
            self.atomic_volume_m3, self.vacancy_formation_volume_m3,
            self.vacancy_diffusivity_m2_s, self.vacancy_hit_area_m2,
            self.direct_geometry_factor, self.taylor_factor, self.burgers_m,
            self.direct_barrier_eV, self.direct_activation_volume_m3,
            self.direct_hit_area_m2, self.emission_attempt_frequency_s,
            self.emission_barrier_J, self.emission_stress_volume_m3,
            self.emission_area_per_loop_m2,
        )
        if any(not math.isfinite(float(value)) or float(value) <= 0.0 for value in positive):
            raise ValueError("physical mechanism parameters must be finite and positive")
        if not 0.0 <= self.direct_success_fraction <= 1.0:
            raise ValueError("direct successful-outcome fraction must lie in [0,1]")
        if self.vacancy_required_hits <= 0 or self.direct_required_hits <= 0:
            raise ValueError("both mechanisms require positive hit counts")
        partition = math.fsum((
            self.interaction_mobile_vacancy_fraction,
            self.interaction_direct_cavitation_fraction,
            self.interaction_benign_fraction,
        ))
        if not math.isclose(partition, 1.0, rel_tol=0.0, abs_tol=1.0e-12):
            raise ValueError("interaction outcome fractions must form a unit partition")
        if self.rho_reference_m2 <= 0.0 or self.vacancy_diffusivity_prefactor_m2_s <= 0.0:
            raise ValueError("vacancy transport reference scales must be positive")
        if self.emission_model_thickness_m <= 0.0 or not math.isclose(
            self.emission_retained_loop_fraction+self.emission_escaped_loop_fraction,
            1.0, rel_tol=0.0, abs_tol=1.0e-12,
        ):
            raise ValueError("production emission projection parameters are invalid")
        lifecycle = (
            self.lifecycle_attempt_frequency_s,
            self.stabilization_barrier_J,
            self.healing_barrier_J,
        )
        if any(value is not None for value in lifecycle):
            if (any(value is None for value in lifecycle)
                    or any(float(value) <= 0.0 for value in lifecycle)
                    or self.stabilization_activation_volume_m3 < 0.0
                    or self.healing_activation_volume_m3 < 0.0):
                raise ValueError("production lifecycle parameters are incomplete")

    @property
    def inventory_ratio(self) -> float:
        return self.vacancy_formation_volume_m3/self.atomic_volume_m3

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(
            self.__dict__, sort_keys=True, separators=(",", ":"),
        ).encode()).hexdigest()


@dataclass(frozen=True)
class ReducedSiteState:
    site_id: str
    x_m: float
    support_half_width_m: float
    vacancy_thresholds: tuple[float, ...]
    direct_thresholds: tuple[float, ...]
    phase: SitePhase = SitePhase.AVAILABLE
    vacancy_action: float = 0.0
    vacancy_hits: int = 0
    reserved_vacancy_area_m2: float = 0.0
    direct_action: float = 0.0
    direct_hits: int = 0
    direct_free_volume_area_m2: float = 0.0
    stabilization_action: float = 0.0
    healing_action: float = 0.0
    stabilization_threshold: float = 1.0
    healing_threshold: float = 1.0
    radius_m: float | None = None
    vacancy_growth_area_m2: float = 0.0
    captured_unaccommodated_vacancy_area_m2: float = 0.0
    emission_growth_area_m2: float = 0.0
    emitted_loop_count: float = 0.0
    emission_source_availability: tuple[float, ...] = (1.0, 1.0, 1.0)
    emission_sources: tuple[HybridEmissionSourceState, ...] = ()
    realized_emitted_loop_count: int = 0
    continuum_moment_loop_count: float = 0.0
    emission_packet_count: int = 0
    growth_representation: str | None = None
    retained_loop_count_effective: float = 0.0
    escaped_loop_count_effective: float = 0.0
    cumulative_emitted_burgers_m: float = 0.0
    deposited_plastic_strain_integral_m2: float = 0.0
    deposited_dislocation_line_length_m: float = 0.0

    def __post_init__(self) -> None:
        if not self.site_id or self.support_half_width_m <= 0.0:
            raise ValueError("site identity and support are required")
        if any(value <= 0.0 for value in self.vacancy_thresholds+self.direct_thresholds):
            raise ValueError("stochastic thresholds must be positive")
        if tuple(sorted(self.vacancy_thresholds)) != self.vacancy_thresholds:
            raise ValueError("vacancy thresholds must be cumulative and ordered")
        if tuple(sorted(self.direct_thresholds)) != self.direct_thresholds:
            raise ValueError("direct thresholds must be cumulative and ordered")
        if self.radius_m is not None and self.radius_m <= 0.0:
            raise ValueError("cavity radius must be positive")
        if self.stabilization_threshold <= 0.0 or self.healing_threshold <= 0.0:
            raise ValueError("lifecycle thresholds must be positive")
        if any(not 0.0 <= value <= 1.0 for value in self.emission_source_availability):
            raise ValueError("emission source availability must lie in [0,1]")
        if self.emission_sources and len(self.emission_sources) != len(
                self.emission_source_availability):
            raise ValueError("emission source owners and availability disagree")
        effective = self.realized_emitted_loop_count+self.continuum_moment_loop_count
        if not math.isclose(self.emitted_loop_count, effective,
                            rel_tol=1.0e-12, abs_tol=1.0e-12):
            raise ValueError("realized and continuum emission ledgers do not close")
        if any(value < 0.0 for value in (
            self.retained_loop_count_effective,
            self.escaped_loop_count_effective,
            self.cumulative_emitted_burgers_m,
            self.deposited_plastic_strain_integral_m2,
            self.deposited_dislocation_line_length_m,
        )):
            raise ValueError("loop-derived mechanics ledgers must be nonnegative")

    @property
    def total_cavity_area_m2(self) -> float:
        return (self.reserved_vacancy_area_m2+self.direct_free_volume_area_m2
                +self.vacancy_growth_area_m2+self.emission_growth_area_m2)


@dataclass(frozen=True)
class LineFields:
    equivalent_plastic_strain: tuple[float, ...]
    forest_density_m2: tuple[float, ...]
    mobile_density_m2: tuple[float, ...]
    vacancy_fraction: tuple[float, ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]
    loop_deposited_forest_density_m2: tuple[float, ...] = ()


@dataclass(frozen=True)
class LineLedgers:
    initial_field_inventory_area_m2: float
    plastic_source_area_m2: float = 0.0
    climb_loss_area_m2: float = 0.0
    climb_emission_area_m2: float = 0.0
    exterior_loss_area_m2: float = 0.0
    exterior_gain_area_m2: float = 0.0
    crack_surface_loss_area_m2: float = 0.0
    crack_surface_gain_area_m2: float = 0.0
    site_capture_area_m2: float = 0.0
    cavity_vacancy_area_m2: float = 0.0
    cavity_emission_area_m2: float = 0.0
    site_reserved_area_m2: float = 0.0
    site_unaccommodated_area_m2: float = 0.0
    ineligible_capture_annihilation_area_m2: float = 0.0
    conservation_residual_area_m2: float = 0.0
    full_system_residual_area_m2: float = 0.0


@dataclass(frozen=True)
class ExecutableOneDState:
    core: OneDStateV3
    normalization: LineNormalization
    rows: TwoMechanismRows
    fields: LineFields
    sites: tuple[ReducedSiteState, ...]
    ledgers: LineLedgers
    physical_time_s: float = 0.0
    cycle_count: float = 0.0
    temperature_K: float = 300.0
    topology_regime: TopologyRegime = TopologyRegime.PRECONNECTION
    last_mechanics_response: MechanicsResponse | None = None
    event_history: tuple[Mapping[str, object], ...] = ()
    fracture_process_row: FractureProcessRow | None = None
    fracture_adapter_state: V2FractureOwnerState | None = None
    fracture_front_origin_m: float = 0.0
    compact_transport_state: CompactTransportState | None = None
    compact_mechanical_state: CompactMechanicalState | None = None
    native_incremental_owner_state: NativeIncrementalOwnerState | None = None
    schema: str = SCHEMA

    def __post_init__(self) -> None:
        count = len(self.normalization.cell_lengths_m)
        arrays = (
            self.fields.equivalent_plastic_strain, self.fields.forest_density_m2,
            self.fields.mobile_density_m2, self.fields.vacancy_fraction,
            self.fields.mean_stress_Pa, self.fields.opening_stress_Pa,
        )
        if any(len(values) != count for values in arrays):
            raise ValueError("every reduced field must own one value per line cell")
        if (self.fields.loop_deposited_forest_density_m2
                and len(self.fields.loop_deposited_forest_density_m2) != count):
            raise ValueError("loop-deposited forest field must own one value per line cell")
        if not math.isclose(self.core.fracture_state.time_s, self.physical_time_s,
                            rel_tol=0.0, abs_tol=1.0e-12):
            raise ValueError("fracture and physical-time owners must agree")
        if not math.isfinite(self.temperature_K) or self.temperature_K <= 0.0:
            raise ValueError("physical temperature must be finite and positive")
        if self.fracture_process_row is not None and self.fracture_adapter_state is not None:
            raise ValueError("handwritten and complete V2 fracture owners are mutually exclusive")
        if self.compact_transport_state is not None:
            compact = self.compact_transport_state
            if not np.allclose(
                    compact.line_solid_area_m2, self.normalization.cell_areas_m2,
                    rtol=2.0e-12, atol=1.0e-30):
                raise ValueError("line and compact solid measures disagree")
            if not np.allclose(
                    compact.line_average(compact.vacancy_fraction),
                    self.fields.vacancy_fraction, rtol=2.0e-12, atol=1.0e-30):
                raise ValueError("line field is not the compact-state projection")
        if (self.compact_mechanical_state is not None
                and self.compact_transport_state is not None
                and not np.allclose(
                    self.compact_mechanical_state.cell_measure_m2,
                    self.compact_transport_state.solid_area_m2,
                    rtol=0.0, atol=0.0)):
            raise ValueError("compact mechanics and transport measures disagree")


@dataclass(frozen=True)
class PhysicalIncrement:
    duration_s: float
    signed_load: float
    equivalent_plastic_strain_increment: tuple[float, ...]
    forest_density_m2: tuple[float, ...]
    mobile_density_m2: tuple[float, ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]
    crack_surface_sink_rate_s: tuple[float, ...] = ()
    # Optional conservative projections of the accepted multidimensional
    # operator.  They are instantaneous local fields, not fitted endpoint
    # inventories.  Empty tuples retain the native reduced constitutive law.
    plastic_vacancy_source_rate_s: tuple[float, ...] = ()
    climb_equilibrium_fraction: tuple[float, ...] = ()
    compact_transport_increment: CompactTransportIncrement | None = None
    compact_mechanical_increment: CompactMechanicalIncrement | None = None
    mechanics_response: MechanicsResponse | None = None
    fracture_cleavage_stress_Pa: float | None = None
    fracture_emission_stress_Pa: float | None = None
    prescribed_direct_opportunity_rate_s_by_site: Mapping[str, float] = field(
        default_factory=dict)
    prescribed_direct_mean_stress_Pa_by_site: Mapping[str, float] = field(
        default_factory=dict)
    bulk_accommodation_area_rate_m2_s_by_site: Mapping[str, float] = field(
        default_factory=dict)
    fracture_opening_m: float | None = None
    fracture_native_K_scale: float = 1.0
    fracture_mechanics_binding_identity: str = "UNCHANGED_NATIVE_MECHANICS"
    cavity_source_tensors_xy_Pa_by_site: Mapping[
        str, tuple[tuple[tuple[float, float], tuple[float, float]], ...]
    ] = field(default_factory=dict)
    cavity_source_sigma_zz_Pa_by_site: Mapping[str, tuple[float, ...]] = field(
        default_factory=dict)

    @property
    def v2_fracture_opening_m(self) -> float:
        return (float(self.signed_load) if self.fracture_opening_m is None
                else float(self.fracture_opening_m))


def initialize_executable_state(
    core: OneDStateV3,
    normalization: LineNormalization,
    rows: TwoMechanismRows,
    *,
    sites: Sequence[ReducedSiteState],
    initial_vacancy_fraction: float,
    initial_forest_density_m2: float,
    temperature_K: float = 300.0,
    fracture_process_row: FractureProcessRow | None = None,
    fracture_adapter_state: V2FractureOwnerState | None = None,
    fracture_front_origin_m: float = 0.0,
) -> ExecutableOneDState:
    n = len(normalization.cell_lengths_m)
    c = np.full(n, float(initial_vacancy_fraction))
    inventory = rows.inventory_ratio*float(np.dot(normalization.cell_areas_m2, c))
    fields = LineFields(
        tuple(np.zeros(n)), tuple(np.full(n, initial_forest_density_m2)),
        tuple(np.zeros(n)), tuple(c), tuple(np.zeros(n)), tuple(np.zeros(n)),
        tuple(np.zeros(n)),
    )
    owned_sites = []
    for site in sites:
        if site.emission_sources:
            owned_sites.append(site)
            continue
        digest = hashlib.sha256(
            f"oneD-v3-emission:{rows.fingerprint}:{site.site_id}".encode()).digest()
        seed = int.from_bytes(digest[:8], "little") or 1
        sources = initialize_sources(rows.emission_source_count, seed)
        owned_sites.append(replace(
            site, emission_sources=sources,
            emission_source_availability=tuple(
                source.available_fraction for source in sources),
        ))
    return ExecutableOneDState(
        core=replace(core, fracture_state=replace(core.fracture_state, time_s=0.0)),
        normalization=normalization, rows=rows, fields=fields,
        sites=tuple(owned_sites), ledgers=LineLedgers(inventory),
        temperature_K=float(temperature_K),
        fracture_process_row=fracture_process_row,
        fracture_adapter_state=fracture_adapter_state,
        fracture_front_origin_m=float(fracture_front_origin_m),
    )


def _arrays(increment: PhysicalIncrement, n: int):
    names = (
        "equivalent_plastic_strain_increment", "forest_density_m2",
        "mobile_density_m2", "mean_stress_Pa", "opening_stress_Pa",
    )
    values = {name: np.asarray(getattr(increment, name), float) for name in names}
    if any(value.shape != (n,) for value in values.values()):
        raise ValueError("physical increment fields must match the line grid")
    if increment.duration_s <= 0.0 or not math.isfinite(increment.duration_s):
        raise ValueError("physical time increment must be finite and positive")
    if np.any(values["equivalent_plastic_strain_increment"] < 0.0):
        raise ValueError("equivalent plastic activity is unsigned and nonnegative")
    return values


def direct_interaction_successful_rate_s(
    rows: TwoMechanismRows, *, forest_density_m2: float,
    equivalent_plastic_strain_rate_s: float, support_volume_m3: float,
    mean_stress_Pa: float, temperature_K: float,
) -> float:
    """Exact reduced evaluation of the production direct-interaction law."""
    opportunity = (rows.direct_geometry_factor*float(forest_density_m2)
                   *rows.taylor_factor*abs(float(equivalent_plastic_strain_rate_s))
                   /rows.burgers_m*float(support_volume_m3))
    success = math.exp(-max(
        rows.direct_barrier_eV*EV_J-max(float(mean_stress_Pa), 0.0)
        *rows.direct_activation_volume_m3, 0.0,
    )/(KB*float(temperature_K)))
    return opportunity*rows.direct_success_fraction*success


def direct_successful_rate_from_integrated_opportunity_s(
    rows: TwoMechanismRows, *, support_integrated_opportunity_rate_s: float,
    mean_stress_Pa: float, temperature_K: float,
) -> float:
    """Consume the support-integrated mechanical input used by the 2-D owner."""
    success = math.exp(-max(
        rows.direct_barrier_eV*EV_J-max(float(mean_stress_Pa), 0.0)
        *rows.direct_activation_volume_m3, 0.0,
    )/(KB*float(temperature_K)))
    return (float(support_integrated_opportunity_rate_s)
            *rows.direct_success_fraction*success)


def vacancy_birth_action_increment(
    rows: TwoMechanismRows, *, captured_area_m2: float,
    mean_stress_Pa: float, temperature_K: float,
) -> float:
    return (float(captured_area_m2)/rows.vacancy_hit_area_m2)*math.exp(-max(
        rows.vacancy_birth_barrier_J-max(float(mean_stress_Pa), 0.0)
        *rows.vacancy_stress_coupling_volume_m3, 0.0,
    )/(KB*float(temperature_K)))


def vacancy_diffusivity_m2_s(rows: TwoMechanismRows, temperature_K: float) -> float:
    """Production V2 Arrhenius diffusivity evaluated from the owned row."""
    return rows.vacancy_diffusivity_prefactor_m2_s*math.exp(
        -rows.vacancy_migration_energy_eV*EV_J/(KB*float(temperature_K))
    )


def equilibrium_vacancy_fraction(
    rows: TwoMechanismRows, temperature_K: float, mean_stress_Pa: np.ndarray | float,
) -> np.ndarray:
    """Stress-dependent lattice equilibrium used by the production owner."""
    stress = np.asarray(mean_stress_Pa, float)
    exponent = (
        rows.vacancy_formation_entropy_over_kB
        -(rows.vacancy_formation_energy_eV*EV_J
          -rows.vacancy_formation_volume_m3*stress)/(KB*float(temperature_K))
    )
    return 1.0/(1.0+np.exp(np.clip(-exponent, -700.0, 700.0)))


def cavity_emission_rates_s(
    rows: TwoMechanismRows, *, radius_m: float, opening_stress_Pa: float,
    temperature_K: float,
    source_orientations_rad: Sequence[float] | None = None,
    source_tensors_xy_Pa: Sequence[Sequence[Sequence[float]]] | None = None,
) -> tuple[float, ...]:
    """EXP-floor cavity-source intensities with explicit circumference count."""
    capillary = rows.emission_surface_energy_J_m2/float(radius_m)
    sources = rows.emission_surface_source_density_per_m*2.0*math.pi*float(radius_m)
    if source_tensors_xy_Pa is None:
        resolved_values = (max(float(opening_stress_Pa)-capillary, 0.0),) * (
            rows.emission_source_count)
    else:
        tensors = np.asarray(source_tensors_xy_Pa, float)
        orientations = tuple(source_orientations_rad or ())
        if tensors.shape != (len(orientations), 2, 2):
            raise ValueError("source tensors and production orientations disagree")
        resolved_values = tuple(max(
            float(tensor[0, 0]+tensor[1, 1])
            -2.0*float(tensor[0, 0]-tensor[1, 1])*math.cos(2.0*theta)
            -4.0*float(tensor[0, 1])*math.sin(2.0*theta)-capillary,
            0.0,
        ) for tensor, theta in zip(tensors, orientations))
    floor = max(rows.emission_barrier_floor_min_J,
                rows.emission_barrier_floor_fraction*rows.emission_barrier_J)
    return tuple(
        sources*rows.emission_attempt_frequency_s*math.exp(-(
            floor+(rows.emission_barrier_J-floor)*math.exp(
                -rows.emission_barrier_exp_a
                *(resolved/rows.emission_critical_stress_Pa)
                 **rows.emission_barrier_exp_n)
        )/(KB*float(temperature_K)))
        for resolved in resolved_values
    )


def _advance_production_emission_owner(
    site: ReducedSiteState, rows: TwoMechanismRows, *, opening_stress_Pa: float,
    temperature_K: float, duration_s: float,
    source_tensors_xy_Pa=None,
) -> tuple[ReducedSiteState, int, int]:
    """Couple production hybrid emission to the changing physical radius."""
    remaining = float(duration_s)
    updated = site
    realized_increment_total = 0
    packets = 0
    tolerance = max(64.0*np.spacing(max(remaining, 1.0)), 1.0e-18)
    while remaining > tolerance:
        rates = cavity_emission_rates_s(
            rows, radius_m=updated.radius_m,
            opening_stress_Pa=opening_stress_Pa,
            temperature_K=temperature_K,
            source_orientations_rad=tuple(
                source.orientation_rad for source in updated.emission_sources),
            source_tensors_xy_Pa=source_tensors_xy_Pa,
        )
        q = rows.emission_chi_loop*2.0*math.pi*updated.radius_m*rows.burgers_m
        upper_count_rate = math.fsum(
            rate*max(source.available_fraction,
                     rows.emission_recovery_rate_s/max(
                         rows.emission_recovery_rate_s
                         +rows.emission_depletion_per_loop*rate, 1.0e-300))
            for source, rate in zip(updated.emission_sources, rates)
        )
        maximum_area = (rows.emission_maximum_packet_area_fraction
                        *math.pi*updated.radius_m**2)
        packet = (remaining if upper_count_rate*q <= 0.0 else
                  min(remaining, maximum_area/(upper_count_rate*q)))
        if packet <= tolerance:
            packet = min(remaining, tolerance)
        sources, realized_increment, moment_increment = advance_sources(
            updated.emission_sources, rates, packet,
            recovery_rate_s=rows.emission_recovery_rate_s,
            depletion_per_loop=rows.emission_depletion_per_loop,
            low_count_mu_max=rows.emission_low_count_mu_max,
            continuum_mu_min=rows.emission_continuum_mu_min,
        )
        count_increment = realized_increment+moment_increment
        area_increment = q*count_increment
        realized = updated.realized_emitted_loop_count+realized_increment
        moment = updated.continuum_moment_loop_count+moment_increment
        updated = replace(
            updated,
            emission_sources=sources,
            emission_source_availability=tuple(
                source.available_fraction for source in sources),
            realized_emitted_loop_count=realized,
            continuum_moment_loop_count=moment,
            emitted_loop_count=float(realized)+moment,
            emission_growth_area_m2=updated.emission_growth_area_m2+area_increment,
            emission_packet_count=updated.emission_packet_count+1,
            retained_loop_count_effective=(
                updated.retained_loop_count_effective
                +count_increment*rows.emission_retained_loop_fraction),
            escaped_loop_count_effective=(
                updated.escaped_loop_count_effective
                +count_increment*rows.emission_escaped_loop_fraction),
            cumulative_emitted_burgers_m=(
                updated.cumulative_emitted_burgers_m
                +count_increment*rows.burgers_m),
            deposited_plastic_strain_integral_m2=(
                updated.deposited_plastic_strain_integral_m2
                +area_increment/rows.emission_model_thickness_m),
            deposited_dislocation_line_length_m=(
                updated.deposited_dislocation_line_length_m
                +count_increment*rows.emission_retained_loop_fraction
                 *2.0*math.pi*updated.radius_m),
        )
        updated = replace(
            updated, radius_m=math.sqrt(updated.total_cavity_area_m2/math.pi))
        realized_increment_total += realized_increment
        packets += 1
        remaining = max(remaining-packet, 0.0)
        if packets > 100000:
            raise RuntimeError("coupled cavity-emission packet bound exceeded")
    return updated, realized_increment_total, packets


def _next_emission_packet_duration(
    site: ReducedSiteState, rows: TwoMechanismRows,
    rates_s: Sequence[float], maximum_duration_s: float,
) -> float:
    """Production area-fraction packet boundary for mechanics refresh."""
    q = rows.emission_chi_loop*2.0*math.pi*site.radius_m*rows.burgers_m
    upper_count_rate = math.fsum(
        rate*max(
            source.available_fraction,
            rows.emission_recovery_rate_s/max(
                rows.emission_recovery_rate_s
                +rows.emission_depletion_per_loop*rate, 1.0e-300),
        )
        for source, rate in zip(site.emission_sources, rates_s)
    )
    maximum_area = rows.emission_maximum_packet_area_fraction*math.pi*site.radius_m**2
    if upper_count_rate*q <= 0.0:
        return float(maximum_duration_s)
    return min(float(maximum_duration_s), maximum_area/(upper_count_rate*q))


def _advance_physical_segment(
    state: ExecutableOneDState, increment: PhysicalIncrement,
    *, cycle_increment: float = 0.0,
) -> ExecutableOneDState:
    """Advance transport and every active owner over one common interval."""
    norm, rows = state.normalization, state.rows
    n = len(norm.cell_lengths_m)
    values = _arrays(increment, n)
    if (increment.mechanics_response is not None
            and increment.mechanics_response.regime != state.topology_regime):
        raise RuntimeError("mechanics response belongs to a different topology regime")
    dt = float(increment.duration_s)
    area = norm.cell_areas_m2
    width = np.asarray(norm.transverse_width_m, float)
    centers = norm.centers_m
    old_c = np.asarray(state.fields.vacancy_fraction, float)
    dep = values["equivalent_plastic_strain_increment"]
    epdot = dep/dt
    rho = values["forest_density_m2"]
    diffusivity = vacancy_diffusivity_m2_s(rows, state.temperature_K)
    ceq = equilibrium_vacancy_fraction(
        rows, state.temperature_K, values["mean_stress_Pa"])
    ceq_surface = float(equilibrium_vacancy_fraction(
        rows, state.temperature_K, 0.0))
    projected_source = np.asarray(
        increment.plastic_vacancy_source_rate_s, float)
    if projected_source.size:
        if (projected_source.shape != (n,) or np.any(~np.isfinite(projected_source))
                or np.any(projected_source < 0.0)):
            raise ValueError("projected plastic vacancy source must be nonnegative per-cell data")
        source_rate = projected_source
    else:
        baseline_source_rate = rows.plastic_vacancy_coefficient_per_strain*epdot
        enhanced_source_rate = (baseline_source_rate*rows.dislocation_production_boost
                                *np.sqrt(rho/rows.rho_reference_m2))
        source_rate = (baseline_source_rate
                       +rows.interaction_mobile_vacancy_fraction*enhanced_source_rate)

    mass = area*rows.inventory_ratio
    matrix = np.diag(mass/dt + mass*source_rate)
    rhs = mass/dt*old_c + mass*source_rate
    for face in range(n-1):
        spacing = centers[face+1]-centers[face]
        face_width = 2.0*width[face]*width[face+1]/(width[face]+width[face+1])
        conductance = diffusivity*face_width/spacing*rows.inventory_ratio
        stress_gradient = (values["mean_stress_Pa"][face+1]
                           -values["mean_stress_Pa"][face])/spacing
        drift = (diffusivity*face_width*rows.inventory_ratio
                 *rows.vacancy_stress_coupling_volume_m3
                 *stress_gradient/(KB*state.temperature_K))
        matrix[face, face] += conductance
        matrix[face+1, face+1] += conductance
        matrix[face, face+1] -= conductance
        matrix[face+1, face] -= conductance
        # Conservative upwind stress drift; the same face flux leaves one
        # cell and enters its neighbor.
        donor = face if drift >= 0.0 else face+1
        receiver = face+1 if drift >= 0.0 else face
        matrix[donor, donor] += abs(drift)
        matrix[receiver, donor] -= abs(drift)
    climb_rate = diffusivity*rows.dislocation_climb_capture_efficiency*rho
    climb_conductance = climb_rate*mass
    projected_climb_equilibrium = np.asarray(
        increment.climb_equilibrium_fraction, float)
    if projected_climb_equilibrium.size:
        if (projected_climb_equilibrium.shape != (n,)
                or np.any(~np.isfinite(projected_climb_equilibrium))
                or np.any(projected_climb_equilibrium < 0.0)
                or np.any(projected_climb_equilibrium > 1.0)):
            raise ValueError("projected climb equilibrium must lie in [0,1] per cell")
        ceq_climb = projected_climb_equilibrium
    else:
        ceq_climb = ceq
    surface_multiplier = (np.asarray(norm.exterior_surface_multiplier, float)
                          if norm.exterior_surface_multiplier else np.zeros(n))
    exterior_conductance = (rows.exterior_sink_efficiency*diffusivity
                            *surface_multiplier*norm.cell_lengths_m
                            /np.maximum(width, 1.0e-300))*rows.inventory_ratio
    crack_rates = (np.asarray(increment.crack_surface_sink_rate_s, float)
                   if increment.crack_surface_sink_rate_s else np.zeros(n))
    if crack_rates.shape != (n,) or np.any(crack_rates < 0.0):
        raise ValueError("crack-surface sink rates must be nonnegative per-cell data")
    crack_conductance = crack_rates*area*rows.inventory_ratio
    matrix[np.diag_indices(n)] += climb_conductance+exterior_conductance+crack_conductance
    rhs += (climb_conductance*ceq_climb
            +(exterior_conductance+crack_conductance)*ceq_surface)

    capture_by_site = []
    raw_capture_vectors = []
    for site in state.sites:
        mask = np.abs(centers-site.x_m) <= site.support_half_width_m
        weights = area*mask
        if not np.any(mask):
            raise ValueError(f"site {site.site_id} has no line-cell support")
        weights = weights/np.sum(weights)
        capture_active = site.phase in {
            SitePhase.AVAILABLE, SitePhase.EMBRYO,
            SitePhase.STABLE, SitePhase.RESOLVED,
        }
        raw_capture_vectors.append(
            rows.site_capture_factor*diffusivity*weights*rows.inventory_ratio
            if capture_active else np.zeros(n))
    # A site is an excess-vacancy capture owner, not a reservoir that may emit
    # inventory it does not own.  Solve the resulting one-sided exchange as a
    # small active-set problem so cells at/below c_eq carry zero capture flux.
    base_matrix = matrix.copy()
    base_rhs = rhs.copy()
    active = np.asarray(old_c > ceq, dtype=bool)
    capture_vectors = []
    for _ in range(64):
        matrix = base_matrix.copy()
        rhs = base_rhs.copy()
        capture_vectors = [vector*active for vector in raw_capture_vectors]
        total_capture = np.sum(capture_vectors, axis=0) if capture_vectors else np.zeros(n)
        matrix[np.diag_indices(n)] += total_capture
        rhs += total_capture*ceq
        new_c = np.linalg.solve(matrix, rhs)
        next_active = new_c > ceq
        if np.array_equal(next_active, active):
            break
        active = next_active
    else:
        raise RuntimeError("excess-vacancy capture active set did not converge")
    if np.any(new_c < -1.0e-14) or np.any(~np.isfinite(new_c)):
        raise RuntimeError("conservative line transport produced invalid concentration")
    new_c = np.maximum(new_c, 0.0)
    for vector in capture_vectors:
        capture_by_site.append(float(dt*np.dot(vector, np.maximum(new_c-ceq, 0.0))))

    climb_exchange = dt*climb_conductance*(new_c-ceq_climb)
    climb_loss = float(np.sum(np.maximum(climb_exchange, 0.0)))
    climb_emission = float(np.sum(np.maximum(-climb_exchange, 0.0)))
    exterior_exchange = dt*exterior_conductance*(new_c-ceq_surface)
    crack_exchange = dt*crack_conductance*(new_c-ceq_surface)
    exterior_loss = float(np.sum(np.maximum(exterior_exchange, 0.0)))
    exterior_gain = float(np.sum(np.maximum(-exterior_exchange, 0.0)))
    crack_loss = float(np.sum(np.maximum(crack_exchange, 0.0)))
    crack_gain = float(np.sum(np.maximum(-crack_exchange, 0.0)))
    captured = math.fsum(capture_by_site)
    compact_result: CompactTransportResult | None = None
    compact_mechanics = state.compact_mechanical_state
    if state.compact_transport_state is not None:
        if increment.compact_transport_increment is None:
            raise RuntimeError(
                "authoritative compact state requires a compact operator increment")
        compact_result = advance_compact_transport(
            state.compact_transport_state,
            increment.compact_transport_increment,
            duration_s=dt, temperature_K=state.temperature_K,
            diffusivity_m2_s=diffusivity, inventory_ratio=rows.inventory_ratio,
            vacancy_stress_coupling_volume_m3=(
                rows.vacancy_stress_coupling_volume_m3),
            climb_capture_efficiency=rows.dislocation_climb_capture_efficiency,
            site_capture_rate_area_per_s=rows.site_capture_factor*diffusivity,
            exterior_sink_efficiency=rows.exterior_sink_efficiency,
            equilibrium_surface_fraction=ceq_surface,
        )
        by_site = dict(compact_result.capture_by_site_area_m2)
        capture_by_site = [by_site.get(site.site_id, 0.0) for site in state.sites]
        captured = math.fsum(capture_by_site)
        climb_loss = compact_result.climb_loss_area_m2
        climb_emission = compact_result.climb_emission_area_m2
        exterior_loss = compact_result.exterior_loss_area_m2
        exterior_gain = compact_result.exterior_gain_area_m2
        crack_loss = compact_result.crack_loss_area_m2
        crack_gain = compact_result.crack_gain_area_m2
        new_c = compact_result.state.line_average(
            compact_result.state.vacancy_fraction)
    if compact_mechanics is not None:
        if increment.compact_mechanical_increment is None:
            raise RuntimeError(
                "authoritative compact mechanics requires a signed tensor increment")
        compact_mechanics = advance_compact_mechanics(
            compact_mechanics, increment.compact_mechanical_increment)
    sites = []
    events = []
    active_void_site_id = (
        state.core.void_state.site_id if state.core.void_state is not None else
        next((item.site_id for item in state.sites if item.phase not in {
            SitePhase.AVAILABLE, SitePhase.HEALED}), None)
    )
    for site, capture in zip(state.sites, capture_by_site):
        support = np.abs(centers-site.x_m) <= site.support_half_width_m
        gamma = (rows.direct_geometry_factor*values["forest_density_m2"]
                 *rows.taylor_factor*epdot/rows.burgers_m)
        opportunity = float(np.sum(gamma[support]*area[support]*norm.thickness_m))
        weighted = gamma[support]*area[support]
        mean_stress = (float(np.dot(weighted, values["mean_stress_Pa"][support])
                             /max(np.sum(weighted), 1.0e-300))
                       if np.sum(weighted) > 0.0
                       else float(np.mean(values["mean_stress_Pa"][support])))
        success = math.exp(-max(
            rows.direct_barrier_eV*EV_J-max(mean_stress, 0.0)*rows.direct_activation_volume_m3,
            0.0,
        )/(KB*state.temperature_K))
        if site.site_id in increment.prescribed_direct_opportunity_rate_s_by_site:
            direct_rate = direct_successful_rate_from_integrated_opportunity_s(
                rows,
                support_integrated_opportunity_rate_s=(
                    increment.prescribed_direct_opportunity_rate_s_by_site[
                        site.site_id]),
                mean_stress_Pa=increment.prescribed_direct_mean_stress_Pa_by_site[
                    site.site_id],
                temperature_K=state.temperature_K,
            )
        else:
            direct_rate = opportunity*rows.direct_success_fraction*success
        direct_increment = direct_rate*dt
        reserving = site.phase in {SitePhase.AVAILABLE, SitePhase.EMBRYO}
        updated = replace(
            site,
            reserved_vacancy_area_m2=(
                site.reserved_vacancy_area_m2+capture if reserving
                else site.reserved_vacancy_area_m2
            ),
            direct_action=(site.direct_action+direct_increment
                           if site.phase == SitePhase.AVAILABLE
                           else site.direct_action),
        )
        if updated.phase == SitePhase.AVAILABLE:
            vacancy_rate_action = vacancy_birth_action_increment(
                rows, captured_area_m2=capture, mean_stress_Pa=mean_stress,
                temperature_K=state.temperature_K,
            )
            updated = replace(updated, vacancy_action=updated.vacancy_action+vacancy_rate_action)
            vacancy_hits = updated.vacancy_hits
            while (vacancy_hits < rows.vacancy_required_hits
                   and updated.vacancy_action >= (
                       updated.vacancy_thresholds[vacancy_hits]
                       -64.0*np.spacing(max(
                           updated.vacancy_thresholds[vacancy_hits], 1.0)))
                   and updated.reserved_vacancy_area_m2
                   >= (vacancy_hits+1)*rows.vacancy_hit_area_m2):
                vacancy_hits += 1
                events.append({"event": "VACANCY_BIRTH_HIT", "site_id": site.site_id})
            direct_hits = updated.direct_hits
            while (direct_hits < rows.direct_required_hits
                   and updated.direct_action >= (
                       updated.direct_thresholds[direct_hits]
                       -64.0*np.spacing(max(
                           updated.direct_thresholds[direct_hits], 1.0)))):
                direct_hits += 1
                events.append({"event": "DIRECT_BIRTH_HIT", "site_id": site.site_id})
            updated = replace(
                updated, vacancy_hits=vacancy_hits, direct_hits=direct_hits,
                direct_free_volume_area_m2=direct_hits*rows.direct_hit_area_m2,
            )
            if (vacancy_hits == rows.vacancy_required_hits
                    or direct_hits == rows.direct_required_hits):
                seed_area = (updated.reserved_vacancy_area_m2
                             +updated.direct_free_volume_area_m2)
                updated = replace(
                    updated, phase=SitePhase.EMBRYO,
                    radius_m=math.sqrt(seed_area/math.pi),
                    growth_representation="EMBRYO",
                )
                events.append({"event": "EMBRYO", "site_id": site.site_id})
                # ReducedSiteState owns every site's lifecycle.  The legacy
                # core.void_state remains a single-primary compatibility
                # projection and must not suppress births at other sites.
                if active_void_site_id is None:
                    active_void_site_id = site.site_id
        elif updated.phase == SitePhase.EMBRYO:
            stabilization_rate, healing_rate = _lifecycle_rates_for_site(
                state, updated, increment)
            stabilize = updated.stabilization_action+stabilization_rate*dt
            heal = updated.healing_action+healing_rate*dt
            updated = replace(
                updated,
                stabilization_action=min(
                    stabilize, updated.stabilization_threshold),
                healing_action=min(heal, updated.healing_threshold),
            )
        if site.phase in {SitePhase.EMBRYO, SitePhase.STABLE, SitePhase.RESOLVED}:
            opening = float(np.mean(values["opening_stress_Pa"][support]))
            # Use the production mechanism owner: vacancy supply and plastic
            # accommodation act in series (harmonic rate), while emitted-loop
            # growth remains a separate parallel mechanism.  The previous
            # reduced ``min`` shortcut materially over-accommodated capture.
            raw_rate = capture/dt
            bulk_rate = float(
                increment.bulk_accommodation_area_rate_m2_s_by_site.get(
                    site.site_id,
                    rows.bulk_accommodation_coefficient
                    *2.0*math.pi*updated.radius_m**2
                    *float(np.mean(dep[support]))/dt))
            accommodated_rate = production_series_limited_vacancy_rate(
                raw_rate, bulk_rate)
            vacancy_growth = (0.0 if updated.phase == SitePhase.EMBRYO else
                              accommodated_rate*dt)
            unaccommodated = (0.0 if updated.phase == SitePhase.EMBRYO else
                              max(capture-vacancy_growth, 0.0))
            updated = replace(
                updated,
                vacancy_growth_area_m2=updated.vacancy_growth_area_m2+vacancy_growth,
                captured_unaccommodated_vacancy_area_m2=(
                    updated.captured_unaccommodated_vacancy_area_m2+unaccommodated),
            )
            updated = replace(
                updated, radius_m=math.sqrt(updated.total_cavity_area_m2/math.pi),
            )
            count_before = updated.emitted_loop_count
            updated, realized_increment, _ = _advance_production_emission_owner(
                updated, rows, opening_stress_Pa=opening,
                temperature_K=state.temperature_K, duration_s=dt,
                source_tensors_xy_Pa=(
                    increment.cavity_source_tensors_xy_Pa_by_site.get(site.site_id)),
            )
            count_increment = updated.emitted_loop_count-count_before
            if count_increment > 0.0:
                events.append({
                    "event": ("CAVITY_LOOP_EMISSION" if realized_increment
                              else "CAVITY_CONTINUUM_GROWTH_PACKET"),
                    "site_id": site.site_id,
                    "realized_loop_count": realized_increment,
                    "effective_loop_count": count_increment,
                    "continuum_moment_loop_count": count_increment-realized_increment,
                })
        if site.phase == SitePhase.EMBRYO:
            stable_crossed = (updated.stabilization_action
                              >= updated.stabilization_threshold)
            healing_crossed = updated.healing_action >= updated.healing_threshold
            # The production lifecycle owns healing-first exact ties.  Once
            # any loop has been emitted the embryo is irreversible, so a
            # healing winner publishes the residual-defect stable state.
            if healing_crossed:
                healing_outcome = production_healing_representation(
                    updated.emission_sources)
                if healing_outcome == RESIDUAL_LOOP_BEARING_DEFECT:
                    updated = replace(
                        updated, phase=SitePhase.STABLE,
                        growth_representation=RESIDUAL_LOOP_BEARING_DEFECT,
                    )
                    events.append({"event": "HEALING_PROHIBITED_RESIDUAL_DEFECT",
                                   "site_id": site.site_id,
                                   "retained_emitted_loops": updated.emitted_loop_count})
                else:
                    updated = replace(
                        updated, phase=SitePhase.HEALED, radius_m=None,
                        growth_representation=HEALED_AVAILABLE_SITE,
                    )
                    events.append({"event": "HEALED", "site_id": site.site_id})
            elif stable_crossed:
                updated = replace(
                    updated, phase=SitePhase.STABLE,
                    growth_representation="STABLE_SUBGRID_VOID",
                )
                events.append({"event": "STABILIZED", "site_id": site.site_id})
        sites.append(updated)

    if compact_result is None:
        old_inventory = rows.inventory_ratio*float(np.dot(area, old_c))
        new_inventory = rows.inventory_ratio*float(np.dot(area, new_c))
        source_total = float(dt*np.dot(mass, source_rate*(1.0-new_c)))
        residual = (old_inventory+source_total+climb_emission+exterior_gain+crack_gain
                    -new_inventory-climb_loss-exterior_loss-crack_loss-captured)
    else:
        old_inventory = compact_result.old_inventory_area_m2
        new_inventory = compact_result.new_inventory_area_m2
        source_total = compact_result.plastic_source_area_m2
        residual = compact_result.conservation_residual_area_m2
    tolerance = 1.0e-10*max(old_inventory+source_total, 1.0e-30)
    if abs(residual) > tolerance:
        raise RuntimeError(
            "line transport inventory conservation failed: "
            f"residual={residual:.17e}, tolerance={tolerance:.17e}")
    owned_before = math.fsum(
        x.reserved_vacancy_area_m2+x.vacancy_growth_area_m2
        +x.captured_unaccommodated_vacancy_area_m2 for x in state.sites)
    owned_after = math.fsum(
        x.reserved_vacancy_area_m2+x.vacancy_growth_area_m2
        +x.captured_unaccommodated_vacancy_area_m2 for x in sites)
    full_system_residual = residual+captured-(owned_after-owned_before)
    if abs(full_system_residual) > tolerance:
        raise RuntimeError("field-plus-site vacancy ownership failed")
    ledgers = replace(
        state.ledgers,
        plastic_source_area_m2=state.ledgers.plastic_source_area_m2+source_total,
        climb_loss_area_m2=state.ledgers.climb_loss_area_m2+climb_loss,
        climb_emission_area_m2=state.ledgers.climb_emission_area_m2+climb_emission,
        exterior_loss_area_m2=state.ledgers.exterior_loss_area_m2+exterior_loss,
        exterior_gain_area_m2=state.ledgers.exterior_gain_area_m2+exterior_gain,
        crack_surface_loss_area_m2=state.ledgers.crack_surface_loss_area_m2+crack_loss,
        crack_surface_gain_area_m2=state.ledgers.crack_surface_gain_area_m2+crack_gain,
        site_capture_area_m2=state.ledgers.site_capture_area_m2+captured,
        conservation_residual_area_m2=state.ledgers.conservation_residual_area_m2+residual,
        cavity_vacancy_area_m2=math.fsum(x.vacancy_growth_area_m2 for x in sites),
        cavity_emission_area_m2=math.fsum(x.emission_growth_area_m2 for x in sites),
        site_reserved_area_m2=math.fsum(x.reserved_vacancy_area_m2 for x in sites),
        site_unaccommodated_area_m2=math.fsum(
            x.captured_unaccommodated_vacancy_area_m2 for x in sites),
        full_system_residual_area_m2=(state.ledgers.full_system_residual_area_m2
                                     +full_system_residual),
    )
    loop_dep = np.zeros(n)
    loop_rho = np.zeros(n)
    before_by_id = {site.site_id: site for site in state.sites}
    for site in sites:
        before_site = before_by_id[site.site_id]
        delta_strain = (site.deposited_plastic_strain_integral_m2
                        -before_site.deposited_plastic_strain_integral_m2)
        delta_line = (site.deposited_dislocation_line_length_m
                      -before_site.deposited_dislocation_line_length_m)
        if delta_strain <= 0.0 and delta_line <= 0.0:
            continue
        support = np.abs(centers-site.x_m) <= site.support_half_width_m
        support_area = float(np.sum(area[support]))
        if support_area <= 0.0:
            raise RuntimeError("loop mechanics deposition has no line support")
        # Scalar aligned projection of the production source-oriented slip
        # tensor: preserve its support-integrated plastic measure and retained
        # loop line length exactly on the reduced cells.
        loop_dep[support] += delta_strain/support_area
        loop_rho[support] += delta_line/support_area
    old_loop_rho = np.asarray(
        state.fields.loop_deposited_forest_density_m2 or np.zeros(n), float)
    new_loop_rho = old_loop_rho+loop_rho
    fields = LineFields(
        tuple(np.asarray(state.fields.equivalent_plastic_strain)+dep+loop_dep),
        tuple(values["forest_density_m2"]+new_loop_rho),
        tuple(values["mobile_density_m2"]),
        tuple(new_c), tuple(values["mean_stress_Pa"]),
        tuple(values["opening_stress_Pa"]), tuple(new_loop_rho),
    )
    time_after = state.physical_time_s+dt
    fracture = state.core.fracture_state
    fracture_adapter_state = state.fracture_adapter_state
    if fracture_adapter_state is not None:
        preview = preview_v2_fracture_interval(
            fracture_adapter_state,
            opening_m=increment.v2_fracture_opening_m,
            temperature_K=state.temperature_K,
            duration_s=dt,
            mechanics_binding=ReducedMechanicsDriveBinding(
                increment.fracture_native_K_scale,
                increment.fracture_mechanics_binding_identity),
        )
        fracture_adapter_state = commit_v2_fracture_preview(
            fracture_adapter_state, preview)
        fracture = project_v2_fracture_state(
            fracture, fracture_adapter_state,
            physical_time_s=time_after,
            external_control=float(increment.signed_load),
        )
        if preview.fired:
            events.append({
                "event": "FRACTURE_CLEAVAGE", "owner": "CompleteV2FractureAdapter",
                "backend": fracture_adapter_state.backend,
                "advance_m": preview.interval_result.event_length_m,
                "geometry_commits": preview.interval_result.geometry_commits,
                "post_event_renewals": preview.interval_result.post_event_renewals,
            })
    elif state.fracture_process_row is not None:
        if (increment.fracture_cleavage_stress_Pa is None
                or increment.fracture_emission_stress_Pa is None):
            raise RuntimeError("coupled fracture advance requires both state-bound stresses")
        kernel = SharedBarrierHazardCore(state.fracture_process_row.parameters)
        response = kernel.evaluate(
            fracture, state.temperature_K,
            float(increment.fracture_cleavage_stress_Pa),
            float(increment.fracture_emission_stress_Pa), dt,
        )
        cleavage_action = fracture.cleavage_action+response.cleavage_hazard_increment
        emission_action = fracture.emission_action+response.emission_hazard_increment
        fracture = replace(
            fracture, time_s=time_after,
            external_control=float(increment.signed_load),
            cleavage_action=cleavage_action, emission_action=emission_action,
        )
        tolerance_action = 64.0*np.spacing(max(
            abs(fracture.cleavage_threshold), 1.0))
        if cleavage_action >= fracture.cleavage_threshold-tolerance_action:
            fracture = replace(
                fracture,
                crack_extension_m=(fracture.crack_extension_m
                                   +state.fracture_process_row.cleavage_advance_m),
                cleavage_action=0.0,
                event_count=fracture.event_count+1,
                physical_avalanche_index=fracture.physical_avalanche_index+1,
            )
            events.append({
                "event": "FRACTURE_CLEAVAGE", "owner": "ReducedState/V2",
                "parameter_row_id": state.fracture_process_row.candidate_id,
                "parameter_row_fingerprint": state.fracture_process_row.fingerprint,
                "advance_m": state.fracture_process_row.cleavage_advance_m,
            })
    else:
        fracture = replace(
            fracture, time_s=time_after,
            external_control=float(increment.signed_load),
        )
    core = replace(state.core, fracture_state=fracture)
    owner = next((item for item in sites
                  if item.site_id == active_void_site_id), None)
    if owner is not None:
        core = replace(core, void_state=_synchronize_core_void_state(
            core.void_state, owner, rows, events))
    timed_events = tuple({**dict(event), "physical_time_s": time_after}
                         for event in events)
    return replace(
        state, core=core, fields=fields, sites=tuple(sites), ledgers=ledgers,
        compact_transport_state=(None if compact_result is None
                                 else compact_result.state),
        compact_mechanical_state=compact_mechanics,
        fracture_adapter_state=fracture_adapter_state,
        physical_time_s=time_after, cycle_count=state.cycle_count+float(cycle_increment),
        last_mechanics_response=increment.mechanics_response,
        event_history=state.event_history+timed_events,
    )


def _synchronize_core_void_state(
    before: OneDVoidState | None, site: ReducedSiteState,
    rows: TwoMechanismRows, events: Sequence[Mapping[str, object]],
) -> OneDVoidState:
    """Publish the physical owner through the existing V3 lifecycle state."""
    phase_map = {
        SitePhase.EMBRYO: (VoidPhase.EMBRYO, MechanicsRepresentation.INACTIVE),
        SitePhase.STABLE: (VoidPhase.STABLE_SUBGRID_VOID, MechanicsRepresentation.SUBGRID),
        SitePhase.RESOLVED: (VoidPhase.RESOLVED_VOID, MechanicsRepresentation.SURROGATE_ACTIVE),
        SitePhase.CONNECTED: (VoidPhase.CONNECTED_VOID, MechanicsRepresentation.CONNECTED_CAVITY),
        SitePhase.CHILD: (VoidPhase.DOWNSTREAM_FRONT_ACTIVE, MechanicsRepresentation.CHILD_ACTIVE),
        SitePhase.HEALED: (VoidPhase.HEALED_SITE, MechanicsRepresentation.INACTIVE),
    }
    phase, representation = phase_map[site.phase]
    vacancy_complete = site.vacancy_hits >= rows.vacancy_required_hits
    direct_complete = site.direct_hits >= rows.direct_required_hits
    use_direct = direct_complete or (
        not vacancy_complete
        and site.direct_hits/rows.direct_required_hits
        >= site.vacancy_hits/rows.vacancy_required_hits)
    thresholds = site.direct_thresholds if use_direct else site.vacancy_thresholds
    hit_count = site.direct_hits if use_direct else site.vacancy_hits
    required = rows.direct_required_hits if use_direct else rows.vacancy_required_hits
    action = site.direct_action if use_direct else site.vacancy_action
    threshold = thresholds[min(hit_count, required)-1] if hit_count else thresholds[0]
    geometry_active = phase in {
        VoidPhase.STABLE_SUBGRID_VOID, VoidPhase.RESOLVED_VOID,
        VoidPhase.CONNECTED_VOID, VoidPhase.DOWNSTREAM_FRONT_ACTIVE,
    }
    radius = site.radius_m if geometry_active else None
    area = math.pi*radius**2 if radius is not None else 0.0
    lineage_add = tuple(
        str(event["event"]) for event in events
        if event.get("site_id") == site.site_id)
    base_lineage = () if before is None else before.lineage
    return OneDVoidState(
        site_id=site.site_id, x_void_m=site.x_m,
        phase=phase, mechanics_representation=representation,
        radius_m=radius, area_m2=area,
        hit_count=min(hit_count, required), required_hit_count=required,
        candidate_weight=1.0,
        birth=HazardClock(min(action, threshold), threshold),
        stabilization=HazardClock(min(site.stabilization_action, 1.0), 1.0),
        healing=HazardClock(min(site.healing_action, 1.0), 1.0),
        ligament=(HazardClock() if before is None else before.ligament),
        downstream=(HazardClock() if before is None else before.downstream),
        available_inventory_area_m2=site.captured_unaccommodated_vacancy_area_m2,
        consumed_inventory_area_m2=area,
        lineage=base_lineage+lineage_add,
        rng_state={} if before is None else before.rng_state,
        length_ledgers=(before.length_ledgers if before is not None
                        else LengthLedgers()),
        active_tip_position_m=(before.active_tip_position_m
                               if phase == VoidPhase.DOWNSTREAM_FRONT_ACTIVE
                               and before is not None else None),
        source_v5_state_sha256=(None if before is None
                                else before.source_v5_state_sha256),
        growth_representation=site.growth_representation,
    )


def _direct_rate_for_site(
    state: ExecutableOneDState, site: ReducedSiteState,
    increment: PhysicalIncrement,
) -> float:
    if site.phase != SitePhase.AVAILABLE:
        return 0.0
    if site.site_id in increment.prescribed_direct_opportunity_rate_s_by_site:
        return direct_successful_rate_from_integrated_opportunity_s(
            state.rows,
            support_integrated_opportunity_rate_s=(
                increment.prescribed_direct_opportunity_rate_s_by_site[
                    site.site_id]),
            mean_stress_Pa=increment.prescribed_direct_mean_stress_Pa_by_site[
                site.site_id],
            temperature_K=state.temperature_K,
        )
    values = _arrays(increment, len(state.normalization.cell_lengths_m))
    centers = state.normalization.centers_m
    support = np.abs(centers-site.x_m) <= site.support_half_width_m
    area = state.normalization.cell_areas_m2
    epdot = values["equivalent_plastic_strain_increment"]/increment.duration_s
    gamma = (state.rows.direct_geometry_factor*values["forest_density_m2"]
             *state.rows.taylor_factor*epdot/state.rows.burgers_m)
    opportunity = float(np.sum(
        gamma[support]*area[support]*state.normalization.thickness_m))
    weighted = gamma[support]*area[support]
    mean_stress = (float(np.dot(weighted, values["mean_stress_Pa"][support])
                         /max(np.sum(weighted), 1.0e-300))
                   if np.sum(weighted) > 0.0 else
                   float(np.mean(values["mean_stress_Pa"][support])))
    return direct_successful_rate_from_integrated_opportunity_s(
        state.rows, support_integrated_opportunity_rate_s=opportunity,
        mean_stress_Pa=mean_stress, temperature_K=state.temperature_K,
    )


def _lifecycle_rates_for_site(
    state: ExecutableOneDState, site: ReducedSiteState,
    increment: PhysicalIncrement,
) -> tuple[float, float]:
    """Return the production Arrhenius clocks when their row is available."""
    rows = state.rows
    if rows.lifecycle_attempt_frequency_s is None:
        return float(rows.stabilization_rate_s), float(rows.healing_rate_s)
    tensors = increment.cavity_source_tensors_xy_Pa_by_site.get(site.site_id, ())
    if tensors:
        tensile = max(float(np.linalg.eigvalsh(
            np.asarray(tensors[0], float).reshape(2, 2))[-1]), 0.0)
    else:
        support = np.abs(state.normalization.centers_m-site.x_m) <= site.support_half_width_m
        tensile = max(float(np.mean(
            np.asarray(increment.opening_stress_Pa, float)[support])), 0.0)
    thermal = KB*state.temperature_K
    stabilization_effective = max(
        float(rows.stabilization_barrier_J)
        -tensile*rows.stabilization_activation_volume_m3, 0.0)
    healing_effective = max(
        float(rows.healing_barrier_J)
        +tensile*rows.healing_activation_volume_m3, 0.0)
    attempt = float(rows.lifecycle_attempt_frequency_s)
    return (
        attempt*math.exp(-stabilization_effective/thermal),
        attempt*math.exp(-healing_effective/thermal),
    )


def _slice_increment(increment: PhysicalIncrement, duration_s: float) -> PhysicalIncrement:
    fraction = float(duration_s)/float(increment.duration_s)
    compact = increment.compact_transport_increment
    if compact is not None:
        compact = replace(
            compact, equivalent_plastic_strain_increment=tuple(
                fraction*np.asarray(
                    compact.equivalent_plastic_strain_increment, float)))
    return replace(
        increment, duration_s=float(duration_s),
        equivalent_plastic_strain_increment=tuple(
            fraction*np.asarray(increment.equivalent_plastic_strain_increment, float)),
        compact_transport_increment=compact,
    )


def advance_physical_time(
    state: ExecutableOneDState, increment: PhysicalIncrement,
    *, cycle_increment: float = 0.0,
    mechanics_refresh: Callable[
        [ExecutableOneDState, float, float], PhysicalIncrement
    ] | None = None,
) -> ExecutableOneDState:
    """Advance globally ordered site owners over one physical interval.

    Rates supplied by one mechanics observation are held piecewise constant,
    but every direct-birth, stabilization, or healing first passage splits the
    interval.  All sites compete on the same clock; after a commit, the
    remaining interval is rebuilt from the updated physical state.
    """
    total = float(increment.duration_s)
    if total <= 0.0 or not math.isfinite(total):
        raise ValueError("physical time increment must be finite and positive")
    remaining = total
    result = state
    tolerance = max(64.0*np.spacing(total), 1.0e-15*total)
    events = 0
    while remaining > tolerance:
        trial = _slice_increment(increment, remaining)
        crossings: list[float] = []
        for site in result.sites:
            if site.phase == SitePhase.AVAILABLE:
                rate = _direct_rate_for_site(result, site, trial)
                if rate > 0.0 and site.direct_hits < result.rows.direct_required_hits:
                    crossings.append(max(
                        site.direct_thresholds[site.direct_hits]-site.direct_action, 0.0
                    )/rate)
            elif site.phase == SitePhase.EMBRYO:
                stabilization_rate, healing_rate = _lifecycle_rates_for_site(
                    result, site, trial)
                if stabilization_rate > 0.0:
                    crossings.append(max(
                        site.stabilization_threshold-site.stabilization_action,
                        0.0)/stabilization_rate)
                if healing_rate > 0.0:
                    crossings.append(max(
                        site.healing_threshold-site.healing_action,
                        0.0)/healing_rate)
            if site.phase in {SitePhase.EMBRYO, SitePhase.STABLE, SitePhase.RESOLVED}:
                support = np.abs(
                    result.normalization.centers_m-site.x_m
                ) <= site.support_half_width_m
                opening = float(np.mean(np.asarray(
                    trial.opening_stress_Pa, float)[support]))
                rates = cavity_emission_rates_s(
                    result.rows, radius_m=site.radius_m,
                    opening_stress_Pa=opening,
                    temperature_K=result.temperature_K,
                    source_orientations_rad=tuple(
                        source.orientation_rad for source in site.emission_sources),
                    source_tensors_xy_Pa=(
                        trial.cavity_source_tensors_xy_Pa_by_site.get(site.site_id)),
                )
                crossing = next_exact_crossing_time(
                    site.emission_sources, rates, remaining,
                    recovery_rate_s=result.rows.emission_recovery_rate_s,
                    depletion_per_loop=result.rows.emission_depletion_per_loop,
                    low_count_mu_max=result.rows.emission_low_count_mu_max,
                    continuum_mu_min=result.rows.emission_continuum_mu_min,
                )
                if math.isfinite(crossing):
                    crossings.append(crossing)
                packet_crossing = _next_emission_packet_duration(
                    site, result.rows, rates, remaining)
                if packet_crossing < remaining-tolerance:
                    crossings.append(packet_crossing)
        if result.fracture_adapter_state is not None:
            crossing = first_v2_fracture_event_time(
                result.fracture_adapter_state,
                opening_m=trial.v2_fracture_opening_m,
                temperature_K=result.temperature_K,
                maximum_duration_s=remaining,
                tolerance_s=tolerance,
                mechanics_binding=ReducedMechanicsDriveBinding(
                    trial.fracture_native_K_scale,
                    trial.fracture_mechanics_binding_identity),
            )
            if crossing is not None:
                crossings.append(crossing)
        elif result.fracture_process_row is not None:
            if (trial.fracture_cleavage_stress_Pa is None
                    or trial.fracture_emission_stress_Pa is None):
                raise RuntimeError("coupled fracture preview requires state-bound stresses")
            fracture = result.core.fracture_state
            rates = SharedBarrierHazardCore(
                result.fracture_process_row.parameters).evaluate(
                    fracture, result.temperature_K,
                    float(trial.fracture_cleavage_stress_Pa),
                    float(trial.fracture_emission_stress_Pa), 1.0,
                )
            if rates.cleavage_rate_s > 0.0:
                crossings.append(max(
                    fracture.cleavage_threshold-fracture.cleavage_action, 0.0
                )/rates.cleavage_rate_s)
        positive = [value for value in crossings if value > tolerance]
        old_remaining = remaining
        analytic_horizon = min([remaining, *positive]) if positive else remaining
        segment = analytic_horizon
        # Vacancy action is tied to the implicit transport/capture solution,
        # so it has no honest closed-form clock rate.  Preview the immutable
        # segment and localize the first reserved-inventory-backed hit by
        # bisection before any analytic owner is allowed to pass it.
        trial_after = _advance_physical_segment(
            result, _slice_increment(increment, analytic_horizon),
            cycle_increment=0.0)
        if any(after.vacancy_hits > before.vacancy_hits
               for before, after in zip(result.sites, trial_after.sites)):
            low, high = 0.0, analytic_horizon
            for _ in range(56):
                if high-low <= tolerance:
                    break
                mid = 0.5*(low+high)
                mid_after = _advance_physical_segment(
                    result, _slice_increment(increment, mid),
                    cycle_increment=0.0)
                if any(after.vacancy_hits > before.vacancy_hits
                       for before, after in zip(result.sites, mid_after.sites)):
                    high = mid
                else:
                    low = mid
            segment = high
        event_boundary = segment < old_remaining-tolerance
        before_events = len(result.event_history)
        result = _advance_physical_segment(
            result, _slice_increment(increment, segment),
            cycle_increment=float(cycle_increment)*segment/total,
        )
        remaining = max(remaining-segment, 0.0)
        if len(result.event_history) > before_events:
            events += len(result.event_history)-before_events
            if mechanics_refresh is not None and remaining > tolerance:
                refreshed = mechanics_refresh(
                    result, float(increment.signed_load), float(remaining))
                if (refreshed.duration_s != float(remaining)
                        or refreshed.signed_load != float(increment.signed_load)):
                    raise RuntimeError(
                        "post-event mechanics refresh changed interval ownership")
                increment = refreshed
            if events > 1024:
                raise RuntimeError("reduced global event scheduler exceeded its bound")
        elif event_boundary:
            raise RuntimeError(
                "reduced first-passage boundary did not commit an event: "
                f"segment={segment:.17e}, crossings={crossings!r}")
    if remaining > 0.0:
        result = _advance_physical_segment(
            result, _slice_increment(increment, remaining),
            cycle_increment=float(cycle_increment)*remaining/total,
        )
    return result


def advance_signed_waveform(
    state: ExecutableOneDState,
    waveform: Sequence[tuple[float, float]],
    mechanics: Callable[[ExecutableOneDState, float, float], PhysicalIncrement],
    *, cycles: int = 1,
) -> ExecutableOneDState:
    """Advance an arbitrary signed waveform without resetting physical state."""
    if cycles <= 0 or int(cycles) != cycles:
        raise ValueError("fatigue adapter requires a positive integer cycle count")
    if not waveform or any(dt <= 0.0 for dt, _ in waveform):
        raise ValueError("waveform segments require positive physical duration")
    result = state
    segments = len(waveform)
    for _ in range(int(cycles)):
        for dt, signed_load in waveform:
            increment = mechanics(result, float(signed_load), float(dt))
            if increment.duration_s != float(dt) or increment.signed_load != float(signed_load):
                raise RuntimeError("fatigue mechanics callback changed waveform ownership")
            result = advance_physical_time(
                result, increment, cycle_increment=1.0/segments,
                mechanics_refresh=mechanics,
            )
    return result


__all__ = [
    "ExecutableOneDState", "FractureProcessRow", "LineFields", "LineLedgers", "LineNormalization",
    "PhysicalIncrement", "ReducedSiteState", "SCHEMA", "SitePhase",
    "TwoMechanismRows", "advance_physical_time", "advance_signed_waveform",
    "cavity_emission_rates_s", "direct_interaction_successful_rate_s",
    "direct_successful_rate_from_integrated_opportunity_s",
    "equilibrium_vacancy_fraction", "initialize_executable_state",
    "vacancy_birth_action_increment", "vacancy_diffusivity_m2_s",
]
