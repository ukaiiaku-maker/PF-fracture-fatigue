"""Mesh-free adapter of the production hybrid cavity-emission owner.

The counter-based Poisson measure, LOW_COUNT_EXACT/CONTINUUM regime rule,
availability flow, depletion and Burgers-radius loop kinematics are copied
from ``unified-2d.embryo-growth/1``.  Only the FEM stress recovery is replaced
by an already reduced opening-stress input.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import math
from typing import Sequence

import numpy as np


PRODUCTION_OWNER_SCHEMA = "unified-2d.embryo-growth/1"
PRODUCTION_VACANCY_ACCOMMODATION_OWNER_ID = (
    "unified-2d.embryo-growth/1:mechanism_resolved_growth_rates")
ADAPTER_SCHEMA = "oneD.v3.production-cavity-emission-adapter/1"
RESIDUAL_LOOP_BEARING_DEFECT = "RESIDUAL_LOOP_BEARING_DEFECT"
HEALED_AVAILABLE_SITE = "HEALED_AVAILABLE_SITE"
_POISSON_MEASURE_ROOT_POWER = 40
_POISSON_MEASURE_DEPTH = 92


@dataclass(frozen=True)
class HybridEmissionSourceState:
    source_id: str
    orientation_rad: float
    random_measure_seed: int
    available_fraction: float = 1.0
    integrated_action: float = 0.0
    realized_loop_count: int = 0
    continuum_moment_loop_count: float = 0.0
    availability_flow_regime: str | None = None
    regime_epoch: int = 0

    def __post_init__(self) -> None:
        if (not self.source_id or self.random_measure_seed <= 0
                or not 0.0 <= self.available_fraction <= 1.0
                or self.integrated_action < 0.0
                or self.realized_loop_count < 0
                or self.continuum_moment_loop_count < 0.0):
            raise ValueError("invalid production cavity-emission source state")

    @property
    def effective_loop_count(self) -> float:
        return self.realized_loop_count+self.continuum_moment_loop_count

    @property
    def next_exact_threshold(self) -> float:
        return poisson_measure_next_action(
            self.random_measure_seed, self.integrated_action)


def _counter_rng(seed: int, level: int, index: int, purpose: str):
    digest = hashlib.sha256(
        f"cavity-poisson-v1:{seed}:{level}:{index}:{purpose}".encode()).digest()
    return np.random.Generator(np.random.Philox(
        int.from_bytes(digest[:8], "little")))


def _root_measure_count(seed: int) -> int:
    return int(_counter_rng(seed, 0, 0, "root").poisson(
        2.0**_POISSON_MEASURE_ROOT_POWER))


def _split_measure_count(seed: int, level: int, index: int,
                         parent_count: int) -> int:
    return int(_counter_rng(seed, level, index, "split").binomial(
        parent_count, 0.5))


def poisson_measure_count(seed: int, action: float) -> int:
    x = float(action)
    root_hi = 2.0**_POISSON_MEASURE_ROOT_POWER
    if not 0.0 <= x <= root_hi:
        raise RuntimeError("cavity Poisson compensator exceeds qualified domain")
    count = _root_measure_count(seed)
    lo, hi, level, index, prefix = 0.0, root_hi, 0, 0, 0
    for _ in range(_POISSON_MEASURE_DEPTH):
        if x <= lo:
            return prefix
        if x >= hi:
            return prefix+count
        left = _split_measure_count(seed, level+1, 2*index, count)
        mid = 0.5*(lo+hi)
        if x < mid:
            count, hi, level, index = left, mid, level+1, 2*index
        else:
            prefix += left
            count, lo, level, index = count-left, mid, level+1, 2*index+1
    return prefix+(count if x >= 0.5*(lo+hi) else 0)


def poisson_measure_next_action(seed: int, action: float) -> float:
    rank = poisson_measure_count(seed, action)+1
    root_hi = 2.0**_POISSON_MEASURE_ROOT_POWER
    count = _root_measure_count(seed)
    if rank > count:
        raise RuntimeError("cavity Poisson measure root exhausted")
    lo, hi, level, index = 0.0, root_hi, 0, 0
    for _ in range(_POISSON_MEASURE_DEPTH):
        left = _split_measure_count(seed, level+1, 2*index, count)
        mid = 0.5*(lo+hi)
        if rank <= left:
            count, hi, level, index = left, mid, level+1, 2*index
        else:
            rank -= left
            count, lo, level, index = count-left, mid, level+1, 2*index+1
    return 0.5*(lo+hi)


def initialize_sources(count: int, seed: int) -> tuple[HybridEmissionSourceState, ...]:
    rng = np.random.default_rng(int(seed))
    return tuple(HybridEmissionSourceState(
        source_id=f"cavity-source-{index}",
        orientation_rad=index*math.pi/max(count, 1),
        random_measure_seed=int(rng.integers(1, np.iinfo(np.int64).max)),
    ) for index in range(int(count)))


def _recovery_flow(availability: float, recovery_rate_s: float,
                   duration_s: float) -> tuple[float, float]:
    a0, rate, dt = map(float, (availability, recovery_rate_s, duration_s))
    if rate <= 0.0:
        return a0, a0*dt
    decay = math.exp(-rate*dt)
    return (1.0-(1.0-a0)*decay,
            dt-(1.0-a0)*(1.0-decay)/rate)


def _continuum_flow(availability: float, base_rate_s: float,
                    recovery_rate_s: float, depletion_per_loop: float,
                    duration_s: float) -> tuple[float, float]:
    decay_rate = recovery_rate_s+depletion_per_loop*base_rate_s
    if decay_rate <= 0.0:
        return availability, base_rate_s*availability*duration_s
    equilibrium = recovery_rate_s/decay_rate
    decay = math.exp(-decay_rate*duration_s)
    after = equilibrium+(availability-equilibrium)*decay
    exposure = (equilibrium*duration_s+(availability-equilibrium)
                *(1.0-decay)/decay_rate)
    return after, base_rate_s*exposure


def _regime(source: HybridEmissionSourceState, base_rate_s: float,
            recovery_rate_s: float, depletion_per_loop: float,
            low_count_mu_max: float, continuum_mu_min: float) -> str:
    relaxation = recovery_rate_s+depletion_per_loop*max(base_rate_s, 0.0)
    exposure = (0.0 if base_rate_s <= 0.0 else
                base_rate_s/max(relaxation, np.finfo(float).tiny))
    if source.availability_flow_regime == "LOW_COUNT_EXACT":
        return "CONTINUUM" if exposure >= continuum_mu_min else "LOW_COUNT_EXACT"
    if source.availability_flow_regime == "CONTINUUM":
        return "LOW_COUNT_EXACT" if exposure <= low_count_mu_max else "CONTINUUM"
    return "LOW_COUNT_EXACT" if exposure < continuum_mu_min else "CONTINUUM"


def advance_sources(
    sources: Sequence[HybridEmissionSourceState], base_rates_s: Sequence[float],
    duration_s: float, *, recovery_rate_s: float, depletion_per_loop: float,
    low_count_mu_max: float = 0.25, continuum_mu_min: float = 25.0,
) -> tuple[tuple[HybridEmissionSourceState, ...], int, float]:
    """Advance the production random-time-change owner at fixed base rates."""
    updated = []
    realized_total = 0
    moment_total = 0.0
    for source, base in zip(sources, map(float, base_rates_s)):
        regime = _regime(source, base, recovery_rate_s, depletion_per_loop,
                         low_count_mu_max, continuum_mu_min)
        action0 = source.integrated_action
        if regime == "CONTINUUM":
            availability, increment = _continuum_flow(
                source.available_fraction, base, recovery_rate_s,
                depletion_per_loop, duration_s)
            after = replace(
                source, available_fraction=availability,
                integrated_action=action0+increment,
                continuum_moment_loop_count=(
                    source.continuum_moment_loop_count+increment),
                availability_flow_regime=regime,
                regime_epoch=source.regime_epoch+int(
                    source.availability_flow_regime not in {None, regime}),
            )
            moment_total += increment
        else:
            # Exact low-count path: localize every canonical jump while
            # evolving recovery and applying multiplicative depletion.
            remaining = float(duration_s)
            availability = source.available_fraction
            action = action0
            realized = 0
            while remaining > 0.0:
                threshold = poisson_measure_next_action(
                    source.random_measure_seed, action)
                recovered, exposure = _recovery_flow(
                    availability, recovery_rate_s, remaining)
                possible = action+base*exposure
                if possible < threshold-2e-11*max(1.0, threshold):
                    availability, action, remaining = recovered, possible, 0.0
                    break
                lo, hi = 0.0, remaining
                for _ in range(64):
                    mid = 0.5*(lo+hi)
                    _, partial = _recovery_flow(
                        availability, recovery_rate_s, mid)
                    if action+base*partial < threshold:
                        lo = mid
                    else:
                        hi = mid
                availability, partial = _recovery_flow(
                    availability, recovery_rate_s, hi)
                action = math.nextafter(threshold, math.inf)
                availability *= math.exp(-depletion_per_loop)
                realized += 1
                remaining = max(remaining-hi, 0.0)
            after = replace(
                source, available_fraction=availability,
                integrated_action=action,
                realized_loop_count=source.realized_loop_count+realized,
                availability_flow_regime=regime,
                regime_epoch=source.regime_epoch+int(
                    source.availability_flow_regime not in {None, regime}),
            )
            realized_total += realized
        updated.append(after)
    return tuple(updated), realized_total, moment_total


def next_exact_crossing_time(
    sources: Sequence[HybridEmissionSourceState], base_rates_s: Sequence[float],
    maximum_duration_s: float, *, recovery_rate_s: float,
    depletion_per_loop: float, low_count_mu_max: float = 0.25,
    continuum_mu_min: float = 25.0,
) -> float:
    """Earliest LOW_COUNT_EXACT jump under recovery-only pre-jump flow."""
    crossings = []
    for source, base in zip(sources, map(float, base_rates_s)):
        if _regime(source, base, recovery_rate_s, depletion_per_loop,
                   low_count_mu_max, continuum_mu_min) != "LOW_COUNT_EXACT" or base <= 0.0:
            continue
        needed = poisson_measure_next_action(
            source.random_measure_seed, source.integrated_action)-source.integrated_action
        _, full_exposure = _recovery_flow(
            source.available_fraction, recovery_rate_s, maximum_duration_s)
        if base*full_exposure < needed:
            continue
        lo, hi = 0.0, float(maximum_duration_s)
        for _ in range(64):
            mid = 0.5*(lo+hi)
            _, exposure = _recovery_flow(
                source.available_fraction, recovery_rate_s, mid)
            if base*exposure < needed:
                lo = mid
            else:
                hi = mid
        crossings.append(hi)
    return min(crossings, default=math.inf)


def production_healing_representation(
    sources: Sequence[HybridEmissionSourceState],
) -> str:
    """Return the production embryo-healing outcome from the owned measure.

    This is the mesh-free form of ``embryo_growth_v1.heal_embryo``.  Both an
    actually realized low-count jump and a continuum moment are physical loop
    history.  Only an owner with exactly zero effective emitted population may
    return to a pristine healed site.
    """
    effective = math.fsum(source.effective_loop_count for source in sources)
    return (RESIDUAL_LOOP_BEARING_DEFECT
            if effective > 0.0 else HEALED_AVAILABLE_SITE)


def production_series_limited_vacancy_rate(
    vacancy_raw_area_rate_m2_s: float,
    bulk_accommodation_area_rate_m2_s: float,
) -> float:
    """Exact mesh-free projection of the production accommodation owner."""
    raw = max(float(vacancy_raw_area_rate_m2_s), 0.0)
    accommodation = max(float(bulk_accommodation_area_rate_m2_s), 0.0)
    return (0.0 if raw <= 0.0 or accommodation <= 0.0 else
            1.0/(1.0/raw+1.0/accommodation))


__all__ = [
    "ADAPTER_SCHEMA", "PRODUCTION_OWNER_SCHEMA",
    "PRODUCTION_VACANCY_ACCOMMODATION_OWNER_ID", "HEALED_AVAILABLE_SITE",
    "RESIDUAL_LOOP_BEARING_DEFECT", "HybridEmissionSourceState",
    "advance_sources", "initialize_sources", "next_exact_crossing_time",
    "poisson_measure_count", "poisson_measure_next_action",
    "production_healing_representation",
    "production_series_limited_vacancy_rate",
]
