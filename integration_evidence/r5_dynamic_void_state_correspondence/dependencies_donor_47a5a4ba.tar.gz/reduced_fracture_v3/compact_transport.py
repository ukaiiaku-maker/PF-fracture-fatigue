"""Topology-aware transverse-compartment vacancy transport reduction.

The state is deliberately mesh independent: exact 2-D overlap is used once to
initialize positive compartment measures and operator fields.  Online updates
own only a small structured graph, with the two crack sides disconnected behind
the accepted tip and connected through intact material ahead of it.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import math
from typing import Mapping

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve

from .conservative_projection import triangle_compartment_overlap_areas

KB = 1.380649e-23
SCHEMA = "oneD.v3.compact-transverse-transport/1"


@dataclass(frozen=True)
class CompactTransportState:
    axial_edges_m: tuple[float, ...]
    transverse_edges_m: tuple[float, ...]
    solid_area_m2: tuple[float, ...]
    vacancy_fraction: tuple[float, ...]
    equivalent_plastic_strain: tuple[float, ...]
    forest_density_m2: tuple[float, ...]
    mobile_density_m2: tuple[float, ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]
    exterior_boundary_factor: tuple[float, ...]
    crack_boundary_factor: tuple[float, ...]
    internal_exchange_factor: tuple[tuple[int, int, float], ...]
    site_capture_weight_density: tuple[tuple[str, tuple[float, ...]], ...]
    crack_tip_m: float
    initialization_identity: str
    rt0_diffusion_operator_factor: tuple[tuple[float, ...], ...] = ()
    rt0_consistent_mass_m2: tuple[tuple[float, ...], ...] = ()
    rt0_exterior_flux_response: tuple[float, ...] = ()
    rt0_crack_flux_response: tuple[float, ...] = ()
    schema: str = SCHEMA

    def __post_init__(self) -> None:
        nx, ny = len(self.axial_edges_m)-1, len(self.transverse_edges_m)-1
        count = nx*ny
        if (nx <= 0 or ny < 2 or np.any(np.diff(self.axial_edges_m) <= 0.0)
                or np.any(np.diff(self.transverse_edges_m) <= 0.0)):
            raise ValueError("compact transport grid must be ordered and transverse")
        arrays = (self.solid_area_m2, self.vacancy_fraction,
                  self.equivalent_plastic_strain, self.forest_density_m2,
                  self.mobile_density_m2, self.mean_stress_Pa,
                  self.opening_stress_Pa, self.exterior_boundary_factor,
                  self.crack_boundary_factor)
        if any(len(values) != count for values in arrays):
            raise ValueError("compact fields must own every transverse compartment")
        area = np.asarray(self.solid_area_m2, float)
        if np.any(~np.isfinite(area)) or np.any(area <= 0.0):
            raise ValueError("every retained compact compartment needs positive solid measure")
        concentration = np.asarray(self.vacancy_fraction, float)
        if np.any(~np.isfinite(concentration)) or np.any(concentration < 0.0):
            raise ValueError("compact concentration must be finite and nonnegative")
        if any(len(weights) != count or np.any(np.asarray(weights) < 0.0)
               for _, weights in self.site_capture_weight_density):
            raise ValueError("site capture weights must cover compact state")
        if any(i < 0 or j < 0 or i >= count or j >= count or i == j or value <= 0.0
               for i, j, value in self.internal_exchange_factor):
            raise ValueError("compact internal exchange graph is invalid")
        if not self.initialization_identity:
            raise ValueError("compact state initialization must be declared")
        if self.rt0_diffusion_operator_factor:
            operator = np.asarray(self.rt0_diffusion_operator_factor, float)
            if operator.shape != (count, count) or np.any(~np.isfinite(operator)):
                raise ValueError("condensed RT0 operator has the wrong shape")
            consistent_mass = np.asarray(self.rt0_consistent_mass_m2, float)
            if (consistent_mass.shape != (count, count)
                    or np.any(~np.isfinite(consistent_mass))):
                raise ValueError("condensed RT0 mass has the wrong shape")
            if (len(self.rt0_exterior_flux_response) != count
                    or len(self.rt0_crack_flux_response) != count):
                raise ValueError("condensed RT0 boundary responses are incomplete")

    @property
    def shape(self) -> tuple[int, int]:
        return len(self.axial_edges_m)-1, len(self.transverse_edges_m)-1

    def line_average(self, values: tuple[float, ...] | np.ndarray) -> np.ndarray:
        nx, ny = self.shape
        area = np.asarray(self.solid_area_m2, float).reshape(nx, ny)
        field = np.asarray(values, float).reshape(nx, ny)
        return np.sum(area*field, axis=1)/np.sum(area, axis=1)

    @property
    def line_solid_area_m2(self) -> np.ndarray:
        return np.sum(np.asarray(self.solid_area_m2).reshape(self.shape), axis=1)


@dataclass(frozen=True)
class CompactTransportIncrement:
    equivalent_plastic_strain_increment: tuple[float, ...]
    forest_density_m2: tuple[float, ...]
    mobile_density_m2: tuple[float, ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]
    plastic_vacancy_source_rate_s: tuple[float, ...]
    climb_equilibrium_fraction: tuple[float, ...]


@dataclass(frozen=True)
class CompactTransportResult:
    state: CompactTransportState
    capture_by_site_area_m2: tuple[tuple[str, float], ...]
    old_inventory_area_m2: float
    new_inventory_area_m2: float
    plastic_source_area_m2: float
    climb_loss_area_m2: float
    climb_emission_area_m2: float
    exterior_loss_area_m2: float
    exterior_gain_area_m2: float
    crack_loss_area_m2: float
    crack_gain_area_m2: float
    conservation_residual_area_m2: float


def project_compact_state(
    *, nodes_xy_m: np.ndarray, elements: np.ndarray,
    axial_edges_m: np.ndarray, transverse_edges_m: np.ndarray,
    fields_by_name: Mapping[str, np.ndarray], boundary_faces,
    capture_weights_by_site: Mapping[str, np.ndarray], crack_tip_m: float,
    initialization_identity: str,
) -> CompactTransportState:
    """Create the one allowed reference projection into an autonomous state."""
    overlap = triangle_compartment_overlap_areas(
        nodes_xy_m, elements, axial_edges_m, transverse_edges_m)
    flat = overlap.reshape((-1, overlap.shape[-1]))
    area = np.sum(flat, axis=1)
    if np.any(area <= 64.0*np.finfo(float).tiny):
        raise RuntimeError("selected compact grid contains an empty solid compartment")
    intensive = lambda values: flat@np.asarray(values, float)/area
    exterior = np.zeros(len(area)); crack = np.zeros(len(area))
    nx, ny = overlap.shape[:2]
    centroids = np.asarray(nodes_xy_m)[np.asarray(elements, int)].mean(axis=1)
    owner_compartment = np.ravel_multi_index((
        np.clip(np.searchsorted(axial_edges_m, centroids[:, 0])-1, 0, nx-1),
        np.clip(np.searchsorted(transverse_edges_m, centroids[:, 1])-1, 0, ny-1),
    ), (nx, ny))
    exchanges: dict[tuple[int, int], float] = {}
    for face in boundary_faces:
        kind = getattr(face.kind, "value", str(face.kind))
        if kind == "INTACT_INTERIOR_INTERFACE":
            first, second = (int(value) for value in face.owner_elements)
            i, j = sorted((int(owner_compartment[first]),
                           int(owner_compartment[second])))
            if i != j:
                exchanges[(i, j)] = exchanges.get((i, j), 0.0) + (
                    float(face.length_m)/max(math.fsum(face.owner_distances_m), 1.0e-300))
            continue
        if kind not in {"EXTERNAL_FREE_SURFACE", "CRACK_FREE_SURFACE",
                        "MERGED_CAVITY_CRACK_WAKE"}:
            continue
        ix = int(np.clip(np.searchsorted(axial_edges_m, face.center_xy_m[0])-1, 0, nx-1))
        # Coincident crack faces have the same geometric midpoint.  Their
        # topology-owned side tag, not floating-point y roundoff, selects the
        # concentration owner.  side=+1 is the upper trace and side=-1 the
        # lower trace.
        transverse_coordinate = float(face.center_xy_m[1])
        if kind in {"CRACK_FREE_SURFACE", "MERGED_CAVITY_CRACK_WAKE"} \
                and int(getattr(face, "side", 0)) != 0:
            zero_index = int(np.searchsorted(transverse_edges_m, 0.0))
            if (zero_index < len(transverse_edges_m)
                    and transverse_edges_m[zero_index] == 0.0):
                iy = zero_index if int(face.side) > 0 else zero_index-1
            else:
                transverse_coordinate = math.copysign(
                    max(abs(transverse_coordinate), np.finfo(float).eps),
                    int(face.side))
                iy = int(np.searchsorted(
                    transverse_edges_m, transverse_coordinate)-1)
            iy = int(np.clip(iy, 0, ny-1))
        else:
            iy = int(np.clip(np.searchsorted(
                transverse_edges_m, transverse_coordinate)-1, 0, ny-1))
        value = float(face.length_m)/max(float(face.owner_distances_m[0]), 1.0e-300)
        target = exterior if kind == "EXTERNAL_FREE_SURFACE" else crack
        target[np.ravel_multi_index((ix, iy), (nx, ny))] += value
    capture = []
    for site_id, element_weights in capture_weights_by_site.items():
        capture.append((site_id, tuple(intensive(np.asarray(element_weights, float)))))
    required = ("vacancy_fraction", "equivalent_plastic_strain", "forest_density_m2",
                "mobile_density_m2", "mean_stress_Pa", "opening_stress_Pa")
    missing = set(required)-set(fields_by_name)
    if missing:
        raise ValueError(f"compact projection missing fields: {sorted(missing)}")
    return CompactTransportState(
        tuple(axial_edges_m), tuple(transverse_edges_m), tuple(area),
        *(tuple(intensive(fields_by_name[name])) for name in required),
        tuple(exterior), tuple(crack),
        tuple((i, j, value) for (i, j), value in sorted(exchanges.items())),
        tuple(capture), float(crack_tip_m),
        initialization_identity,
    )


def _connections(state: CompactTransportState, diffusivity: float, ratio: float):
    if state.internal_exchange_factor:
        return [(i, j, diffusivity*factor*ratio)
                for i, j, factor in state.internal_exchange_factor]
    nx, ny = state.shape
    x = np.asarray(state.axial_edges_m); y = np.asarray(state.transverse_edges_m)
    xc = 0.5*(x[:-1]+x[1:]); yc = 0.5*(y[:-1]+y[1:])
    area = np.asarray(state.solid_area_m2).reshape(nx, ny)
    geometric = np.diff(x)[:, None]*np.diff(y)[None, :]
    fraction = np.minimum(area/geometric, 1.0)
    result = []
    for ix in range(nx-1):
        for iy in range(ny):
            factor = (np.diff(y)[iy]*min(fraction[ix, iy], fraction[ix+1, iy])
                      /(xc[ix+1]-xc[ix]))
            result.append((np.ravel_multi_index((ix, iy), (nx, ny)),
                           np.ravel_multi_index((ix+1, iy), (nx, ny)),
                           diffusivity*factor*ratio))
    for ix in range(nx):
        for iy in range(ny-1):
            # The accepted crack is an exact interface. Communication across
            # y=0 survives only in intact material ahead of its current tip.
            if (abs(y[iy+1]) <= 32.0*np.spacing(max(abs(y[iy+1]), 1.0))
                    and xc[ix] <= state.crack_tip_m):
                continue
            factor = (np.diff(x)[ix]*min(fraction[ix, iy], fraction[ix, iy+1])
                      /(yc[iy+1]-yc[iy]))
            result.append((np.ravel_multi_index((ix, iy), (nx, ny)),
                           np.ravel_multi_index((ix, iy+1), (nx, ny)),
                           diffusivity*factor*ratio))
    return result


def stress_drift_face_rate(
    conductance_area_per_s: float, concentration_first: float,
    concentration_second: float, stress_first_Pa: float,
    stress_second_Pa: float, coupling_volume_m3: float, temperature_K: float,
) -> float:
    """Oriented integrated stress-drift rate with consistent dimensions."""
    mobility = 0.5*(
        concentration_first*(1.0-concentration_first)
        +concentration_second*(1.0-concentration_second))
    return (float(conductance_area_per_s)*float(coupling_volume_m3)*mobility
            *(float(stress_second_Pa)-float(stress_first_Pa))
            /(KB*float(temperature_K)))


def advance_compact_transport(
    state: CompactTransportState, increment: CompactTransportIncrement, *,
    duration_s: float, temperature_K: float, diffusivity_m2_s: float,
    inventory_ratio: float, vacancy_stress_coupling_volume_m3: float,
    climb_capture_efficiency: float, site_capture_rate_area_per_s: float,
    exterior_sink_efficiency: float, equilibrium_surface_fraction: float,
) -> CompactTransportResult:
    """Backward-Euler conservative graph solve with one-sided site capture."""
    dt = float(duration_s); count = len(state.solid_area_m2)
    arrays = [np.asarray(getattr(increment, name), float) for name in (
        "equivalent_plastic_strain_increment", "forest_density_m2",
        "mobile_density_m2", "mean_stress_Pa", "opening_stress_Pa",
        "plastic_vacancy_source_rate_s", "climb_equilibrium_fraction")]
    if any(value.shape != (count,) or np.any(~np.isfinite(value)) for value in arrays):
        raise ValueError("compact increment fields must cover every compartment")
    dep, rho, mobile, mean, opening, source, ceq = arrays
    if np.any(source < 0.0) or np.any(ceq < 0.0) or np.any(ceq > 1.0):
        raise ValueError("compact source/equilibrium fields are outside physical bounds")
    area = np.asarray(state.solid_area_m2); mass = area*inventory_ratio
    old = np.asarray(state.vacancy_fraction)
    climb_rate = diffusivity_m2_s*climb_capture_efficiency*rho
    climb_g = mass*climb_rate
    condensed_rt0 = bool(state.rt0_diffusion_operator_factor)
    ext_g = (np.zeros(count) if condensed_rt0 else
             diffusivity_m2_s*exterior_sink_efficiency*inventory_ratio
             *np.asarray(state.exterior_boundary_factor))
    crack_g = (np.zeros(count) if condensed_rt0 else
               diffusivity_m2_s*inventory_ratio
               *np.asarray(state.crack_boundary_factor))
    time_mass = (inventory_ratio*np.asarray(state.rt0_consistent_mass_m2)
                 if condensed_rt0 else np.diag(mass))
    diagonal = mass*source+climb_g+ext_g+crack_g
    rhs = time_mass@old/dt+mass*source+climb_g*ceq+(ext_g+crack_g)*equilibrium_surface_fraction
    rows=[]; cols=[]; data=[]
    def add(i, j, value): rows.append(i); cols.append(j); data.append(value)
    time_rows,time_cols=np.nonzero(time_mass)
    for i,j in zip(time_rows,time_cols): add(int(i),int(j),time_mass[i,j]/dt)
    for i in range(count): add(i, i, diagonal[i])
    nx, ny = state.shape
    if condensed_rt0:
        operator = (diffusivity_m2_s*inventory_ratio
                    *np.asarray(state.rt0_diffusion_operator_factor))
        base_operator = sparse.csr_matrix(operator)
        rhs += operator@np.ones(count)*equilibrium_surface_fraction
    else:
        base_operator = sparse.csr_matrix((count, count))
    connections = _connections(state, diffusivity_m2_s, inventory_ratio)
    for i, j, conductance in ([] if condensed_rt0 else connections):
        add(i, i, conductance); add(j, j, conductance)
        add(i, j, -conductance); add(j, i, -conductance)
    # Stress drift is an integrated face flux.  ``conductance`` already owns
    # D*face_measure/distance, so multiplying by the stress *difference* (not
    # its gradient) restores the missing distance.  The c(1-c) mobility is
    # dimensionless; the final coefficient therefore has inventory/time units.
    for i, j, conductance in connections:
        drift = stress_drift_face_rate(
            conductance, old[i], old[j], mean[i], mean[j],
            vacancy_stress_coupling_volume_m3, temperature_K)
        donor, receiver = (i, j) if drift >= 0.0 else (j, i)
        add(donor, donor, abs(drift)); add(receiver, donor, -abs(drift))
    base = sparse.csr_matrix((data, (rows, cols)), shape=(count, count))+base_operator
    capture_density = {site_id: np.asarray(weights, float)
                       for site_id, weights in state.site_capture_weight_density}
    active = old > ceq
    capture_vectors = {}
    for _ in range(64):
        capture_vectors = {
            site_id: mass*site_capture_rate_area_per_s*weights*active
            for site_id, weights in capture_density.items()}
        total = (np.sum(tuple(capture_vectors.values()), axis=0)
                 if capture_vectors else np.zeros(count))
        matrix = base+sparse.diags(total)
        candidate = np.asarray(spsolve(matrix, rhs+total*ceq), float)
        next_active = candidate > ceq
        if np.array_equal(active, next_active):
            break
        active = next_active
    else:
        raise RuntimeError("compact excess-capture active set did not converge")
    if np.any(candidate < -1.0e-14) or np.any(~np.isfinite(candidate)):
        raise RuntimeError("compact transport produced invalid concentration")
    new = np.maximum(candidate, 0.0)
    captures = tuple((site_id, float(dt*np.dot(vector, np.maximum(new-ceq, 0.0))))
                     for site_id, vector in capture_vectors.items())
    climb_exchange = dt*climb_g*(new-ceq)
    if condensed_rt0:
        ext_exchange = (dt*diffusivity_m2_s*inventory_ratio
                        *np.asarray(state.rt0_exterior_flux_response)
                        *(new-equilibrium_surface_fraction))
        crack_exchange = (dt*diffusivity_m2_s*inventory_ratio
                          *np.asarray(state.rt0_crack_flux_response)
                          *(new-equilibrium_surface_fraction))
    else:
        ext_exchange = dt*ext_g*(new-equilibrium_surface_fraction)
        crack_exchange = dt*crack_g*(new-equilibrium_surface_fraction)
    old_inventory=float(np.dot(mass, old)); new_inventory=float(np.dot(mass, new))
    source_total=float(dt*np.dot(mass, source*(1.0-new)))
    loss=lambda value: float(np.sum(np.maximum(value, 0.0)))
    gain=lambda value: float(np.sum(np.maximum(-value, 0.0)))
    captured=math.fsum(value for _, value in captures)
    residual=(old_inventory+source_total+gain(climb_exchange)+gain(ext_exchange)
              +gain(crack_exchange)-new_inventory-loss(climb_exchange)
              -loss(ext_exchange)-loss(crack_exchange)-captured)
    tolerance=1.0e-10*max(old_inventory+source_total, 1.0e-30)
    if abs(residual) > tolerance:
        raise RuntimeError(f"compact transport conservation failed: {residual:.6e}")
    updated=replace(
        state, vacancy_fraction=tuple(new),
        equivalent_plastic_strain=tuple(
            np.asarray(state.equivalent_plastic_strain)+dep),
        forest_density_m2=tuple(rho), mobile_density_m2=tuple(mobile),
        mean_stress_Pa=tuple(mean), opening_stress_Pa=tuple(opening))
    return CompactTransportResult(
        updated, captures, old_inventory, new_inventory, source_total,
        loss(climb_exchange), gain(climb_exchange), loss(ext_exchange),
        gain(ext_exchange), loss(crack_exchange), gain(crack_exchange), residual)


__all__ = [
    "CompactTransportIncrement", "CompactTransportResult", "CompactTransportState",
    "advance_compact_transport", "project_compact_state",
    "stress_drift_face_rate",
]
