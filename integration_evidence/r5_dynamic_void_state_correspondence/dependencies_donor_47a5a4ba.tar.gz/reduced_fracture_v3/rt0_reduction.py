"""Conservative restriction and Galerkin condensation of an RT0/P0 operator."""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.sparse.linalg import spsolve


@dataclass(frozen=True)
class CondensedRT0P0Operators:
    solid_measure_m2: np.ndarray
    restriction: np.ndarray
    reconstruction: np.ndarray
    consistent_mass_m2: np.ndarray
    diffusion_factor: np.ndarray
    exterior_flux_response: np.ndarray
    crack_flux_response: np.ndarray

    def verify(self, element_measure_m2: np.ndarray) -> dict[str, float]:
        area=np.asarray(element_measure_m2,float)
        ones_c=np.ones(len(self.solid_measure_m2)); ones_e=np.ones(len(area))
        values={
            "partition_of_unity_inf":float(np.linalg.norm(
                self.reconstruction@ones_c-ones_e,ord=np.inf)),
            "restriction_constant_inf":float(np.linalg.norm(
                self.restriction@ones_e-ones_c,ord=np.inf)),
            "inventory_adjoint_inf":float(np.linalg.norm(
                self.solid_measure_m2@self.restriction-area,ord=np.inf)),
            "mass_row_sum_inf":float(np.linalg.norm(
                self.consistent_mass_m2@ones_c-self.solid_measure_m2,ord=np.inf)),
            "diffusion_symmetry_inf":float(np.linalg.norm(
                self.diffusion_factor-self.diffusion_factor.T,ord=np.inf)),
        }
        return values


def condense_rt0_p0_operators(
    *, overlap_area_m2: np.ndarray, element_area_m2: np.ndarray,
    rt0_mass_matrix: sparse.spmatrix, divergence_operator: sparse.spmatrix,
    unknown_faces, exterior_kinds: set[str], crack_kinds: set[str],
) -> CondensedRT0P0Operators:
    """Build an operator-faithful conservative P0 reduction.

    ``overlap_area_m2[c,e]`` is the exact intersection measure.  Restriction
    conserves extensive inventory; reconstruction preserves constants.  The
    consistent mass and flux operator use the same pair, avoiding the mixed
    normalizations that previously contaminated the compact evolution.
    """
    overlap=np.asarray(overlap_area_m2,float); area=np.asarray(element_area_m2,float)
    if (overlap.ndim != 2 or overlap.shape[1] != len(area)
            or np.any(overlap < 0.0) or np.any(area <= 0.0)):
        raise ValueError("invalid overlap/element measures")
    solid=np.sum(overlap,axis=1)
    if np.any(solid <= 0.0):
        raise ValueError("every reduced compartment requires positive solid measure")
    if not np.allclose(np.sum(overlap,axis=0),area,rtol=2.0e-12,atol=1.0e-30):
        raise RuntimeError("compact overlaps do not partition the native P0 domain")
    restriction=overlap/solid[:,None]
    reconstruction=overlap.T/area[:,None]
    consistent_mass=reconstruction.T@(area[:,None]*reconstruction)
    M=sparse.csc_matrix(rt0_mass_matrix); B=sparse.csr_matrix(divergence_operator)
    flux_response=splu(M).solve(np.asarray(B.T@reconstruction))
    diffusion=np.asarray(reconstruction.T@(B@flux_response))
    diffusion=0.5*(diffusion+diffusion.T)
    exterior=np.zeros(len(solid)); crack=np.zeros(len(solid))
    for index,face in enumerate(unknown_faces):
        kind=getattr(face.kind,"value",str(face.kind))
        if kind in exterior_kinds: exterior += flux_response[index]
        if kind in crack_kinds: crack += flux_response[index]
    result=CondensedRT0P0Operators(
        solid,restriction,reconstruction,consistent_mass,diffusion,exterior,crack)
    audit=result.verify(area)
    tolerance=5.0e-11
    if any(value > tolerance for value in audit.values()):
        raise RuntimeError(f"RT0/P0 reduction normalization failed: {audit}")
    return result


def identity_overlap(element_area_m2: np.ndarray) -> np.ndarray:
    """Reduction-disabled basis: one reduced coordinate per native P0 cell."""
    return np.diag(np.asarray(element_area_m2,float))


def condense_rt0_flux_forcing(
    *, reconstruction: np.ndarray, rt0_mass_matrix: sparse.spmatrix,
    divergence_operator: sparse.spmatrix, native_flux_rhs: np.ndarray,
) -> np.ndarray:
    """Galerkin projection of any current native RT0 flux forcing.

    This includes nonlinear stress-driven forcing assembled from the current
    concentration and accepted stress.  With the identity basis it is exactly
    the native eliminated P0 right-hand side, so drift qualification is not
    conflated with the compact graph approximation.
    """
    R=np.asarray(reconstruction,float)
    M=sparse.csc_matrix(rt0_mass_matrix)
    B=sparse.csr_matrix(divergence_operator)
    forcing=np.asarray(native_flux_rhs,float)
    if forcing.shape != (M.shape[0],) or R.shape[0] != B.shape[0]:
        raise ValueError("native RT0 forcing dimensions are inconsistent")
    return np.asarray(R.T@(B@splu(M).solve(forcing)),float)


def solve_identity_condensed_mixed_system(
    mixed_matrix: sparse.spmatrix, mixed_rhs: np.ndarray, flux_dof_count: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Eliminate native RT0 fluxes without reducing the P0 state.

    The input is the complete production mixed system, so its right-hand side
    already contains current mobility/stress drift, physical boundary data,
    backward-Euler mass, sources, climb, and capture reactions.
    """
    system=sparse.csc_matrix(mixed_matrix); rhs=np.asarray(mixed_rhs,float)
    nq=int(flux_dof_count)
    M=system[:nq,:nq].tocsc()
    B=(-system[nq:,:nq]).tocsr()
    C=(-system[nq:,nq:]).tocsc()
    flux_rhs=rhs[:nq]; reaction_rhs=-rhs[nq:]
    factor=splu(M)
    minv_bt=factor.solve(np.asarray(B.T.toarray()))
    forcing=np.asarray(B@factor.solve(flux_rhs)).reshape(-1)
    schur=sparse.csc_matrix(B@minv_bt)+C
    concentration=np.asarray(splu(schur).solve(reaction_rhs-forcing),float)
    flux=np.asarray(factor.solve(flux_rhs+np.asarray(B.T@concentration).reshape(-1)),float)
    # The native mixed systems are strongly scaled.  One residual correction
    # in the original coordinates prevents block-elimination roundoff from
    # appearing as a flux discrepancy while leaving the identity-basis
    # solution unchanged algebraically.
    candidate=np.r_[flux,concentration]
    correction=np.asarray(spsolve(system,rhs-system@candidate),float)
    flux=flux+correction[:nq]
    concentration=concentration+correction[nq:]
    return flux,concentration


__all__=["CondensedRT0P0Operators","condense_rt0_flux_forcing",
         "condense_rt0_p0_operators","identity_overlap",
         "solve_identity_condensed_mixed_system"]
