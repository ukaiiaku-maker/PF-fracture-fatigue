"""Atomic restart for the executable V3 physical-line state."""
from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum
import hashlib
import json
import os
from pathlib import Path
import pickle
from typing import Any, Mapping

import numpy as np

from .physical import ExecutableOneDState, SCHEMA


def _encode(value: Any):
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        encoded = {}
        for item in fields(value):
            field_value = getattr(value, item.name, ())
            # Empty optional operator/projection extensions are semantically
            # the historical default and are omitted so existing physical
            # checkpoints retain their complete-state fingerprint.
            if ((item.name in {"solid_fraction"} and field_value == ())
                    or (item.name == "compact_transport_state"
                        and field_value is None)
                    or (item.name == "compact_mechanical_state"
                        and field_value is None)
                    or (item.name == "native_incremental_owner_state"
                        and field_value is None)
                    or (item.name in {
                        "internal_exchange_factor",
                        "rt0_diffusion_operator_factor",
                        "rt0_consistent_mass_m2",
                        "rt0_exterior_flux_response",
                        "rt0_crack_flux_response",
                    } and field_value == ())):
                continue
            encoded[item.name] = _encode(field_value)
        return encoded
    if isinstance(value, Mapping):
        return {str(key): _encode(item) for key, item in sorted(value.items())}
    if isinstance(value, (tuple, list)):
        return [_encode(item) for item in value]
    if isinstance(value, np.ndarray):
        return _encode(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def physical_fingerprint(state: ExecutableOneDState) -> str:
    payload = json.dumps(
        _encode(state), sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode()
    return hashlib.sha256(payload).hexdigest()


def write_physical_checkpoint(state: ExecutableOneDState, path: str | Path) -> dict[str, Any]:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = pickle.dumps(state, protocol=5)
    payload_sha = hashlib.sha256(payload).hexdigest()
    state_file = destination.name + "." + payload_sha + ".state.pkl"
    state_path = destination.parent / state_file
    temporary_state = state_path.with_suffix(state_path.suffix + ".tmp")
    temporary_state.write_bytes(payload)
    os.replace(temporary_state, state_path)
    manifest = {
        "schema": "oneD.v3.physical-checkpoint/1",
        "state_schema": SCHEMA,
        "state_file": state_file,
        "state_payload_sha256": payload_sha,
        "complete_state_fingerprint": physical_fingerprint(state),
        "physical_time_s": state.physical_time_s,
        "cycle_count": state.cycle_count,
    }
    temporary_manifest = destination.with_suffix(destination.suffix + ".tmp")
    temporary_manifest.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    os.replace(temporary_manifest, destination)
    return manifest


def restore_physical_checkpoint(path: str | Path) -> ExecutableOneDState:
    source = Path(path)
    manifest = json.loads(source.read_text())
    payload = (source.parent / manifest["state_file"]).read_bytes()
    if hashlib.sha256(payload).hexdigest() != manifest["state_payload_sha256"]:
        raise RuntimeError("physical checkpoint payload hash mismatch")
    state = pickle.loads(payload)
    if not isinstance(state, ExecutableOneDState):
        raise TypeError("checkpoint does not contain an executable V3 state")
    if physical_fingerprint(state) != manifest["complete_state_fingerprint"]:
        raise RuntimeError("physical checkpoint state fingerprint mismatch")
    return state


__all__ = [
    "physical_fingerprint", "restore_physical_checkpoint", "write_physical_checkpoint",
]
