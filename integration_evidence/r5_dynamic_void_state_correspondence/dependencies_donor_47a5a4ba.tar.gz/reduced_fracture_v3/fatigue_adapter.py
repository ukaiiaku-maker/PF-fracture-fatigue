"""Adapter from the existing fatigue waveform owner to physical-time V3."""
from __future__ import annotations

from typing import Callable, Any

import numpy as np

from .physical import ExecutableOneDState, PhysicalIncrement, advance_signed_waveform


def advance_existing_fatigue_waveform(
    state: ExecutableOneDState,
    waveform: Any,
    mechanics: Callable[[ExecutableOneDState, float, float], PhysicalIncrement],
    *,
    cycles: int,
    n_phase: int = 96,
) -> ExecutableOneDState:
    """Consume ``fatigue_v1.FatigueWaveform`` without changing its semantics."""
    if n_phase < 4:
        raise ValueError("fatigue waveform requires at least four phase samples")
    if not hasattr(waveform, "K_phase") or not hasattr(waveform, "period_s"):
        raise TypeError("adapter requires the existing fatigue waveform interface")
    phases = 2.0*np.pi*np.arange(n_phase, dtype=float)/n_phase
    loads = np.asarray(waveform.K_phase(phases), float)
    if loads.shape != phases.shape or np.any(~np.isfinite(loads)):
        raise ValueError("fatigue waveform returned invalid signed loading")
    duration = float(waveform.period_s)/n_phase
    segments = tuple((duration, float(load)) for load in loads)
    return advance_signed_waveform(state, segments, mechanics, cycles=cycles)


__all__ = ["advance_existing_fatigue_waveform"]
