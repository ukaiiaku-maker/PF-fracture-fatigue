"""Standalone comparison gate used by the reduced incremental solver."""
from __future__ import annotations
import numpy as np


def rel(a, b, floor=1.0e-30):
    aa, bb = np.asarray(a, float), np.asarray(b, float)
    return float(np.linalg.norm(aa-bb) / max(np.linalg.norm(bb), floor))


def compare_leg(actual, reference, reference_state):
    rm, am = reference["mechanics"], actual["mechanics"]
    rs = {item["site_id"]: item for item in reference["final_sites"]}
    sites = {item["site_id"]: item for item in actual["sites"]}
    kinetic = lambda row: float(row["canonical_directional_rows"][0]["G_kinetic_used_J_per_m2"])
    channels = {
        "signed_plastic_strain": rel(actual["ep_gp"], reference_state.ep_gp),
        "forest_density": rel(actual["rho_gp"], reference_state.rho_gp),
        "vacancy_concentration": rel(actual["vacancy_fraction_gp"],
            reference_state.vacancy_transport_state_v2.vacancy_fraction_gp),
        "source_tensor": rel(actual["canonical_source_tensor_Pa"], reference["canonical_source_tensor_Pa"]),
        "kinetic_G": rel(kinetic(actual["canonical_drive"]), kinetic(reference["canonical_drive"])),
        "top_reaction": rel(am["top_reaction_N_per_m"], rm["top_reaction_N_per_m"]),
        "bottom_reaction": rel(am["bottom_reaction_N_per_m"], rm["bottom_reaction_N_per_m"]),
        "compliance": rel(am["compliance_m2_per_N"], rm["compliance_m2_per_N"]),
        "recoverable_energy": rel(am["recoverable_energy_J_per_m"], rm["recoverable_energy_J_per_m"]),
        "plastic_work": rel(actual["plastic_work_J_per_m"], reference["plastic_work_J_per_m"]),
    }
    budget = {key: rel(actual["budget"][key], reference["budget"][key], 1.0e-28)
              for key in reference["budget"]}
    signed_climb = lambda v: (v["dislocation_climb_annihilation_area_m2"]
                              - v["dislocation_climb_emission_area_m2"])
    required = {
        "plastic_production": rel(actual["budget"]["plastic_production_area_m2"], reference["budget"]["plastic_production_area_m2"], 1e-28),
        "signed_climb": rel(signed_climb(actual["budget"]), signed_climb(reference["budget"]), 1e-28),
        "external_exchange": rel(actual["budget"]["external_surface_absorption_area_m2"], reference["budget"]["external_surface_absorption_area_m2"], 1e-28),
        "crack_exchange": rel(actual["budget"]["crack_surface_absorption_area_m2"], reference["budget"]["crack_surface_absorption_area_m2"], 1e-28),
        "site_capture": rel(actual["budget"]["subgrid_capture_area_m2"], reference["budget"]["subgrid_capture_area_m2"], 1e-28),
        "waiting_inventory": rel(actual["budget"]["reserved_embryo_inventory_area_m2"], reference["budget"]["reserved_embryo_inventory_area_m2"], 1e-28),
    }
    rows = []; gates = []
    small = lambda a,b: abs(float(a)-float(b)) <= 1e-24 or rel(a,b,1e-30) <= 1e-1
    for site_id in sorted(rs):
        a,b=sites[site_id],rs[site_id]
        rows.append({"site_id":site_id,"radius_relative_error":rel(a["radius_m"],b["radius_m"]),
            "vacancy_area_relative_error":rel(a["vacancy_derived_area_m2"],b["vacancy_derived_area_m2"],1e-30),
            "waiting_inventory_relative_error":rel(a["captured_unaccommodated_vacancy_area_m2"],b["captured_unaccommodated_vacancy_area_m2"],1e-30),
            "emission_area_relative_error":rel(a["dislocation_derived_area_m2"],b["dislocation_derived_area_m2"],1e-30),
            "loop_count_absolute_error":abs(a["effective_loop_count"]-b["effective_loop_count"]),
            "availability_absolute_error":float(np.max(np.abs(np.asarray(a["source_availability"])-np.asarray(b["source_availability"]))))})
        gates.append(small(a["vacancy_derived_area_m2"],b["vacancy_derived_area_m2"])
            and small(a["captured_unaccommodated_vacancy_area_m2"],b["captured_unaccommodated_vacancy_area_m2"])
            and small(a["dislocation_derived_area_m2"],b["dislocation_derived_area_m2"])
            and rows[-1]["loop_count_absolute_error"] <= 1e-8
            and rows[-1]["availability_absolute_error"] <= 5e-2)
    passing=(max(channels[k] for k in ("signed_plastic_strain","forest_density","source_tensor","top_reaction","bottom_reaction","compliance"))<=5e-3
        and channels["recoverable_energy"]<=2e-2 and channels["kinetic_G"]<=5e-2
        and channels["plastic_work"]<=2e-2 and channels["vacancy_concentration"]<=2e-2
        and max(required.values(),default=0.0)<=1e-1 and actual["events"]==reference["events"]
        and all(row["radius_relative_error"]<=2e-2 for row in rows) and all(gates))
    return {"channels":channels,"budget_increment_relative_errors":budget,
        "required_signed_budget_relative_errors":required,"sites":rows,
        "events_equal":actual["events"]==reference["events"],"pass":passing}
