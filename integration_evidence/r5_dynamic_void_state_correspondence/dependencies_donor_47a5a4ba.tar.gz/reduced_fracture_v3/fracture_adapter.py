"""Transactional adapter for the complete V2 production fracture advance.

The V3 scheduler owns an immutable serialized V2 closure.  Preview restores a
private clone and invokes ``advance_interval`` itself, so process-zone fields,
wake fields, threshold renewal, geometry publication and backend vetoes retain
their V2 implementation.  Commit only swaps in the accepted serialized clone.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import base64
import hashlib
import pickle
from types import SimpleNamespace
from typing import Any, Mapping

from reduced_fracture_v2.native_closure import (
    FEMCZMNativeStateClosure, NativeIntervalResult, PFNativeStateClosure,
)
from reduced_fracture_v2.state import ReducedState


SCHEMA = "oneD.v3.complete-v2-fracture-adapter/1"
_CLOSURE_TYPES = (PFNativeStateClosure, FEMCZMNativeStateClosure)


@dataclass(frozen=True)
class ReducedMechanicsDriveBinding:
    """Reduced-history correction applied at the native PF drive boundary."""
    native_K_scale: float = 1.0
    source_identity: str = "UNCHANGED_NATIVE_MECHANICS"

    def __post_init__(self) -> None:
        if not (0.0 <= float(self.native_K_scale) < float("inf")):
            raise ValueError("native fracture-drive scale must be finite and nonnegative")
        if not self.source_identity:
            raise ValueError("mechanics binding requires a source identity")


class _ScaledPFMechanicsProvider:
    """Keep laboratory opening fixed while scaling the PF-native K-like drive."""
    def __init__(self, base: Any, binding: ReducedMechanicsDriveBinding):
        self.base = base
        self.binding = binding

    def evaluate(self, extension_m: float, opening_m: float) -> Any:
        state = self.base.evaluate(extension_m, opening_m)
        scale = float(self.binding.native_K_scale)
        if state.pf_native_KJ_Pa_sqrt_m is None:
            raise RuntimeError("reduced PF mechanics binding requires a native KJ drive")
        updates = dict(
            native_drive=(None if getattr(state, "native_drive", None) is None
                          else float(state.native_drive)*scale),
            pf_native_KJ_Pa_sqrt_m=float(state.pf_native_KJ_Pa_sqrt_m)*scale,
            pf_native_J_J_m2=(None if getattr(state, "pf_native_J_J_m2", None) is None
                              else float(state.pf_native_J_J_m2)*scale**2),
            map_qualification=(
                f"{getattr(state, 'map_qualification', None) or 'PF_NATIVE'}"
                "+REDUCED_HISTORY_SCALE:"
                f"{self.binding.source_identity}"),
        )
        try:
            return replace(state, **updates)
        except TypeError:
            values = vars(state).copy()
            values.update(updates)
            return SimpleNamespace(**values)


def _payload(closure: Any) -> tuple[str, str]:
    raw = pickle.dumps(closure, protocol=5)
    return base64.b64encode(raw).decode("ascii"), hashlib.sha256(raw).hexdigest()


def _restore(payload_b64: str) -> Any:
    closure = pickle.loads(base64.b64decode(payload_b64.encode("ascii")))
    if not isinstance(closure, _CLOSURE_TYPES):
        raise TypeError("fracture owner does not contain a production V2 closure")
    return closure


@dataclass(frozen=True)
class V2FractureOwnerState:
    backend: str
    closure_payload_b64: str
    closure_payload_sha256: str
    last_forward_state: Mapping[str, Any]
    accepted_intervals: int = 0
    native_backend_calls: int = 0
    last_mechanics_binding: Mapping[str, Any] | None = None
    schema: str = SCHEMA

    def __post_init__(self) -> None:
        if self.schema != SCHEMA or self.backend not in {"PF", "FEMCZM"}:
            raise ValueError("invalid complete V2 fracture owner")
        raw = base64.b64decode(self.closure_payload_b64.encode("ascii"))
        if hashlib.sha256(raw).hexdigest() != self.closure_payload_sha256:
            raise ValueError("V2 fracture closure payload fingerprint mismatch")

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256((
            self.schema + ":" + self.backend + ":" + self.closure_payload_sha256
            + ":" + str(self.accepted_intervals) + ":" + str(self.native_backend_calls)
            + ":" + repr(self.last_mechanics_binding)
        ).encode()).hexdigest()


@dataclass(frozen=True)
class V2FracturePreview:
    owner_before_fingerprint: str
    proposed_owner: V2FractureOwnerState
    interval_result: NativeIntervalResult

    @property
    def fired(self) -> bool:
        return bool(self.interval_result.fired)


def initialize_v2_fracture_owner(
    closure: PFNativeStateClosure | FEMCZMNativeStateClosure,
    *, opening_m: float,
) -> V2FractureOwnerState:
    if not isinstance(closure, _CLOSURE_TYPES):
        raise TypeError("adapter requires PFNativeStateClosure or FEMCZMNativeStateClosure")
    encoded, digest = _payload(closure)
    backend = "PF" if isinstance(closure, PFNativeStateClosure) else "FEMCZM"
    return V2FractureOwnerState(
        backend, encoded, digest, asdict(closure.state(float(opening_m))),
    )


def preview_v2_fracture_interval(
    owner: V2FractureOwnerState, *, opening_m: float,
    temperature_K: float, duration_s: float,
    mechanics_binding: ReducedMechanicsDriveBinding | None = None,
) -> V2FracturePreview:
    if duration_s < 0.0:
        raise ValueError("fracture preview duration must be nonnegative")
    closure = _restore(owner.closure_payload_b64)
    binding = mechanics_binding or ReducedMechanicsDriveBinding()
    if owner.backend != "PF" and binding.native_K_scale != 1.0:
        raise RuntimeError("reduced native-drive binding is qualified only for PF")
    base_mechanics = closure.mechanics
    if owner.backend == "PF":
        closure.mechanics = _ScaledPFMechanicsProvider(base_mechanics, binding)
    # The closure is an isolated clone.  Any backend exception, including a
    # late energy veto, leaves ``owner`` byte-for-byte unchanged.
    result = closure.advance_interval(
        float(opening_m), float(temperature_K), float(duration_s))
    closure.mechanics = base_mechanics
    encoded, digest = _payload(closure)
    proposed = V2FractureOwnerState(
        owner.backend, encoded, digest, asdict(result.post_state),
        accepted_intervals=owner.accepted_intervals + 1,
        native_backend_calls=owner.native_backend_calls + 1,
        last_mechanics_binding=asdict(binding),
    )
    return V2FracturePreview(owner.fingerprint, proposed, result)


def commit_v2_fracture_preview(
    owner: V2FractureOwnerState, preview: V2FracturePreview,
) -> V2FractureOwnerState:
    if owner.fingerprint != preview.owner_before_fingerprint:
        raise RuntimeError("stale V2 fracture preview cannot commit")
    return preview.proposed_owner


def first_v2_fracture_event_time(
    owner: V2FractureOwnerState, *, opening_m: float, temperature_K: float,
    maximum_duration_s: float, tolerance_s: float,
    mechanics_binding: ReducedMechanicsDriveBinding | None = None,
) -> float | None:
    """Localize the first event by replaying isolated production advances."""
    full = preview_v2_fracture_interval(
        owner, opening_m=opening_m, temperature_K=temperature_K,
        duration_s=maximum_duration_s, mechanics_binding=mechanics_binding)
    if not full.fired:
        return None
    low, high = 0.0, float(maximum_duration_s)
    for _ in range(64):
        if high-low <= tolerance_s:
            break
        mid = 0.5*(low+high)
        trial = preview_v2_fracture_interval(
            owner, opening_m=opening_m, temperature_K=temperature_K,
            duration_s=mid, mechanics_binding=mechanics_binding)
        if trial.fired:
            high = mid
        else:
            low = mid
    return high


def restore_v2_fracture_closure(owner: V2FractureOwnerState) -> Any:
    """Testing/diagnostic access to a clone; never a mutable state escape."""
    return _restore(owner.closure_payload_b64)


def project_v2_fracture_state(
    current: ReducedState, owner: V2FractureOwnerState, *,
    physical_time_s: float, external_control: float,
) -> ReducedState:
    """Expose V2 observables without becoming a second fracture owner."""
    row = owner.last_forward_state
    return ReducedState(
        time_s=float(physical_time_s),
        external_control=float(external_control),
        crack_extension_m=float(row["extension_m"]),
        cleavage_action=float(row["cleavage_action"]),
        cleavage_threshold=float(row["cleavage_threshold"]),
        emission_action=current.emission_action,
        emission_threshold=current.emission_threshold,
        mobile_density_m2=float(row["mobile_count"]),
        retained_density_m2=float(row["retained_count"]),
        local_slip=current.local_slip,
        tip_radius_m=float(row["tip_radius_m"]),
        front_width_m=float(row["front_width_m"]),
        source_area_m2=float(row["source_area_m2"]),
        source_multiplicity=float(row["source_multiplicity"]),
        backstress_Pa=float(row["backstress_Pa"]),
        signed_shielding_Pa_sqrt_m=float(row["signed_shielding_Pa_sqrt_m"]),
        event_count=int(row["event_count"]),
        physical_avalanche_index=int(row["physical_avalanche_index"]),
    )


__all__ = [
    "SCHEMA", "ReducedMechanicsDriveBinding", "V2FractureOwnerState", "V2FracturePreview",
    "commit_v2_fracture_preview", "first_v2_fracture_event_time",
    "initialize_v2_fracture_owner", "preview_v2_fracture_interval",
    "project_v2_fracture_state", "restore_v2_fracture_closure",
]
