"""Reduced global solvers that retain native local constitutive physics."""
from __future__ import annotations

from dataclasses import replace
import hashlib
import pickle
import time

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu


def _orthonormal_columns(columns, relative_cutoff=1.0e-11):
    matrix=np.column_stack(tuple(np.asarray(x,float) for x in columns))
    u,s,_=np.linalg.svd(matrix,full_matrices=False)
    if not len(s) or s[0] <= 0.0:
        raise ValueError("reduced basis has no nonzero direction")
    return u[:,s>s[0]*float(relative_cutoff)]


def _hash_arrays(*values):
    digest=hashlib.sha256()
    for value in values:
        array=np.ascontiguousarray(value)
        digest.update(array.dtype.str.encode())
        digest.update(np.asarray(array.shape,dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def structured_indicator_basis(points_xy, nx: int, ny: int):
    points=np.asarray(points_xy,float)
    xedge=np.linspace(points[:,0].min()-np.spacing(abs(points[:,0].min())+1.0),
                      points[:,0].max()+np.spacing(abs(points[:,0].max())+1.0),nx+1)
    yedge=np.linspace(points[:,1].min()-np.spacing(abs(points[:,1].min())+1.0),
                      points[:,1].max()+np.spacing(abs(points[:,1].max())+1.0),ny+1)
    ix=np.clip(np.searchsorted(xedge,points[:,0],side="right")-1,0,nx-1)
    iy=np.clip(np.searchsorted(yedge,points[:,1],side="right")-1,0,ny-1)
    labels=ix*ny+iy
    columns=[]
    for label in sorted(set(labels)):
        column=(labels==label).astype(float)
        columns.append(column/np.linalg.norm(column))
    return columns


def topology_dependency_identity(state):
    """Identity of the geometry/operator owners that invalidate both ROMs."""
    from .provider_identity import numerical_provider_dependency_identity
    return numerical_provider_dependency_identity(state)


def mechanical_dependency_identity(state):
    from .provider_identity import mechanical_provider_dependency_identity
    return mechanical_provider_dependency_identity(state)


def transport_dependency_identity(state):
    from .provider_identity import transport_provider_dependency_identity
    return transport_provider_dependency_identity(state)


class TopologyTransitionProviderManager:
    """Explicitly retire and rebuild numerical providers after native commit.

    The manager owns no physical state and performs no fracture operation.  It
    records the accepted topology on which each provider pair was built and
    refuses to publish a replacement unless a native transaction actually
    changed that dependency identity.
    """
    def __init__(self,state,mechanics,transport):
        self.mechanics=mechanics; self.transport=transport
        self.dependency_identity=topology_dependency_identity(state)
        self.mechanical_dependency_identity=mechanical_dependency_identity(state)
        self.transport_dependency_identity=transport_dependency_identity(state)
        self.generation=0; self.transition_count=0
        self.retired=[]; self.audit=[]

    def rebuild_after_native_commit(self,before,accepted_after,builder):
        old_identity=topology_dependency_identity(before)
        new_identity=topology_dependency_identity(accepted_after)
        old_mechanical=mechanical_dependency_identity(before)
        new_mechanical=mechanical_dependency_identity(accepted_after)
        old_transport=transport_dependency_identity(before)
        new_transport=transport_dependency_identity(accepted_after)
        if old_identity != self.dependency_identity:
            raise RuntimeError("transition manager is not bound to the pre-event state")
        if new_identity == old_identity:
            raise RuntimeError("native topology transaction changed no provider dependency")
        retired=(self.mechanics,self.transport)
        mechanical_reuse_rejected=None
        if old_mechanical != self.mechanical_dependency_identity:
            raise RuntimeError("transition manager mechanical binding is stale")
        if old_transport != self.transport_dependency_identity:
            raise RuntimeError("transition manager transport binding is stale")
        mechanical_changed=new_mechanical != old_mechanical
        transport_changed=new_transport != old_transport
        if mechanical_changed and callable(self.mechanics):
            try:
                self.mechanics(accepted_after)
            except RuntimeError as error:
                if "contract changed" not in str(error):
                    raise
                mechanical_reuse_rejected=True
            else:
                raise RuntimeError("pre-event mechanical provider accepted changed topology")
        mechanics,transport,basis_audit=builder(accepted_after,[accepted_after])
        self.retired.append(retired)
        self.mechanics=mechanics; self.transport=transport
        self.dependency_identity=new_identity
        self.mechanical_dependency_identity=new_mechanical
        self.transport_dependency_identity=new_transport
        self.generation+=1; self.transition_count+=1
        row={
            "generation":self.generation,
            "pre_dependency_identity":old_identity,
            "post_dependency_identity":new_identity,
            "mechanical_dependency_changed":mechanical_changed,
            "transport_dependency_changed":transport_changed,
            "mechanical_dimension":mechanics.dimension,
            "transport_dimension":transport.dimension,
            "pre_event_mechanical_provider_reuse_rejected":mechanical_reuse_rejected,
            "pre_event_transport_provider_retired_by_dependency_identity":True,
            "basis":basis_audit,
        }
        self.audit.append(row)
        return mechanics,transport,row

    def snapshot_binding(self):
        """Return a cheap ownership snapshot for outer transaction rollback."""
        return {
            "mechanics":self.mechanics,"transport":self.transport,
            "dependency_identity":self.dependency_identity,
            "mechanical_dependency_identity":self.mechanical_dependency_identity,
            "transport_dependency_identity":self.transport_dependency_identity,
            "generation":self.generation,"transition_count":self.transition_count,
            "retired":list(self.retired),"audit":list(self.audit),
        }

    def restore_binding(self,snapshot):
        """Restore provider ownership after a failed outer continuation."""
        self.mechanics=snapshot["mechanics"]
        self.transport=snapshot["transport"]
        self.dependency_identity=snapshot["dependency_identity"]
        self.mechanical_dependency_identity=snapshot["mechanical_dependency_identity"]
        self.transport_dependency_identity=snapshot["transport_dependency_identity"]
        self.generation=snapshot["generation"]
        self.transition_count=snapshot["transition_count"]
        self.retired=list(snapshot["retired"])
        self.audit=list(snapshot["audit"])


class ReducedMechanicalEquilibriumProvider:
    """Galerkin free-displacement solve with exact Dirichlet lifting."""
    provider_identity="REDUCED_FIXED_OPERATOR_GALERKIN_NATIVE_CONSTITUTIVE"

    def __init__(self,state,basis_free,residual_relative_limit=2.0e-5):
        from arrhenius_fracture.fem import assemble_mechanics
        from arrhenius_fracture.topology_transaction_v11 import ExactDirichletFactorizationCache
        self.prescribed=ExactDirichletFactorizationCache._prescribed(
            state.boundary,len(state.displacement))
        self.free=~self.prescribed
        self.basis=np.asarray(basis_free,float)
        if self.basis.shape[0] != int(np.sum(self.free)):
            raise ValueError("mechanical basis does not cover free DOFs")
        self.basis=_orthonormal_columns(self.basis.T)
        matrix,*_=assemble_mechanics(
            state.mesh,np.asarray(state.displacement),state.ep_gp,state.rho_gp,
            state.damage,state.elasticity_D,state.material,
            cohesive_network=state.cohesive_network)
        self.matrix=matrix.tocsr()
        self.Kff=self.matrix[np.ix_(self.free,self.free)].tocsc()
        self.reduced_operator=self.basis.T@(self.Kff@self.basis)
        self.operator_hash=self._hash(matrix)
        elements=np.asarray(state.mesh.elems,int)
        self.element_dofs=np.column_stack((
            2*elements[:,0],2*elements[:,0]+1,2*elements[:,1],2*elements[:,1]+1,
            2*elements[:,2],2*elements[:,2]+1))
        inherited=getattr(state.mesh,"element_damage_gp",None)
        damage=(np.asarray(inherited,float) if inherited is not None else
                np.mean(np.asarray(state.damage)[elements],axis=1))
        self.element_damage=damage
        self.degradation=(1.0-damage)**2+1.0e-6
        self.contract_hash=_hash_arrays(
            state.mesh.nodes,state.mesh.elems,np.flatnonzero(self.prescribed),self.basis,
            state.damage,state.elasticity_D,self.element_damage,
            np.frombuffer(pickle.dumps((state.material,state.cohesive_network),protocol=5),
                          dtype=np.uint8))
        self.residual_relative_limit=float(residual_relative_limit)
        self.solve_count=0; self.fallback_count=0; self.wall_time_s=0.0
        self.maximum_relative_free_residual=0.0

    @staticmethod
    def _hash(matrix):
        csr=matrix.tocsr(); digest=hashlib.sha256()
        for value in (csr.data,csr.indices,csr.indptr):
            digest.update(np.ascontiguousarray(value).tobytes())
        return digest.hexdigest()

    @property
    def dimension(self): return self.basis.shape[1]

    def __call__(self,state):
        from arrhenius_fracture.fem import stress_state
        from arrhenius_fracture.hazard_energy_event_gate_v10230 import (
            _infer_boundary_opening,_stored_energy)
        from arrhenius_fracture.topology_transaction_v11 import (
            _measure_accepted_equilibrium,complete_equilibrium_force_accounting)
        wall=time.perf_counter(); displacement=np.zeros_like(state.displacement,dtype=float)
        top,bottom=_infer_boundary_opening(state.boundary,state.displacement)
        displacement[2*np.asarray(state.boundary.top_nodes,int)+1]=top
        displacement[2*np.asarray(state.boundary.bot_nodes,int)+1]=bottom
        displacement[2*int(state.boundary.left_bot)+1]=bottom
        from arrhenius_fracture.topology_transaction_v11 import ExactDirichletFactorizationCache
        current_prescribed=ExactDirichletFactorizationCache._prescribed(
            state.boundary,len(state.displacement))
        contract_hash=_hash_arrays(
            state.mesh.nodes,state.mesh.elems,np.flatnonzero(current_prescribed),self.basis,
            state.damage,state.elasticity_D,
            np.asarray(getattr(state.mesh,"element_damage_gp",self.element_damage),float),
            np.frombuffer(pickle.dumps((state.material,state.cohesive_network),protocol=5),
                          dtype=np.uint8))
        if contract_hash != self.contract_hash:
            raise RuntimeError("reduced mechanical mesh/DOF/basis contract changed")
        eigenstress=-self.degradation[:,None]*(np.asarray(state.ep_gp).T@state.elasticity_D.T)
        element_force=np.einsum(
            "eji,ej->ei",state.mesh.B_e,eigenstress)*state.mesh.area_e[:,None]
        eigenforce=np.zeros_like(displacement)
        np.add.at(eigenforce,self.element_dofs.ravel(),element_force.ravel())
        residual=self.matrix@displacement+eigenforce
        rhs=-(self.basis.T@np.asarray(residual)[self.free])
        displacement[self.free]=self.basis@np.linalg.solve(self.reduced_operator,rhs)
        accepted_residual=self.matrix@displacement+eigenforce
        sigma,*_=stress_state(state.mesh,displacement,state.ep_gp,state.damage,
                              state.elasticity_D,state.material)
        free_norm=float(np.linalg.norm(np.asarray(accepted_residual)[self.free]))
        scale=max(float(np.linalg.norm(np.asarray(accepted_residual)[self.prescribed])),1.0)
        relative=free_norm/scale
        self.maximum_relative_free_residual=max(self.maximum_relative_free_residual,relative)
        if relative > self.residual_relative_limit:
            raise RuntimeError(f"reduced mechanical residual gate failed: {relative:.6e}")
        energy=_stored_energy(state.mesh,displacement,state.ep_gp,sigma,state.elasticity_D)
        accepted=replace(state,displacement=displacement,stored_energy_J_per_m=energy,
                         equilibrium_observables=None)
        observation=_measure_accepted_equilibrium(
            accepted,accepted_residual,sigma,energy,
            free_residual_relative_limit=self.residual_relative_limit)
        complete=complete_equilibrium_force_accounting(accepted,accepted_residual)
        self.solve_count+=1; self.wall_time_s+=time.perf_counter()-wall
        return replace(accepted,equilibrium_observables=observation,
                       energy_ledgers={**accepted.energy_ledgers,**dict(observation),
                           "complete_equilibrium_force_accounting":complete})


class ReducedTransportLinearProvider:
    """Galerkin P0 concentration solve with conservative RT0 flux recovery."""
    provider_identity="REDUCED_RT0_P0_GALERKIN_CURRENT_STATE_FORCING"

    def __init__(self,basis_concentration):
        self.basis=_orthonormal_columns(np.asarray(basis_concentration,float).T)
        self._key=None; self._factor=None; self._diffusion_basis=None
        self.solve_count=0; self.wall_time_s=0.0; self.maximum_mixed_residual_inf=0.0
        self.cache_rebuild_count=0

    @property
    def dimension(self): return self.basis.shape[1]

    @staticmethod
    def _matrix_key(matrix):
        csr=matrix.tocsr(); digest=hashlib.sha256()
        for value in (csr.data,csr.indices,csr.indptr):
            digest.update(np.ascontiguousarray(value).tobytes())
        return digest.hexdigest()

    def solve(self,mixed_matrix,mixed_rhs,flux_dof_count,dependency_identity=None):
        wall=time.perf_counter(); system=sparse.csc_matrix(mixed_matrix)
        rhs=np.asarray(mixed_rhs,float); nq=int(flux_dof_count); P=self.basis
        M=system[:nq,:nq].tocsc(); B=(-system[nq:,:nq]).tocsr()
        C=(-system[nq:,nq:]).tocsc()
        key=_hash_arrays(
            np.frombuffer(self._matrix_key(M).encode(),dtype=np.uint8),
            np.frombuffer(self._matrix_key(B).encode(),dtype=np.uint8),P,
            np.asarray(system.shape,dtype=np.int64),np.asarray([nq],dtype=np.int64),
            np.frombuffer(repr(dependency_identity).encode(),dtype=np.uint8))
        if key != self._key:
            self._factor=splu(M)
            self._diffusion_basis=self._factor.solve(np.asarray(B.T@P))
            self._key=key
            self.cache_rebuild_count+=1
        flux_rhs=rhs[:nq]; reaction_rhs=-rhs[nq:]
        minv_f=self._factor.solve(flux_rhs)
        reduced=(P.T@(B@self._diffusion_basis)+P.T@(C@P))
        reduced_rhs=P.T@(reaction_rhs-np.asarray(B@minv_f).reshape(-1))
        concentration=P@np.linalg.solve(reduced,reduced_rhs)
        flux=self._factor.solve(flux_rhs+np.asarray(B.T@concentration).reshape(-1))
        solution=np.r_[flux,concentration]
        residual=float(np.linalg.norm(system@solution-rhs,ord=np.inf))
        self.maximum_mixed_residual_inf=max(self.maximum_mixed_residual_inf,residual)
        self.solve_count+=1; self.wall_time_s+=time.perf_counter()-wall
        return solution


__all__=["ReducedMechanicalEquilibriumProvider","ReducedTransportLinearProvider",
         "TopologyTransitionProviderManager","structured_indicator_basis",
         "topology_dependency_identity","mechanical_dependency_identity",
         "transport_dependency_identity"]
