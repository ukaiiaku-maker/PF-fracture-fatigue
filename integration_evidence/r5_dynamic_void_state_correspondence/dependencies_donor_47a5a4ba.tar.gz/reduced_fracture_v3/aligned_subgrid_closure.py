"""First bounded aligned mechanics closure from current 2-D observations."""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from .mechanics import MechanicsMapDomainError, MechanicsResponse, TopologyRegime


@dataclass(frozen=True)
class BoundedPreconnectionSubgridClosure:
    dataset_sha256: str
    opening_m: float
    plastic_history_axis: tuple[float, ...]
    no_void_G_J_per_m2: tuple[float, ...]
    compliance_m2_per_N: tuple[float, ...]
    recoverable_energy_J_per_m: tuple[float, ...]
    maximum_history_rate_s: tuple[float, ...]
    site_tensor_axes: Mapping[str, tuple[tuple[float, ...], ...]]
    site_direct_control_axes: Mapping[str, tuple[tuple[float, ...], ...]]
    source_identities: tuple[str, ...]
    topology_regime: TopologyRegime = TopologyRegime.PRECONNECTION

    def __post_init__(self) -> None:
        axis = np.asarray(self.plastic_history_axis, float)
        if len(axis) < 2 or np.any(np.diff(axis) <= 0.0):
            raise ValueError("bounded closure requires ordered history nodes")
        if any(len(values) != len(axis) for values in (
            self.no_void_G_J_per_m2, self.compliance_m2_per_N,
            self.recoverable_energy_J_per_m,
            self.maximum_history_rate_s,
        )):
            raise ValueError("mechanics closure arrays are incomplete")
        if any(np.asarray(values).shape != (len(axis), 5)
               for values in self.site_tensor_axes.values()):
            raise ValueError("each site requires xx, yy, xy, zz and mean stress")
        if any(np.asarray(values).shape != (len(axis), 5)
               for values in self.site_direct_control_axes.values()):
            raise ValueError("each site requires five direct-interaction controls")

    @property
    def history_domain(self) -> tuple[float, float]:
        return self.plastic_history_axis[0], self.plastic_history_axis[-1]

    def _check(self, opening_m: float, maximum_equivalent_plastic_strain: float) -> float:
        opening = float(opening_m)
        history = float(maximum_equivalent_plastic_strain)
        if not math.isclose(opening, self.opening_m, rel_tol=0.0, abs_tol=1.0e-15):
            raise MechanicsMapDomainError(
                f"opening {opening:.12g} outside fixed-load closure {self.opening_m:.12g}")
        low, high = self.history_domain
        if history < low or history > high:
            raise MechanicsMapDomainError(
                f"plastic history {history:.12g} outside [{low:.12g}, {high:.12g}]")
        return history

    def source_tensor_xy_sigma_zz(
        self, *, site_id: str, opening_m: float,
        maximum_equivalent_plastic_strain: float,
    ) -> tuple[float, float, float, float, float]:
        history = self._check(opening_m, maximum_equivalent_plastic_strain)
        if site_id not in self.site_tensor_axes:
            raise MechanicsMapDomainError(f"site {site_id!r} is outside the closure")
        values = np.asarray(self.site_tensor_axes[site_id], float)
        axis = np.asarray(self.plastic_history_axis, float)
        return tuple(float(np.interp(history, axis, values[:, index]))
                     for index in range(5))

    def maximum_history_rate(self, *, opening_m: float,
                             maximum_equivalent_plastic_strain: float) -> float:
        """State-based evolution law for the closure coordinate, not a time fit."""
        history = self._check(opening_m, maximum_equivalent_plastic_strain)
        return float(np.interp(
            history, np.asarray(self.plastic_history_axis, float),
            np.asarray(self.maximum_history_rate_s, float)))

    def evaluate(
        self, *, opening_m: float, maximum_equivalent_plastic_strain: float,
        site_id: str | None = None, radius_m: float | None = None,
    ) -> MechanicsResponse:
        history = self._check(opening_m, maximum_equivalent_plastic_strain)
        axis = np.asarray(self.plastic_history_axis, float)
        interpolate = lambda values: float(np.interp(history, axis, values))
        tensor = None
        if site_id is not None and radius_m is not None:
            if radius_m <= 0.0:
                raise MechanicsMapDomainError("subgrid cavity radius must be positive")
            xx, yy, xy, _zz, mean = self.source_tensor_xy_sigma_zz(
                site_id=site_id, opening_m=opening_m,
                maximum_equivalent_plastic_strain=history)
            tensor = (xx, yy, xy, mean)
        return MechanicsResponse(
            regime=TopologyRegime.PRECONNECTION,
            G_kinetic=interpolate(self.no_void_G_J_per_m2),
            cavity_tensor=tensor,
            compliance=interpolate(self.compliance_m2_per_N),
            potential_energy=interpolate(self.recoverable_energy_J_per_m),
            map_source_identities=self.source_identities,
            qualification=(
                "QUALIFIED_FIXED_LOAD_HISTORY_INTERPOLATION_WITH_EXACT_"
                "SUBGRID_ZERO_FAR_FIELD_CORRECTION"),
        )

    def site_direct_controls(
        self, *, site_id: str, opening_m: float,
        maximum_equivalent_plastic_strain: float,
    ) -> dict[str, float]:
        history = self._check(opening_m, maximum_equivalent_plastic_strain)
        if site_id not in self.site_direct_control_axes:
            raise MechanicsMapDomainError(f"site {site_id!r} is outside the closure")
        values = np.asarray(self.site_direct_control_axes[site_id], float)
        axis = np.asarray(self.plastic_history_axis, float)
        names = (
            "accepted_epdot_eq_support_average_s", "rho_forest_support_average_m2",
            "rho_mobile_support_average_m2", "mean_stress_support_Pa",
            "support_integrated_interaction_rate_s",
        )
        return {name: float(np.interp(history, axis, values[:, index]))
                for index, name in enumerate(names)}

    @classmethod
    def from_dataset(cls, payload: Mapping[str, Any]):
        training = sorted(
            (row for row in payload["rows"] if row["split"].startswith("TRAIN")),
            key=lambda row: row["plastic_history"]["maximum_equivalent_plastic_strain"],
        )
        openings = {row["applied_load"]["opening_m"] for row in training}
        if len(openings) != 1:
            raise ValueError("first closure is a single measured load level")
        site_ids = {
            site["site_id"] for row in training
            for site in row["plastic_history"]["sites"]
        }
        names = ("sigma_xx_Pa", "sigma_yy_Pa", "sigma_xy_Pa",
                 "sigma_zz_Pa", "mean_stress_Pa")
        site_values = {}
        site_direct_values = {}
        for site_id in sorted(site_ids):
            rows = []
            for observation in training:
                site = next(item for item in observation["plastic_history"]["sites"]
                            if item["site_id"] == site_id)
                rows.append(tuple(float(site["accepted_constitutive_stress_Pa"][name])
                                  for name in names))
            site_values[site_id] = tuple(rows)
            controls = []
            for observation in training:
                direct = next(item for item in observation["direct_opportunity"]
                              if item["site_id"] == site_id)
                controls.append(tuple(float(direct[name]) for name in (
                    "accepted_epdot_eq_support_average_s",
                    "rho_forest_support_average_m2",
                    "rho_mobile_support_average_m2",
                    "mean_stress_support_Pa",
                    "support_integrated_interaction_rate_s",
                )))
            site_direct_values[site_id] = tuple(controls)
        supplied_rates = [row["plastic_history"].get(
            "maximum_equivalent_plastic_strain_rate_s") for row in training]
        if all(value is not None for value in supplied_rates):
            history_rates = tuple(float(value) for value in supplied_rates)
        else:
            # Backward-compatible state-rate reconstruction for the original
            # V1 five-row dataset. New enriched datasets own measured rates.
            training_history = np.asarray([row["plastic_history"][
                "maximum_equivalent_plastic_strain"] for row in training], float)
            training_time = np.asarray([row["accepted_time_s"] for row in training], float)
            history_rates = tuple(map(float, np.gradient(training_history, training_time)))
        return cls(
            dataset_sha256=str(payload["dataset_sha256"]),
            opening_m=float(next(iter(openings))),
            plastic_history_axis=tuple(float(row["plastic_history"][
                "maximum_equivalent_plastic_strain"]) for row in training),
            no_void_G_J_per_m2=tuple(float(row["tip"]["drive"][
                "G_kinetic_used_J_per_m2"]) for row in training),
            compliance_m2_per_N=tuple(float(row["applied_load"][
                "compliance_m2_per_N"]) for row in training),
            recoverable_energy_J_per_m=tuple(float(row["applied_load"][
                "recoverable_energy_J_per_m"]) for row in training),
            maximum_history_rate_s=history_rates,
            site_tensor_axes=site_values,
            site_direct_control_axes=site_direct_values,
            source_identities=tuple(row["observation_sha256"] for row in training),
        )


def load_bounded_subgrid_closure(path: str | Path):
    payload = json.loads(Path(path).read_text())
    return BoundedPreconnectionSubgridClosure.from_dataset(payload), payload


def validate_bounded_subgrid_closure(
    closure: BoundedPreconnectionSubgridClosure, payload: Mapping[str, Any],
) -> dict[str, Any]:
    rows = [row for row in payload["rows"] if row["split"].startswith("HOLDOUT")]
    scores = []
    for row in rows:
        history = row["plastic_history"]["maximum_equivalent_plastic_strain"]
        response = closure.evaluate(
            opening_m=row["applied_load"]["opening_m"],
            maximum_equivalent_plastic_strain=history)
        scalar = {
            "G_relative_error": abs(response.G_kinetic-row["tip"]["drive"][
                "G_kinetic_used_J_per_m2"])/abs(row["tip"]["drive"][
                    "G_kinetic_used_J_per_m2"]),
            "compliance_relative_error": abs(response.compliance-row["applied_load"][
                "compliance_m2_per_N"])/abs(row["applied_load"]["compliance_m2_per_N"]),
            "energy_relative_error": abs(response.potential_energy-row["applied_load"][
                "recoverable_energy_J_per_m"])/abs(row["applied_load"][
                    "recoverable_energy_J_per_m"]),
            "history_rate_relative_error": (
                abs(closure.maximum_history_rate(
                    opening_m=row["applied_load"]["opening_m"],
                    maximum_equivalent_plastic_strain=history)-row["plastic_history"][
                        "maximum_equivalent_plastic_strain_rate_s"])/max(abs(
                            row["plastic_history"][
                                "maximum_equivalent_plastic_strain_rate_s"]), 1.0e-12)
                if "maximum_equivalent_plastic_strain_rate_s" in row["plastic_history"]
                else 0.0),
        }
        tensor_errors = []
        direct_errors = []
        for site in row["plastic_history"]["sites"]:
            predicted = np.asarray(closure.source_tensor_xy_sigma_zz(
                site_id=site["site_id"], opening_m=row["applied_load"]["opening_m"],
                maximum_equivalent_plastic_strain=history))
            stress = site["accepted_constitutive_stress_Pa"]
            observed = np.asarray(tuple(stress[name] for name in (
                "sigma_xx_Pa", "sigma_yy_Pa", "sigma_xy_Pa",
                "sigma_zz_Pa", "mean_stress_Pa")))
            tensor_errors.append(float(np.linalg.norm(predicted-observed)
                                       /max(np.linalg.norm(observed), 1.0e-30)))
            predicted_controls = closure.site_direct_controls(
                site_id=site["site_id"], opening_m=row["applied_load"]["opening_m"],
                maximum_equivalent_plastic_strain=history)
            observed_controls = next(item for item in row["direct_opportunity"]
                                     if item["site_id"] == site["site_id"])
            for name, predicted_value in predicted_controls.items():
                floors = {
                    "accepted_epdot_eq_support_average_s": 1.0e-12,
                    "rho_forest_support_average_m2": 1.0e6,
                    "rho_mobile_support_average_m2": 1.0e6,
                    "mean_stress_support_Pa": 1.0,
                    "support_integrated_interaction_rate_s": 1.0e-12,
                }
                direct_errors.append(abs(predicted_value-observed_controls[name])
                                     /max(abs(observed_controls[name]), floors[name]))
        scores.append({
            "checkpoint": row["checkpoint"], **scalar,
            "maximum_source_tensor_relative_error": max(tensor_errors),
            "maximum_direct_control_relative_error": max(direct_errors),
            "exact_far_field_void_correction": row[
                "matched_no_void_companion"]["far_field_tip_delta_G_J_per_m2"],
        })
    maxima = {
        key: max(row[key] for row in scores) for key in (
            "G_relative_error", "compliance_relative_error",
            "energy_relative_error", "history_rate_relative_error",
            "maximum_source_tensor_relative_error",
            "maximum_direct_control_relative_error")
    }
    passed = (maxima["G_relative_error"] <= 0.05
              and maxima["maximum_source_tensor_relative_error"] <= 0.05
              and maxima["maximum_direct_control_relative_error"] <= 0.05
              and maxima["history_rate_relative_error"] <= 0.05
              and maxima["compliance_relative_error"] <= 0.02
              and maxima["energy_relative_error"] <= 0.02)
    return {"held_out_rows": scores, "maxima": maxima,
            "status": "PASS" if passed else "FAIL"}


__all__ = [
    "BoundedPreconnectionSubgridClosure", "load_bounded_subgrid_closure",
    "validate_bounded_subgrid_closure",
]
