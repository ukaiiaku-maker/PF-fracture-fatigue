"""Signed tensorial history and one-potential reduced mechanical response."""
from __future__ import annotations

from dataclasses import dataclass, replace
import math

import numpy as np

from .mechanics import MechanicsResponse, TopologyRegime


@dataclass(frozen=True)
class CompactMechanicalState:
    """Current signed in-plane plastic/eigenstrain state on compact cells.

    Tensor ordering is ``(xx, yy, xy)`` with tensor shear (not engineering
    shear).  Stress fields live beside the strain history so all mechanical
    observables can be evaluated from one accepted state.
    """
    plastic_strain_xy: tuple[tuple[float, float, float], ...]
    eigenstrain_xy: tuple[tuple[float, float, float], ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]
    cell_measure_m2: tuple[float, ...]
    representation_identity: str

    def __post_init__(self) -> None:
        n = len(self.cell_measure_m2)
        plastic = np.asarray(self.plastic_strain_xy, float)
        eigen = np.asarray(self.eigenstrain_xy, float)
        if plastic.shape != (n, 3) or eigen.shape != (n, 3):
            raise ValueError("signed compact strain tensors must be (cell,xx/yy/xy)")
        if (len(self.mean_stress_Pa) != n or len(self.opening_stress_Pa) != n
                or np.any(~np.isfinite(plastic)) or np.any(~np.isfinite(eigen))
                or np.any(np.asarray(self.cell_measure_m2) <= 0.0)):
            raise ValueError("compact mechanical state is incomplete")
        if not self.representation_identity:
            raise ValueError("compact mechanical representation identity is required")

    @property
    def signed_history_vector(self) -> np.ndarray:
        return np.concatenate((np.asarray(self.plastic_strain_xy).ravel(),
                               np.asarray(self.eigenstrain_xy).ravel()))


@dataclass(frozen=True)
class CompactMechanicalIncrement:
    plastic_strain_increment_xy: tuple[tuple[float, float, float], ...]
    eigenstrain_increment_xy: tuple[tuple[float, float, float], ...]
    mean_stress_Pa: tuple[float, ...]
    opening_stress_Pa: tuple[float, ...]


def advance_compact_mechanics(
    state: CompactMechanicalState, increment: CompactMechanicalIncrement,
) -> CompactMechanicalState:
    plastic = np.asarray(increment.plastic_strain_increment_xy, float)
    eigen = np.asarray(increment.eigenstrain_increment_xy, float)
    n = len(state.cell_measure_m2)
    if plastic.shape != (n, 3) or eigen.shape != (n, 3):
        raise ValueError("compact mechanical increment has the wrong shape")
    if len(increment.mean_stress_Pa) != n or len(increment.opening_stress_Pa) != n:
        raise ValueError("compact mechanical stress fields have the wrong shape")
    return replace(
        state,
        plastic_strain_xy=tuple(map(tuple, np.asarray(state.plastic_strain_xy)+plastic)),
        eigenstrain_xy=tuple(map(tuple, np.asarray(state.eigenstrain_xy)+eigen)),
        mean_stress_Pa=tuple(increment.mean_stress_Pa),
        opening_stress_Pa=tuple(increment.opening_stress_Pa),
    )


@dataclass(frozen=True)
class SignedHistoryPotential:
    """A shared potential: reaction is its opening derivative."""
    reference_history: tuple[float, ...]
    basis_vectors: tuple[tuple[float, ...], ...]
    coefficients: tuple[float, ...]
    opening_scale_m: float
    energy_scale_J_per_m: float
    identity: str

    def coordinates(self, state: CompactMechanicalState) -> np.ndarray:
        delta = state.signed_history_vector-np.asarray(self.reference_history)
        basis = np.asarray(self.basis_vectors, float)
        return basis@delta if basis.size else np.empty(0)

    def response(self, state: CompactMechanicalState, signed_load: float,
                 G_kinetic: float, provenance: tuple[str, ...],
                 regime: TopologyRegime = TopologyRegime.PRECONNECTION,
                 G_local: float | None = None) -> MechanicsResponse:
        z = np.r_[1.0, self.coordinates(state)]
        coefficient = np.asarray(self.coefficients, float)
        if coefficient.shape != (3*len(z),):
            raise ValueError("potential coefficient count does not match history basis")
        stiffness, residual, offset = coefficient.reshape(3, len(z))@z
        load = float(signed_load)
        reaction_nondimensional = stiffness*load-residual
        energy_nondimensional = (0.5*stiffness*load*load
                                 -residual*load+offset)
        reaction = self.energy_scale_J_per_m/self.opening_scale_m*reaction_nondimensional
        if not math.isfinite(reaction) or abs(reaction) <= 1.0e-300:
            raise RuntimeError("signed-history potential produced zero/invalid reaction")
        compliance = abs(self.opening_scale_m*load/reaction)
        return MechanicsResponse(
            regime, float(G_kinetic), G_local, float(compliance),
            float(self.energy_scale_J_per_m*energy_nondimensional),
            provenance, self.identity)


__all__ = [
    "CompactMechanicalIncrement", "CompactMechanicalState",
    "SignedHistoryPotential", "advance_compact_mechanics",
]
