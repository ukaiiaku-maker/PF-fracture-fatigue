"""Standalone reduced-provider dependency identities.

These are operator identities, not full physical-state fingerprints.  The
payload and semantic-hash schema match the 2-D scheduler contract without
importing an undeclared sibling checkout.
"""
from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum
import base64
import hashlib
import json
import math
from types import SimpleNamespace
from typing import Any, Mapping

import numpy as np


SCHEMA = "arrhenius.semantic-identity/1"


def _value(value: Any) -> Any:
    if value is None: return ["none"]
    if isinstance(value, bool): return ["bool", value]
    if isinstance(value, (int, np.integer)) and not isinstance(value, bool):
        return ["int", str(int(value))]
    if isinstance(value, (float, np.floating)):
        number = float(value)
        if math.isnan(number): return ["float", "nan"]
        if math.isinf(number): return ["float", "+inf" if number > 0.0 else "-inf"]
        return ["float", number.hex()]
    if isinstance(value, str): return ["str", value]
    if isinstance(value, (bytes, bytearray, memoryview)):
        return ["bytes", base64.b64encode(bytes(value)).decode("ascii")]
    if isinstance(value, Enum):
        return ["enum", f"{type(value).__module__}.{type(value).__qualname__}", _value(value.value)]
    if isinstance(value, np.ndarray):
        array = np.asarray(value)
        if array.dtype.hasobject: raise TypeError("operator identity does not support object arrays")
        dtype = array.dtype if array.dtype.byteorder in ("|", "<") else array.dtype.newbyteorder("<")
        array = np.ascontiguousarray(array.astype(dtype, copy=False))
        return ["ndarray", dtype.str, list(array.shape),
                base64.b64encode(array.tobytes()).decode("ascii")]
    if is_dataclass(value) and not isinstance(value, type):
        return ["dataclass", f"{type(value).__module__}.{type(value).__qualname__}",
                [[item.name, _value(getattr(value, item.name))] for item in fields(value)]]
    if isinstance(value, SimpleNamespace): return ["simple-namespace", _value(vars(value))]
    if isinstance(value, Mapping):
        rows = [[_value(key), _value(item)] for key, item in value.items()]
        rows.sort(key=lambda row: json.dumps(row[0], separators=(",", ":")))
        return ["mapping", rows]
    if isinstance(value, tuple): return ["tuple", [_value(item) for item in value]]
    if isinstance(value, list): return ["list", [_value(item) for item in value]]
    if isinstance(value, (set, frozenset)):
        items = [_value(item) for item in value]
        items.sort(key=lambda item: json.dumps(item, separators=(",", ":")))
        return ["frozenset" if isinstance(value, frozenset) else "set", items]
    raise TypeError(f"unsupported operator-identity type: {type(value)!r}")


def _hash(value: Any) -> str:
    encoded = json.dumps([SCHEMA, _value(value)], separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def mechanical_provider_dependency_identity(state: Any) -> str:
    return _hash((
        np.asarray(state.mesh.nodes), np.asarray(state.mesh.elems),
        getattr(state, "boundary", None), state.crack_network,
        getattr(state, "cohesive_network", None),
        None if not hasattr(state, "damage") else np.asarray(state.damage),
        None if not hasattr(state, "elasticity_D") else np.asarray(state.elasticity_D),
        getattr(state, "material", None), getattr(state, "sharp_wake_model_id", None),
    ))


def transport_provider_dependency_identity(state: Any) -> str:
    transport = getattr(state, "vacancy_transport_state_v2", None)
    mesh = None if transport is None else transport.transport_mesh
    return _hash((
        np.asarray(state.mesh.nodes), np.asarray(state.mesh.elems),
        None if mesh is None else np.asarray(mesh.nodes),
        None if mesh is None else np.asarray(mesh.elems),
        None if transport is None else getattr(transport, "surface_registry_fingerprint", None),
        None if transport is None else getattr(transport, "parameter_row_fingerprint", None),
    ))


def numerical_provider_dependency_identity(state: Any) -> str:
    return _hash((mechanical_provider_dependency_identity(state),
                  transport_provider_dependency_identity(state)))
