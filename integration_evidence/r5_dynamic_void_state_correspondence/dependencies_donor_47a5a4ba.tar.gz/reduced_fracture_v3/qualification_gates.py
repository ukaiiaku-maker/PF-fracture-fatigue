"""Pure, standalone acceptance gates for reduced/native comparisons."""
from __future__ import annotations

from collections.abc import Mapping
import math


LIMITS = {
    "event_time_relative": 5.0e-3, "plastic_strain_relative": 5.0e-3,
    "density_relative": 5.0e-3, "vacancy_relative": 2.0e-2,
    "split_plastic_relative": 5.0e-3, "split_density_relative": 5.0e-3,
    "split_vacancy_relative": 2.0e-2, "ledger_relative": 2.0e-2,
}
REQUIRED_CHANNELS = (
    "duration_s", "plastic_source_fraction_area",
    "climb_annihilation_fraction_area", "field_inventory_area_m2",
    "active_cavity_absorption_increment_area_m2",
)


def finite_nonnegative(value):
    return (isinstance(value, (int, float)) and math.isfinite(float(value))
            and float(value) >= 0.0)


def connected_row_qualifies(row):
    segments = tuple(row.get("event_boundary_segments", ()))
    ligament = [item for item in segments if item.get("event_type") == "LIGAMENT_RUPTURE"]
    if len(ligament) != 1:
        return False
    event = ligament[0]
    if (event.get("owner_kind") != "ligament_transaction"
            or not event.get("event_ids") or not event.get("candidate_ids")):
        return False
    decision = row.get("event_local_energy_decision")
    if (not isinstance(decision, Mapping) or not decision.get("accepted", False)
            or decision.get("event_type") != "LIGAMENT_RUPTURE"
            or not finite_nonnegative(decision.get("energy_margin_J_per_m"))
            or float(decision["energy_margin_J_per_m"]) <= 0.0):
        return False
    channels = row.get("transport_interval_channels", {})
    if set(channels) != set(REQUIRED_CHANNELS) or not all(
            finite_nonnegative(channels[key]) for key in REQUIRED_CHANNELS):
        return False
    numerical = (
        ("split_final_plastic_relative_error", "split_plastic_relative"),
        ("split_final_density_relative_error", "split_density_relative"),
        ("split_final_vacancy_relative_error", "split_vacancy_relative"),
        ("split_vacancy_ledger_relative_error", "ledger_relative"),
    )
    if any(not finite_nonnegative(row.get(key)) or row[key] > LIMITS[limit]
           for key, limit in numerical):
        return False
    requested = float(row.get("requested_duration_s", math.nan))
    consumed = float(row.get("consumed_duration_s", math.nan))
    remaining = float(row.get("remaining_duration_s", math.nan))
    return bool(
        row.get("outcome") == "ACCEPTED_EVENT_AND_REMAINDER"
        and not row.get("terminal", False)
        and all(math.isfinite(value) and value >= 0.0
                for value in (requested, consumed, remaining))
        and math.isclose(requested, consumed+remaining, rel_tol=0.0, abs_tol=1.0e-10)
        and remaining == 0.0 and row.get("event_boundary_restart_exact", False)
        and str(row.get("event_boundary_phase")) in {
            "VoidPhase.CONNECTED_VOID", "CONNECTED_VOID"}
        and not tuple(row.get("event_boundary_active_tip_ids", ()))
        and row.get("event_boundary_topology_actions")
        == row.get("input_topology_actions", -1)+1
        and row.get("split_competition_exact", False)
        and row.get("split_rng_exact", False)
        and row.get("split_event_counters_exact", False)
        and row.get("split_void_history_exact", False))


def qualification_passes(native, reduced, comparison):
    comparisons = (
        ("event_time_relative_error", "event_time_relative"),
        ("plastic_strain_relative_error", "plastic_strain_relative"),
        ("density_relative_error", "density_relative"),
        ("vacancy_relative_error", "vacancy_relative"),
        ("vacancy_ledger_relative_error", "ledger_relative"),
    )
    return bool(
        connected_row_qualifies(native) and connected_row_qualifies(reduced)
        and native.get("provider_rebuild_count") == 0
        and reduced.get("provider_rebuild_count", 0) >= 1
        and all(finite_nonnegative(comparison.get(key))
                and comparison[key] <= LIMITS[limit]
                for key, limit in comparisons))


def advance_with_provider_manager(
    state, duration, *, reduced, provider_tuple, build_providers,
    advance_interval, interval_kwargs,
):
    mechanics, transport, manager = (
        build_providers(state, reduced) if provider_tuple is None else provider_tuple)
    if manager is not None:
        from .reduced_numerical_providers import topology_dependency_identity
        if mechanics is not manager.mechanics or transport is not manager.transport:
            raise RuntimeError("continuation providers disagree with manager ownership")
        if manager.dependency_identity != topology_dependency_identity(state):
            raise RuntimeError("continuation manager is not bound to restored state")
    final, audit = advance_interval(
        state, duration, mechanical_equilibrium_provider=mechanics,
        transport_linear_solver_provider=transport,
        provider_transition_manager=manager, **dict(interval_kwargs))
    if manager is not None:
        mechanics, transport = manager.mechanics, manager.transport
    return final, audit, (mechanics, transport, manager)
