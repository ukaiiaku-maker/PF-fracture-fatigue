# Prospective complete closure execution protocol

This implementation extends the retained `d69187e` checkpoint. It does not
replace the V2, blocked V3, or previous closure evidence. Scientific limits
remain the registry frozen at `da742b231b4413b3118e0546256bfadaf9022a55`.
An implementation or evidence-ontology PASS is not scientific qualification.

Before new attesting execution, this protocol freezes:

The replacement controlled healing predecessor uses stochastic seed 12010,
selected from the exploratory 32-seed run because its actual competing clocks
reach healing first. Two real birth hits precede a -0.4 micrometre compressive
reload at 900 K. This selection is a named controlled positive peer, not an
unbiased ensemble result or a repaired result for the old deterministic input.
The old failed deterministic healing cases remain historical. No rate or
threshold is replaced; all 32 natural seeds remain in the ensemble unfiltered.

The exploratory 16-microsecond run exposed nine seed/partition inventory
failures from separately adding and subtracting the same floating-point area
transfer. The replacement implementation computes the available account as the
complement of consumed inventory in the accepted total. The transfer, growth
law and frozen 1e-24 square-metre tolerance are unchanged.

- 45 physical transition attempts (nine named stages, partitions 1/2/4/8/16).
- All 11 registered restart stages, with actual subsequent-operation equality.
  The terminal requires accepted child-tip continuation, not merely child birth.
  An unavailable prerequisite stage is recorded as unavailable, never relabeled.
  The zero-drive restart applies a prospective 0.8 micrometre tensile opening.
- The existing twelve physical controlled inputs, including an actual bounded
  refinement attempt followed by downstream first-passage evaluation.
- All 22 lifecycle rollback stages, plus retained promotion/ligament injections.
  PASS requires the named injection to be reached, its exact exception, and
  complete accepted-state restoration. The negative chemical-potential
  inventory-return interval is one second at -1e-20 J; it uses the existing
  shrinkage mobility and source-native rates, not a replacement rate.
- Natural seeds 12000 through 12031, opening 0.4 micrometres, 900 K, duration
  16 microseconds. Each seed runs partitions 1/2/4/8/16 in each half-window;
  checkpoint/restart occurs at eight microseconds. The production driver
  localizes actual owned first passages, creates/debits physical cavities,
  grows/remeshes/equilibrates them, and attempts later physically available
  stages. Requested and actually elapsed time are separate; a failed interval
  is not reported as completed. No-birth is allowed. This replaces neither
  the retained 16-picosecond smoke screen nor its historical result.
- Stagewise inventory, generalized physical/projected length, active-front,
  event ownership, cavity-cycle and independently calculated topology checks.
  The lifecycle `/3` contract records these inside each accepted production
  interval and independently replays the natural histories from their complete
  initial checkpoints to verify every internal measurement and state hash.

Policy C remains fail closed. The bounded coarse and fine source-refinement
peers execute actual conforming refinement, field transfer, equilibrium and
source revalidation. The fine peer additionally attempts one protected-edge
quality sweep. A failed peer is reported as failed, not omitted or promoted
through a caller-authored flag. The eleven legacy downstream-positive
expectations cannot be declared repaired until a genuinely qualified positive
peer exists. Their machine-readable triage retains that unmet condition.

Evidence must be generated twice from a clean committed implementation, with
portable manifests and checkpoint payloads below the hosting object-size
limit. A current `/2` ontology is not retrospective attestation of `/1`
historical evidence. Exact A/B comparison, raw scientific failures, clean-worker
reproduction and repository-wide inherited-CI classification are distinct
ledger entries. No RC or merge is authorized by an evidence reproduction PASS.

The d69187e workflow's fresh traction A/B was byte-exact. Its retained Linux
canonical comparison nevertheless failed: source mesh, stiffness, boundary and
support arrays were exact, all 69 predicate outcomes agreed, but some recovered
values and one geometry observable differed at floating-point roundoff despite
matching recorded package versions. That cross-worker exact comparison remains
FAIL; missing CPU/BLAS runtime provenance prevents a narrower causal claim.
The historical files and exact comparator are retained. Later independent
workflow audits run even if that comparison fails.
# Failed controlled preparation provenance

Lifecycle schema /4 binds each controlled case's fixed crack and site center
to decoded accepted checkpoints, including failed preparations. The oblique
preparation's support rejection is retained with its last actual accepted
geometric-promotion state; a centered available-site fallback is invalid.
The /3 paired run at 034af1f is superseded for this evidence defect. No support
certificate or numerical limit is relaxed. Re-execute the complete lifecycle
pair from the committed /4 implementation before publication.
The retained geometric-promotion checkpoint independently identifies nodes
404 through 408 at y = -0.0005 m as prescribed bottom-boundary nodes. Their
four tube-intersecting edges are loaded edges, not the root's external free
component; extending the boundary-terminal exception would be unjustified.
