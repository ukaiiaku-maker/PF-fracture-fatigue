# Prospective V5 source-resolution and final-closure protocol V1

Baseline: `c4fbd2fec207d1a0964db1a02069af62bc0aacde`, retained permanently as
`V5_V3_CLOSURE_COMPLETE_BUT_BLOCKED`. This protocol is frozen before the new
qualifying sentinel runs. It does not revise the old 683/791 static result,
raw-CST evidence, historical raw full-state identity failures, or any existing
physical-law tolerance. New evidence lives only under
`artifacts/voiding_v5_source_resolution_and_final_closure/`.

## Execution sequence

1. Locate every q < 0.05 triangle in the rejected fine source-refinement trial;
   retain exact coordinates, topology/source relationships and available
   operation lineage. Unknown historical parentage must be explicitly unknown,
   never inferred as a recorded fact.
2. Try materially distinct quality transactions: repeated legal flips, then
   constrained free-interior node optimization; bounded Steiner/local-patch
   retriangulation follows if needed. Preserve every physical boundary, graph,
   support, source and front node/edge. No inverted triangle is admissible.
3. In parallel evaluate a separately versioned deterministic source recovery
   operator, preserving raw CST measurements and the FEM solution. Operator
   geometry/weights and conditioning must be auditable; no desired tensor may
   be imposed to obtain a pass.
4. Apply the prospective transfer budgets below to identical owned candidates
   and thresholds before allowing event selection.
5. Exercise coarse fail-closed and genuinely qualified positive peers, real
   first passage, one child and ordinary child-tip continuation; unavailable
   stages remain failures/not exercised.
6. Correct canonical physical time/hazard/radius integration, then execute the
   45 transition and 11 common-terminal restart cases plus reached rollbacks.
7. Reclassify static convergence families under a new version, and audit
   historical differing-field consumers before any causal-neutrality exclusion.
8. Only when the preceding development/classification phases are complete,
   execute the full source-bound campaign once as separate A/B runs, validate
   independently, publish implementation and evidence separately, execute
   exact-head CI and update PR #63's terminal ledger.

Development uses four sentinels: cavity-only source, connected production
source, deliberately poor-shape negative, and fixed-crack offset source.
Existing trusted captures may be analyzed without claiming new physical solves.
No broad 64-solve/274-row campaign after individual small edits.

## Prospective source-transfer budgets

Design target: at most 5% multiplicative uncertainty in a localized,
constant-positive-rate first-passage waiting time due to numerical source
representation. This is a declared numerical-design target, not experimental
calibration and not a relaxation of the existing 1e-12 partition-time gate.
For preserved remaining hazard H, t = H/lambda. Therefore
`abs(log(lambda/lambda_ref)) <= log(1.05)` bounds both rate and waiting-time
ratios between 1/1.05 and 1.05. The total log budget is split equally between
recovery-vs-reference and successive quality-valid refinement comparisons;
each receives `log(1.05)/2`, so their multiplicative bounds compose to 1.05.

Require at each allocated comparison:

- tensor relative error <= existing 0.05;
- absolute effective barrier difference / kBT <= log(1.05)/2;
- absolute log-rate difference <= log(1.05)/2;
- localized waiting-time relative error <= sqrt(1.05)-1;
- total reference waiting-time relative error <= 0.05;
- exact candidate, cavity, boundary-site, normal/tangent convention, threshold,
  RNG and event-classification ownership; mesh-dependent source captures must
  identify their distinct geometries and common physical source provenance.

Barrier clamping/prefactors are evaluated through the existing rate law, not
assumed interchangeable with barrier difference. Zero/nonfinite/underflowed
reference rates cannot establish positive qualification: compare inactivity
classifications exactly, never divide by a zero/near-zero reference rate.
Log rates should be calculated in the existing law's stable log domain.
Qualification also requires global q >= 0.05, unchanged geometry/topology,
existing resolution screens, frozen equilibrium/energy/reaction/tensor gates,
Kirsch error <= 0.03, and manufactured/rotation/order recovery checks.

## Prospective integration and static-family policy

Canonical accepted time resolution: 1e-24 s, with integer ticks and persisted
subtick remainder if needed; nonrepresentable caller partitions may not lose
time. At the registry's physical event scales this is below the existing
1e-12 relative timing limit. Caller subdivision is not a physical geometry
generation. Constant-rate clocks and material inventories derive from common
cumulative accepted intervals, not repeated rounded increments. Variable-rate
quadrature and root refinement must be tied to physical-time anchors, not the
caller's interval subdivision. Full fingerprints remain intact.

Static qualification V1 retains all coarse failures and requires at least two
quality-valid fine levels, decreasing/stable-limit convergence and final-level
accuracy at the existing frozen physical tolerances. Practical source levels
are 32/12, 64/24 and 128/48, compared with retained matched 512/192 data;
static fine families retain 128/48, 256/96 and 512/192 where applicable.
Operator/source representation is explicit in every row. New family-level
classification never rewrites original per-row V3 outcomes.

## Terminal rules

Try at least two materially distinct mesh strategies and both raw/recovered
source routes before an unresolved source conclusion. Complete all independent
remaining phases even if no positive source qualifies. Preserve historical
raw identity FAIL while classifying audited future-evolution causal equality
separately. Historical traction reconstruction runs in a separate archival
workflow, with its actual result retained. No scientific pass by field deletion,
tolerance fitting, fabricated first passage or substituted helper event.

Normal descendant publication is authorized on the existing finalization-v2
branch. No force, rewrite, squash, rebase, merge or RC before all mandatory
scientific gates pass. Preserve `r_tip != R_void`; no multiple voids, general
multifront production, calibration, fatigue or experimental-validation claims.

## Final evidence publication identity

The final scheduling registry uses 35 physical A/B jobs with at most eight
workers. Each of the 11 common-terminal restart positions owns a separate job,
after single-side multi-case development shards exceeded 160 minutes. Each job
still generates A and B independently and sequentially on the same worker.
The registered 45 transitions, 11 restarts, 12 controlled histories, 39 rollback
attempts, 160 natural peers and 96 static solves are unchanged. Repeated source
preparation is execution overhead, not an extra registered restart case.

Freeze publication tooling before the one full A/B generation. The completed
CI bundle may be stored as deterministic gzip/tar parts no larger than 80 MiB.
No JSON, checkpoint, original inventory or failed scientific result is edited
inside that archive. Safe extraction rejects traversal, symlinks, duplicate or
unregistered members, and rechecks every original file hash.
After complete ontology and A/B comparison, a separate CI packaging job creates
these parts from the uploaded complete bundle. Its output is storage, not another
physical execution. Both the original complete bundle and the lossless parts are
uploaded, allowing local publication without a second full extracted copy on
limited local disks. The later exact-head audit still performs full extraction
and reconstruction; downloading an archive is not an evidence-validity PASS.

The implementation commit generates the evidence. A later normal descendant
commit stores it. The exact-publication-head audit requires identical complete
non-artifact Git trees and permits only changes under the authorized new
evidence root. It then reconstructs the published evidence in a clean detached
worker at the explicitly recorded implementation SHA, including all static
sources, positive and causal sources, lifecycle ontology and full A/B equality.
This is not falsely described as generation at the later publication SHA.
The entire focused registry runs separately at the exact publication head;
repository-wide CI retains its own failure classification.

The registered workflow entry uses operation `final` for the one complete
campaign and operation `audit` for this later publication audit. Neither is a
release qualification when a mandatory scientific gate remains failed.

## Prospective numerical-runtime contract

Same-SHA development restart shards demonstrated different complete terminals
despite identical declared NumPy/SciPy versions and thread counts. These retained
results remain exact-equality failures. They cannot establish which CPU dispatch
caused a difference without a controlled intervention.

Before final generation, the separately executed read-only runtime diagnostic
compares native, Haswell-only, NumPy-baseline-only and combined selections on
the same retained state, with an independent combined-policy repeat. This is
not another physical campaign or retrospective source qualification.

The final x86 clean workers prospectively use Python 3.12.14, NumPy 2.5.3,
SciPy 1.18.1, one BLAS/OpenMP thread, OpenBLAS `HASWELL`, and no optional NumPy
CPU-dispatch targets. The bootstrap obtains the installed wheel's dispatch list,
excludes mandatory baseline features, and configures subsequent processes.
Actual loaded BLAS architecture/thread count and NumPy dispatch are checked,
recorded, and required to match every producer, assembler and publication
reconstructor. An unsupported or ignored policy fails closed. The policy does
not modify a physical equation, scientific tolerance, or fingerprint field.

Upstream mechanisms: [NumPy runtime dispatch](https://numpy.org/doc/stable/reference/simd/build-options.html),
[OpenBLAS runtime variables](https://www.openmathlib.org/OpenBLAS/docs/runtime_variables/),
and [threadpoolctl runtime introspection](https://github.com/joblib/threadpoolctl).
Portable numerical-kernel selection is not a claim of universal cross-platform
bitwise reproducibility; the resulting full A/B and source reconstructions must
still execute and pass independently.

## Storage preflight and immutable assembly

The all-shard assembly must retain every checkpoint and both evidence peers.
Before the one physical campaign, operation `storage-preflight` verifies at
least 24 GiB available on a disposable GitHub-hosted Linux runner. If needed,
only fixed, canonical, non-symlink preinstalled Android/.NET/GHC SDK directories
are cleared. The script refuses user and self-hosted environments, never targets
the repository, evidence or Python, and fails if sufficient capacity is still
unavailable. Each final producer, assembler, packager and publication auditor
repeats that capacity check. New disposable runners restore the unused SDKs.

Assembly hardlinks immutable source captures on the same filesystem, with
byte-preserving copying only when links are unsupported or cross-filesystem.
Conflicting destination hashes and symlinks are rejected. No source JSON is
rewritten through a shared link, and all original shard inventories are checked
again after successful complete assembly. This reduces duplicate storage only;
independent A/B physical executions, every source byte, and all predicates remain
mandatory.
