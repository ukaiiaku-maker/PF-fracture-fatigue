# Source-resolution development findings (nonterminal)

The full a34cdf0 static development phase completed all 96 unique physical
solves, with no solver execution failures. Independent raw-source reconstruction
validates all 96 captures and reproduces the classification: 434/537 family
predicates pass, 0/33 complete families qualify, and 8/12 derivative checks pass.
Failures comprise 30 fixed-tip fine-accuracy gates, 13 each reaction/compliance/
energy stable-limit gates, 12 recovered fixed-arc accuracy gates, 11 two-fine-
quality gates, six recovered fixed-arc stable-limit gates and five raw full-
boundary traction gates. All four perturbation-size convergence checks fail;
the eight individual energy/compliance derivative checks pass. No frozen limit
or the earlier 683/791 classification is changed.

Clean `38a7686` source causality executed all six real interventions. All source
separation and zero-drive guards pass, but doubling the owned child radius in
both process state and branch local state leaves continuation rates unchanged.
The radius-causal-use gate is therefore FAIL, while distinct `r_tip != R_void`
ownership remains true. This is an actual measured limitation, not merely a
missing diagnostic or permission to introduce an unqualified stress law.

Repository-wide run `34180123467` at `352d1d7` reached its 90-minute allowance
and was cancelled; its transcript was uploaded. This is incomplete repository-
wide CI, not inherited-only qualification and not green. The prospective wall-
clock allowance is increased to 180 minutes for the repository-wide and final
full-regression jobs. Focused run `34180123490` at the same head succeeded.
No test, scientific predicate or tolerance is relaxed by the time allowance.

Later repository-wide run `34184892468` at `787ebf6` completed in 4581.50 seconds:
1115 passed, one skipped and exactly seven failed. Its complete failure-identity
set matches the recorded inherited baseline, with no additional failures. This
does not reclassify the earlier timeout or claim that repository-wide CI is green.

Phase-8 rollback run `34184427615` at `facbc24` completed all 39 attempts. Read-only
checkpoint reconstruction verifies every initial/terminal complete fingerprint,
input identity, conservation ledger and independent topology certificate. All
39 intended injections were reached and complete states restored, including all
28 lifecycle stages and the five downstream source/child/continuation stages.
This is complete rollback development evidence, not final A/B qualification or
proof of the separately running common-terminal restart matrix.

Completed transition shard 0 from run `34189099900` records Python 3.12.14,
NumPy 2.5.3 and SciPy 1.18.1, with the optional mesh/JIT packages absent. The
final campaign freezes these numerical versions prospectively. A local read-
only reconstruction of restart shard 2 under Python 3.12.13 / NumPy 2.5.1 /
SciPy 1.18.0 reproduces complete checkpoint identities and the topology PASS
predicate, but differs in two copies of `h_local_median_m` by about 4e-20 m.
That strict reconstruction is NOT a PASS. A dedicated Linux reconstruction
uses the recorded versions and the identical full-ontology row checks, without
loosening comparison or running another physical campaign. Every selected
45/11/39-case registry must be complete before that development audit passes.

Read-only diagnostic `34197537829` at `c8b53a6` completed on three independent
x86 workers. Two autodetected SkylakeX and one Haswell in both loaded OpenBLAS
libraries. On the identical retained shard-2 terminal, the native topology
hashes differ between these targets. Changing only OpenBLAS from SkylakeX to
Haswell changes the topology hash; disabling optional NumPy dispatch alone does
not. All three combined fixed-policy records, including their independent
repeats, are exactly identical. This identifies a genuine BLAS-dispatch effect,
not universal cross-platform reproducibility or a retrospective restart PASS.
The later complete campaign must generate and reconstruct all its own physical
evidence under the prospectively frozen kernel contract.

Independent Linux section audit `34199690728` at `2fa81f2` validates all 39
rollback rows and all 45 transition rows. The transition section remains FAIL:
55/56 total source rows reconstruct, with one extra stagewise
`continued_accepted_event` certificate failing exact reconstruction. All shard
decisions recompute and no checkpoint-name/hash collisions occur. The local
read-only probe isolates two repeated `h_local_median_m` differences,
1.3021257146671744e-7 versus recorded 1.3021257146667747e-7 m; both topology
predicates are true. These exact differences remain failures, not toleranced
passes. The new final runtime contract applies prospectively only.

The a34cdf0 45-case development run exposed loss of the owned child endpoint
inventory during partial clock intervals: child nucleation passes at all five
partitions, but child continuation initially passes only unsplit. `facbc24`
retains the endpoint inventory only for exactly the same front, position and
graph generation. Different owners do not inherit it. Its clean actual
continuation sentinel passes all five partitions with identical complete states.
The final same-head all-45 campaign remains a separate required execution.

The stronger +8e-7 m common reload fails both one- and two-ring timing budgets
at `c284427`; the second waiting-time transfer error is 0.1037261217. Retain
those failures. The additional prospective V2 protocol returns from compression
to the original +4e-7 m tensile load and asks a distinct matched-load restart
question. Its definition is in `V5_COMMON_TERMINAL_RESTART_PROTOCOL_V2.md`;
it does not relabel or qualify the stronger-load V1 cases.

At clean a34cdf0, the disabled causal comparison has exact observed causal
states and event histories in all four cases, but its full prospective future
sequence still fails. Monotonic, restart and unload/reload cases reach two real
matching events, then both candidate-plane openings become negative (the
monotonic case measures about -40.98 and -222.20 MPa). The oblique case reaches
one matching event and then both implementations reject active-tip leakage.
These are not changed-mechanics differences or grounds to force a next event.
Raw historical identity remains FAIL; full future-sequence qualification remains
FAIL, with observed-prefix equality reported separately.

The 352d1d7 targeted actual-state rerun passes all 25 site/stabilization/healing/
subgrid-growth partition cases after supplying the identical exact first-passage
interval to every partition. The a34cdf0 failures remain retained. Subsequent
natural-window diagnostics distinguish arithmetic from physical remesh history:
accepted time is now exactly the requested window for all five partitions;
remaining seed-12000 differences at 8/16 partitions include an extra actual
resolved-cavity remesh, different projected density/P0 damage and FEM response.
Those are not removable audit fields. A variable-rate/remesh-path-independent
production integrator is still unqualified; the piecewise-linear clock helper
alone is not evidence that this coupled-FEM requirement passes.

The preserved c4fbd2f V3 result remains COMPLETE_BUT_BLOCKED. Development has
located all 19 fine-source global-quality failures in unchanged triangles near
the old crack tip, roughly 182–183 micrometres from the cavity source. The
current refinement did not create these elements. Missing earlier lineage is
reported as unknown, not reconstructed history.

Interface/geometry-constrained flips increase minimum quality from .03199422 to
.05370467. Actual field transfer, support reconstruction, equilibrium, topology,
inventory, reaction/compliance/energy and fixed-source checks pass in the fine
connected sentinel. One subsequent complete-ring refinement passes the frozen
source screens and prospective same-owned-threshold time budget (about 1.10%
waiting-time transfer error). Coarse sources remain unavailable.

Two implementation defects blocked the first actual child trial: stale cavity
boundary edge IDs after refinement, and a segment-intersection predicate that
reported contact between disjoint coordinate bounding boxes for short edges.
Fresh endpoint contexts and an unchanged-tolerance necessary bounding-box test
allow actual first passage, a sole active child, and one ordinary child-tip
continuation to commit. All rejected development trials remain in temporary
evidence and will be retained in the final publication package. These are not
clean final A/B attestations.

Important limits remain:

- At the retained fixed load the actual nucleation waiting time is approximately
  4.59e12 seconds and the first continuation wait is 7.45e16 seconds. These are
  real integrated-clock events, NOT events within the 16-microsecond natural
  ensemble. No event-time cap, threshold, cleavage law or temperature was changed.
- The legacy incident-CST child probe and cleavage API carry `r_tip` ownership,
  but the probe does not use it as an analytical `K/sqrt(2*pi*r_tip)` stress scale.
  This cannot be claimed as complete analytical moving-tip process-state
  coupling. Keep a separate failed causal-use gate; do not invent a radius
  conversion or replace the source law to make this green. `r_tip != R_void`.
- The recovered practical 32/64/128 tensors fail prospective timing transfer.
  Their native exit coordinates also differ from the 512 reference. No projected
  point is substituted to claim exact physical-source identity.
- The centered new static family has quality-valid 256/512 peers, convergent
  reaction/compliance/energy, raw boundary traction and recovered cavity tensors,
  but fixed-tip tensor error .08353 still fails the frozen .05 limit.
- Historical raw disabled identity remains FAIL. Causal equality is a separate
  audited extension; failed future operations must not be counted as completed
  neutral histories.

## Lifecycle qualification V5 prospective execution contract

Schema `v12.voiding-v5-closure-actual-lifecycle/5` retains all old artifacts and
adds exact accepted-time ticks/subticks, constant-source anchored directional
hazards, exact site integrals and cumulative positive subgrid growth. The natural
32-seed window remains 16 microseconds with unchanged partitions and criteria.
Variable FEM-dependent source changes and resolved-remesh subdivision remain
subject to the full fingerprints, not erased fields.

The current `/7` schema additionally binds the common continued terminal to its
actual child path, lineage and accepted sharp-front event, and retains separate
direct/replay failures and the prospectively versioned common-load restart
protocol. Earlier `/5` and legacy failed restart evidence remain unchanged and
are not silently promoted to that stronger terminal contract.

Transition and common-terminal restart tests localize the actual next event at
fixed load, recording its possibly very long waiting time. They are no longer
conflated with the natural finite-window experiment. The optional fine-history
runner uses an explicitly fixed crack with 512/192 initial resolution for the
positive transition/restart peers and controlled histories. Natural seeds,
healing control, and the genuinely 32-to-64 local-remesh control retain their
separate declared inputs. Fine restart geometry must preserve its configured
resolution through promotion and resolved growth. No earlier 16-us failed row
is rewritten.

Rollback now includes five quality-repair stages and source qualification. The
child-support injection is after the actual child support rebuild, not an earlier
endpoint-conformity rebuild. A stage that is never reached remains a failure.
