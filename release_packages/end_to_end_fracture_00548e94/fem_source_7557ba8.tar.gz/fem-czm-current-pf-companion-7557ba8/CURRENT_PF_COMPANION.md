# Current-PF FEM/CZM companion

This branch is a separate companion to the frozen
`v10.0.5.18.4.0-theta0-pf-parity` checkout at `2934911`. It does not modify
that checkout or weaken its required historical `a85b57…` kernel guard.

The companion executes the same native full-order adaptive-CZM builder with
the currently available immutable family:

- family SHA-256: `d41b08f69ae773009f65f4c0094ef5436ba7f0f290a94172e5b894d09a41f7c3`
- mechanical-configuration fingerprint:
  `1447653d199f0b43cb475951092d69444c9b785f6fdf518c723792abb3b1f5e5`

It is not a recreation of the unavailable historical `e239710…`
configuration. The FEM crack backend remains the adaptive CZM atomic-path
corridor; the PF comparison backend is sharp-wake. The full-field bulk law is
the existing exact v10.4.1 Peierls–Taylor detailed-balance port. It evolves a
local continuum field but does not spatially transport bulk dislocation
density.

The launcher refuses to overwrite an output directory and requires a clean
`codex/current-pf-companion` branch. A durable, independently verified backup
must be completed before running it:

```bash
OUT=/new/evidence/path ./run_current_pf_companion_one_step.sh
```

The one-step run is a full-order no-event-or-first-event bounded execution,
not a claim that a fracture event must occur in one accepted step.

The informative continuation is frozen in
`CURRENT_PF_COMPANION_FIRST_PASSAGE_MATRIX.json` and launched with:

```bash
OUT=/new/evidence/path ./run_current_pf_companion_first_passage.sh
```

It replays the short initial prefix from the corrected theta-zero initial
state and stops at 10 µm projected extension or 500 accepted steps.
