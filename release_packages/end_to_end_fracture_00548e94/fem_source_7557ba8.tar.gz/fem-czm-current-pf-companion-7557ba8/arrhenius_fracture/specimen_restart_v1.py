"""Native-owner specimen checkpoints for the 2-D fracture driver.

The container records the specimen envelope (mesh, bulk fields, loading and
topology bookkeeping).  Constitutive state is not reimplemented here: objects
which expose ``state_dict``/``from_state_dict`` are serialized through those
native owners.  Large arrays are stored losslessly in a companion NPZ file.
"""
from __future__ import annotations

import hashlib
import importlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .cohesive import CohesiveNetwork


SCHEMA = "fem-czm-specimen-checkpoint/1"
MANIFEST = "checkpoint.json"
ARRAYS = "arrays.npz"


@dataclass(frozen=True)
class _DeferredNativeState:
    owner: str
    payload: dict[str, Any]


def _class_id(obj: Any) -> str:
    cls = type(obj)
    return f"{cls.__module__}:{cls.__qualname__}"


def _resolve_class(identifier: str):
    module_name, qualname = identifier.split(":", 1)
    obj = importlib.import_module(module_name)
    for part in qualname.split("."):
        obj = getattr(obj, part)
    return obj


class _Encoder:
    def __init__(self) -> None:
        self.arrays: dict[str, np.ndarray] = {}

    def encode(self, value: Any, path: str = "root") -> Any:
        if isinstance(value, np.ndarray):
            key = f"a{len(self.arrays):06d}"
            self.arrays[key] = np.asarray(value)
            return {"__kind__": "ndarray", "key": key}
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, Path):
            return {"__kind__": "path", "value": str(value)}
        if isinstance(value, type):
            return {"__kind__": "python_type", "value": f"{value.__module__}:{value.__qualname__}"}
        if isinstance(value, tuple):
            return {"__kind__": "tuple", "items": [self.encode(v, f"{path}[{i}]") for i, v in enumerate(value)]}
        if isinstance(value, list):
            return [self.encode(v, f"{path}[{i}]") for i, v in enumerate(value)]
        if isinstance(value, dict):
            return {
                "__kind__": "mapping",
                "items": [[self.encode(k, f"{path}.key"), self.encode(v, f"{path}[{k!r}]")]
                          for k, v in value.items()],
            }
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        state_dict = getattr(value, "state_dict", None)
        owner = getattr(type(value), "from_state_dict", None)
        if callable(state_dict) and callable(owner):
            return {
                "__kind__": "native_state",
                "owner": _class_id(value),
                "payload": self.encode(state_dict(), path + ".native_state"),
            }
        raise TypeError(f"checkpoint cannot encode {type(value)!r} at {path}")


def _decode(value: Any, arrays: dict[str, np.ndarray]) -> Any:
    if isinstance(value, list):
        return [_decode(v, arrays) for v in value]
    if not isinstance(value, dict) or "__kind__" not in value:
        return value
    kind = value["__kind__"]
    if kind == "ndarray":
        return np.asarray(arrays[value["key"]]).copy()
    if kind == "path":
        return Path(value["value"])
    if kind == "python_type":
        return _resolve_class(value["value"])
    if kind == "tuple":
        return tuple(_decode(v, arrays) for v in value["items"])
    if kind == "mapping":
        return {
            _decode(k, arrays): _decode(v, arrays)
            for k, v in value["items"]
        }
    if kind == "native_state":
        return _DeferredNativeState(
            owner=value["owner"], payload=_decode(value["payload"], arrays)
        )
    raise ValueError(f"unsupported checkpoint encoding kind {kind!r}")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_checkpoint(directory: str | Path, payload: dict[str, Any]) -> Path:
    """Atomically publish a checkpoint directory after both files are durable."""
    target = Path(directory).expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)
    encoder = _Encoder()
    encoded = encoder.encode(payload)
    arrays_tmp = target / (ARRAYS + ".tmp.npz")
    manifest_tmp = target / (MANIFEST + ".tmp")
    np.savez_compressed(arrays_tmp, **encoder.arrays)
    arrays_path = target / ARRAYS
    arrays_tmp.replace(arrays_path)
    manifest = {
        "schema": SCHEMA,
        "arrays_file": ARRAYS,
        "arrays_sha256": _sha256(arrays_path),
        "payload": encoded,
    }
    manifest_tmp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    manifest_tmp.replace(target / MANIFEST)
    return target


def read_checkpoint(directory: str | Path) -> dict[str, Any]:
    target = Path(directory).expanduser().resolve()
    manifest = json.loads((target / MANIFEST).read_text())
    if manifest.get("schema") != SCHEMA:
        raise ValueError("unsupported specimen checkpoint schema")
    arrays_path = target / str(manifest.get("arrays_file", ARRAYS))
    if _sha256(arrays_path) != manifest.get("arrays_sha256"):
        raise ValueError("specimen checkpoint array digest mismatch")
    with np.load(arrays_path, allow_pickle=False) as archive:
        arrays = {name: archive[name] for name in archive.files}
    payload = _decode(manifest["payload"], arrays)
    if not isinstance(payload, dict):
        raise ValueError("specimen checkpoint payload is not a mapping")
    return payload


def update_attestation(directory: str | Path, attestation: dict[str, Any]) -> None:
    """Bind a provider-produced refinement record without rewriting state arrays."""
    target = Path(directory).expanduser().resolve()
    path = target / MANIFEST
    manifest = json.loads(path.read_text())
    if manifest.get("schema") != SCHEMA:
        raise ValueError("unsupported specimen checkpoint schema")
    manifest["refinement_attestation"] = attestation
    tmp = target / (MANIFEST + ".tmp")
    tmp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def read_attestation(directory: str | Path) -> dict[str, Any] | None:
    manifest = json.loads((Path(directory).expanduser().resolve() / MANIFEST).read_text())
    value = manifest.get("refinement_attestation")
    return None if value is None else dict(value)


def capture_engine(engine: Any) -> dict[str, Any]:
    """Capture through the most-derived native kinetic snapshot owner."""
    capture = getattr(engine, "_capture_state", None)
    if callable(capture):
        state = capture()
        owner = "_capture_state/_restore_state"
    else:
        state = {
            name: getattr(engine, name)
            for name in ("N_em", "B", "a_adv", "n_adv", "W_emit", "t", "K_prev")
        }
        owner = "FrontEngine scalar state"
    return {"class": _class_id(engine), "owner": owner, "state": state}


def restore_engine(engine: Any, payload: dict[str, Any]) -> None:
    if payload.get("class") != _class_id(engine):
        raise ValueError(
            "restart engine provider mismatch: "
            f"checkpoint={payload.get('class')!r}, runtime={_class_id(engine)!r}"
        )
    state = dict(payload["state"])
    for name, value in list(state.items()):
        if not isinstance(value, _DeferredNativeState):
            continue
        current = getattr(engine, name, None)
        cls = _resolve_class(value.owner)
        if current is not None and type(current) is not cls:
            raise ValueError(
                f"restart native state owner mismatch for {name}: "
                f"checkpoint={value.owner!r}, runtime={_class_id(current)!r}"
            )
        kernel = None
        if current is not None:
            kernel = getattr(current, "kernel_family", None)
            if kernel is None:
                kernel = getattr(current, "kernel", None)
        try:
            state[name] = cls.from_state_dict(value.payload, kernel)
        except TypeError:
            state[name] = cls.from_state_dict(value.payload)
    restore = getattr(engine, "_restore_state", None)
    if payload.get("owner") == "_capture_state/_restore_state":
        if not callable(restore):
            raise ValueError("checkpoint requires the native engine restore owner")
        restore(state)
        return
    for name, value in state.items():
        setattr(engine, name, value)


def capture_backend(backend: Any) -> dict[str, Any]:
    """Capture topology and cohesive history owned by the active backend."""
    if hasattr(backend, "_delegate"):
        adapter_state = getattr(backend, "restart_state_dict", lambda: None)()
        return {
            "class": _class_id(backend),
            "name": str(getattr(backend, "name", "unknown")),
            "delegate": capture_backend(backend._delegate),
            "adapter_state": adapter_state,
        }
    network = getattr(backend, "cohesive_network", None)
    mutable: dict[str, Any] = {}
    for name, value in vars(backend).items():
        if name in {"geom", "cohesive_network"}:
            continue
        # Backend wrappers keep only arrays/mappings/scalars in mutable fields.
        mutable[name] = value
    return {
        "class": _class_id(backend),
        "name": str(getattr(backend, "name", "unknown")),
        "mutable": mutable,
        "cohesive_network": None if network is None else network.state_dict(),
    }


def restore_backend(backend: Any, payload: dict[str, Any]) -> None:
    if payload.get("class") != _class_id(backend):
        raise ValueError(
            "restart crack-backend provider mismatch: "
            f"checkpoint={payload.get('class')!r}, runtime={_class_id(backend)!r}"
        )
    if "delegate" in payload:
        if not hasattr(backend, "_delegate"):
            raise ValueError("checkpoint requires a delegated crack backend")
        restore_backend(backend._delegate, payload["delegate"])
        adapter_state = payload.get("adapter_state")
        if adapter_state is not None:
            restore = getattr(backend, "restore_restart_state", None)
            if not callable(restore):
                raise ValueError("checkpoint requires the geometry-adapter restore owner")
            restore(adapter_state)
        return
    for name, value in dict(payload.get("mutable", {})).items():
        setattr(backend, name, value)
    network = payload.get("cohesive_network")
    backend.cohesive_network = (
        None if network is None else CohesiveNetwork.from_state_dict(network)
    )


_MUTABLE_RUN_KEYS = {
    "out", "steps", "print_every", "save_snapshots", "snapshot_cols", "no_plots",
    "specimen_restart_from", "specimen_checkpoint_out", "specimen_checkpoint_step",
    "stop_after_specimen_checkpoint",
}


def physics_arguments(namespace: Any) -> dict[str, Any]:
    return {
        key: value for key, value in vars(namespace).items()
        if key not in _MUTABLE_RUN_KEYS
    }


def validate_physics_arguments(saved: dict[str, Any], namespace: Any) -> None:
    current = physics_arguments(namespace)
    if saved == current:
        return
    keys = sorted(set(saved) | set(current))
    changed = [key for key in keys if saved.get(key) != current.get(key)]
    raise ValueError(
        "restart physics/configuration mismatch in: " + ", ".join(changed[:20])
    )


__all__ = [
    "ARRAYS", "MANIFEST", "SCHEMA", "capture_backend", "capture_engine",
    "physics_arguments", "read_attestation", "read_checkpoint", "restore_backend",
    "restore_engine", "update_attestation", "validate_physics_arguments",
    "write_checkpoint",
]
