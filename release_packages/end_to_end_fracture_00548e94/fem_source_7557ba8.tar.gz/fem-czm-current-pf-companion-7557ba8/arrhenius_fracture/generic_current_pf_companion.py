"""Registry-driven entry to the independent FEM/CZM specimen solver.

The historical current-PF companion remains an exact Peak/1000 K reference
preset.  This entry exposes the inputs that the native specimen driver already
supports without weakening that preset.  Capabilities not yet carried by the
native cracked-body solver are rejected explicitly rather than converted into
labels or post-processing changes.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

from . import mode_i_first_passage_v10_0_5_18_four_class_stochastic_emission as _bridge
from . import mode_i_first_passage_v10_0_5_18_3_9_atomic_path_corridor as _native
from . import mode_i_first_passage_v10_0_5_13_barrier_only as _barrier
from .active_only_kernel_family_compat_v10051840 import (
    installed_active_only_kernel_family_compat,
)
from .four_class_parameter_bridge_v100518 import _candidate_from_row
from .mode_i_first_passage_v10_0_5_18_4_0_current_pf_tip_only_companion import (
    _persisted_refinement_payload,
)
from .specimen_restart_v1 import read_attestation, update_attestation

MODEL_ID = "FEM_CZM_generic_current_PF_registry_companion_v1"
AUDIT_FILE = "generic_current_pf_companion_contract_v1.json"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    parser.add_argument("--material-registry", type=Path, required=True)
    parser.add_argument("--parameter-option", required=True)
    parser.add_argument("--constraint", default="plane_strain")
    parser.add_argument("--source-scope", default="tip_only")
    parser.add_argument("--accommodation-mode", default="active_tip")
    parser.add_argument(
        "--opening-model", default="exp_floor_activated_native",
    )
    parser.add_argument("--restart-from", type=Path, default=None)
    parser.add_argument("--dry-run-config", action="store_true")
    return parser


def _option_value(argv: list[str], name: str) -> str | None:
    prefix = name + "="
    for index, token in enumerate(argv):
        if token.startswith(prefix):
            return token[len(prefix):]
        if token == name and index + 1 < len(argv):
            return argv[index + 1]
    return None


def _replace_option(argv: list[str], name: str, value: str) -> None:
    prefix = name + "="
    index = 0
    while index < len(argv):
        if argv[index] == name:
            del argv[index:min(index + 2, len(argv))]
        elif argv[index].startswith(prefix):
            del argv[index]
        else:
            index += 1
    argv.extend([name, str(value)])


def _one_registry_row(registry: Path, option: str) -> dict[str, str]:
    if not registry.is_file():
        raise SystemExit(f"material registry is missing: {registry}")
    with registry.open(newline="") as handle:
        rows = [row for row in csv.DictReader(handle)
                if row.get("option_key") == option]
    if len(rows) != 1:
        raise SystemExit(
            f"expected one registry row for {option!r}; found {len(rows)}"
        )
    return rows[0]


def _validate_supported(wrapper: argparse.Namespace) -> None:
    unsupported = []
    if wrapper.constraint != "plane_strain":
        unsupported.append(
            "constraint (only native plane_strain is integrated; plane_stress "
            "and generalized transverse control await R07)"
        )
    if wrapper.source_scope != "tip_only":
        unsupported.append(
            "source-scope (this generic entry currently supports tip_only; the "
            "source-bound full-field overlay is not silently generalized)"
        )
    if wrapper.accommodation_mode not in {"active_tip", "opening_only"}:
        unsupported.append(
            "accommodation-mode (supported modes are active_tip and opening_only)"
        )
    if wrapper.opening_model != "exp_floor_activated_native":
        unsupported.append(
            "opening-model (the generic specimen adapter has not yet connected "
            "the new bilinear laws to this production driver)"
        )
    if unsupported:
        raise SystemExit("unsupported generic FEM request: " + "; ".join(unsupported))


def resolve_request(argv: list[str]) -> tuple[dict[str, Any], list[str], Any]:
    """Validate a generic request and return its audit, native argv and row."""
    wrapper, native_args = _parser().parse_known_args(list(argv))
    _validate_supported(wrapper)
    registry = wrapper.material_registry.expanduser().resolve()
    row = _one_registry_row(registry, wrapper.parameter_option)
    candidate = _candidate_from_row(row)

    _replace_option(native_args, "--parameter-option", candidate.option_key)
    mode = _option_value(native_args, "--bulk-plasticity-mode")
    if mode not in (None, "tip_only"):
        raise SystemExit(
            "source-scope=tip_only conflicts with "
            f"--bulk-plasticity-mode={mode!r}"
        )
    _replace_option(native_args, "--bulk-plasticity-mode", "tip_only")
    native_opening_flag = "--disable-tip-accommodation"
    if wrapper.accommodation_mode == "opening_only":
        if native_opening_flag not in native_args:
            native_args.append(native_opening_flag)
    elif native_opening_flag in native_args:
        raise SystemExit(
            "accommodation-mode=active_tip conflicts with "
            "--disable-tip-accommodation"
        )
    if wrapper.restart_from is not None:
        restart = wrapper.restart_from.expanduser().resolve()
        attestation = read_attestation(restart)
        if not attestation or not bool(attestation.get("persisted_provider_verified", False)):
            raise SystemExit(
                "restart checkpoint lacks verified physical refinement-provider attestation"
            )
        _replace_option(native_args, "--specimen-restart-from", str(restart))
    out_raw = _option_value(native_args, "--out")
    if out_raw is None:
        raise SystemExit(f"{MODEL_ID} requires --out")

    audit = {
        "schema": MODEL_ID,
        "created_or_updated_utc": datetime.now(timezone.utc).isoformat(),
        "entry": __name__,
        "native_entry": _native.__name__,
        "material": {
            "registry": str(registry),
            "registry_sha256": _sha256(registry),
            "option_key": candidate.option_key,
            "candidate_id": candidate.candidate_id,
            "material_class": candidate.material_class,
            "constructor_visible": {
                "cleave_G00_eV": candidate.cleave_G00_eV,
                "emit_G00_eV": candidate.emit_G00_eV,
                "peierls_H0_eV": candidate.peierls_H0_eV,
                "taylor_H0_eV": candidate.taylor_H0_eV,
                "taylor_corr_rho_c_m2": candidate.taylor_corr_rho_c_m2,
                "rho_source0_m2": candidate.rho_source0_m2,
            },
        },
        "supported_native_request": {
            "constraint": wrapper.constraint,
            "source_scope": wrapper.source_scope,
            "accommodation_mode": wrapper.accommodation_mode,
            "opening_model": wrapper.opening_model,
            "temperature": _option_value(native_args, "--temperatures"),
            "crystal_theta_deg": _option_value(native_args, "--crystal-theta-deg"),
            "nx": _option_value(native_args, "--nx"),
            "ny": _option_value(native_args, "--ny"),
            "dU_m": _option_value(native_args, "--dU"),
            "dt_s": _option_value(native_args, "--dt"),
        },
        "unsupported_axes_fail_closed": {
            "plane_stress_or_generalized_constraint": True,
            "generic_full_field_source_scope": True,
            "opening_only": False,
            "generic_bilinear_specimen_path": True,
            "native_restart_deserialization": False,
        },
        "native_argv": list(native_args),
        "restart": {
            "requested": wrapper.restart_from is not None,
            "checkpoint": None if wrapper.restart_from is None else str(wrapper.restart_from.expanduser().resolve()),
            "native_owner_deserialization": wrapper.restart_from is not None,
        },
        "dry_run": bool(wrapper.dry_run_config),
        "run_completed_without_exception": False,
    }
    return audit, native_args, candidate


def main(argv: list[str] | None = None):
    user_args = list(sys.argv[1:] if argv is None else argv)
    audit, native_args, candidate = resolve_request(user_args)
    out = Path(_option_value(native_args, "--out") or "").expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    audit_path = out / AUDIT_FILE
    audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    if audit["dry_run"]:
        return audit

    key = candidate.option_key
    previous_expected = _bridge.EXPECTED_OPTIONS.get(key)
    previous_loader = _bridge.load_four_class_parameter_option
    previous_mesh_payload = _barrier._mesh_payload

    def load_selected(_source_root, requested):
        if requested != key:
            return previous_loader(_source_root, requested)
        transfer = {
            "schema": MODEL_ID + "/registry-transfer",
            "parameter_option": key,
            "candidate_id": candidate.candidate_id,
            "material_class": row_class,
            "source_registry": audit["material"]["registry"],
            "source_registry_sha256": audit["material"]["registry_sha256"],
            "constructor_visible": audit["material"]["constructor_visible"],
        }
        return candidate, transfer

    row_class = candidate.material_class
    _bridge.EXPECTED_OPTIONS[key] = (candidate.candidate_id, row_class)
    _bridge.load_four_class_parameter_option = load_selected

    def mesh_payload_with_persisted_record(mesh, requested_radius_m):
        observed = previous_mesh_payload(mesh, requested_radius_m)
        if observed.get("actual_radius_verified", False):
            return observed
        return _persisted_refinement_payload(out, requested_radius_m, observed)

    _barrier._mesh_payload = mesh_payload_with_persisted_record
    error = None
    try:
        with installed_active_only_kernel_family_compat(out):
            result = _native.main(native_args)
        checkpoint_raw = _option_value(native_args, "--specimen-checkpoint-out")
        if checkpoint_raw is not None:
            record = out / "compact_corridor_mesh_v91852.json"
            if not record.is_file():
                raise RuntimeError(
                    "cannot bind specimen checkpoint: compact refinement record is missing"
                )
            provider = json.loads(record.read_text())
            radius = provider.get("production_refinement_radius_m")
            recovered = _persisted_refinement_payload(
                out, float(radius) if radius is not None else float("nan"), {}
            )
            if not recovered.get("persisted_provider_verified", False):
                raise RuntimeError(
                    "cannot bind specimen checkpoint: physical refinement provider is unverified"
                )
            update_attestation(Path(checkpoint_raw), recovered)
        audit["run_completed_without_exception"] = True
        return result
    except BaseException as exc:
        error = exc
        raise
    finally:
        _bridge.load_four_class_parameter_option = previous_loader
        _barrier._mesh_payload = previous_mesh_payload
        if previous_expected is None:
            _bridge.EXPECTED_OPTIONS.pop(key, None)
        else:
            _bridge.EXPECTED_OPTIONS[key] = previous_expected
        audit["runtime_error_type"] = None if error is None else type(error).__name__
        audit["runtime_error"] = None if error is None else str(error)
        audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()


__all__ = ["AUDIT_FILE", "MODEL_ID", "main", "resolve_request"]
