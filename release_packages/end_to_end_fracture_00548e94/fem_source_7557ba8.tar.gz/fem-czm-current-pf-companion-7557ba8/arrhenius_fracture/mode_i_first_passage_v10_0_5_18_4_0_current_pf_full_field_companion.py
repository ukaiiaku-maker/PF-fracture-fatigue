"""Full-field FEM/CZM companion for the current immutable PF kernel family."""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from .active_only_kernel_family_compat_v10051840 import (
    installed_active_only_kernel_family_compat,
)
from . import mode_i_first_passage_v10_0_5_18_4_0_theta0_pf_full_field_parity as _full
from . import mode_i_first_passage_v10_0_5_18_4_0_theta0_pf_parity as _control
from . import mode_i_first_passage_v10_0_5_13_barrier_only as _barrier
from .mode_i_first_passage_v10_0_5_18_4_0_current_pf_tip_only_companion import (
    CURRENT_KERNEL_SHA256,
    CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT,
    _persisted_refinement_payload,
)

MODEL_ID = "FEM_CZM_current_PF_1447653_full_field_companion_v1"
AUDIT_FILE = "current_pf_full_field_companion_contract_v1.json"


def main(argv: list[str] | None = None):
    args = list(sys.argv[1:] if argv is None else argv)
    out_raw = _control._option_value(args, "--out")
    family_raw = _control._option_value(args, "--signed-kernel-family")
    if out_raw is None or family_raw is None:
        raise SystemExit(f"{MODEL_ID} requires --out and --signed-kernel-family")
    out = Path(out_raw).expanduser().resolve()
    family = Path(family_raw).expanduser().resolve()
    if not family.is_file() or _control._sha256(family) != CURRENT_KERNEL_SHA256:
        raise SystemExit("current full-field companion kernel SHA-256 mismatch")
    family_payload = json.loads(family.read_text())
    if family_payload.get("mechanical_configuration_fingerprint") != (
        CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT
    ):
        raise SystemExit("current full-field companion mechanical configuration mismatch")
    out.mkdir(parents=True, exist_ok=True)
    historical = _control.REFERENCE_KERNEL_SHA256
    original_mesh_payload = _barrier._mesh_payload

    def mesh_payload_with_persisted_record(mesh, requested_radius_m):
        observed = original_mesh_payload(mesh, requested_radius_m)
        if observed.get("actual_radius_verified", False):
            return observed
        return _persisted_refinement_payload(out, requested_radius_m, observed)

    completed = False
    error = None
    try:
        _control.REFERENCE_KERNEL_SHA256 = CURRENT_KERNEL_SHA256
        _barrier._mesh_payload = mesh_payload_with_persisted_record
        with installed_active_only_kernel_family_compat(out):
            result = _full.main(args)
        completed = True
        return result
    except BaseException as exc:
        error = exc
        raise
    finally:
        _control.REFERENCE_KERNEL_SHA256 = historical
        _barrier._mesh_payload = original_mesh_payload
        payload = {
            "schema": MODEL_ID,
            "created_or_updated_utc": datetime.now(timezone.utc).isoformat(),
            "run_completed_without_exception": completed,
            "runtime_error_type": None if error is None else type(error).__name__,
            "runtime_error": None if error is None else str(error),
            "current_dependency": {
                "path": str(family),
                "sha256": _control._sha256(family) if family.is_file() else None,
                "mechanical_configuration_fingerprint": (
                    CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT
                ),
            },
            "historical_guard_preserved": {
                "kernel_sha256": historical,
                "runtime_restored": _control.REFERENCE_KERNEL_SHA256 == historical,
            },
            "bulk_model": _full.EXACT_BULK_MODEL,
            "bulk_state_semantics": "PF_v10_4_1_algebraic_mobile_density",
            "argv": args,
        }
        (out / AUDIT_FILE).write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n"
        )


if __name__ == "__main__":
    main()

