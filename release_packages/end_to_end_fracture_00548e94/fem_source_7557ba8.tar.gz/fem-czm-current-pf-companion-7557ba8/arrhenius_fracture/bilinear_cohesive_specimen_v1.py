"""Native cracked-body specimen for qualification of autonomous bilinear CZM.

This module is an opt-in qualification adapter.  It does not alter the
Arrhenius production driver or select a production material.  The specimen is
two plane-strain elastic halves with duplicated interface nodes, an initial
traction-free precrack, and native zero-thickness cohesive elements ahead of
the crack.  All mechanics use :mod:`arrhenius_fracture.fem` assembly.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.sparse.linalg import spsolve

from .cohesive import (
    AutonomousBilinearLaw, CohesiveElement, CohesiveNetwork,
    cohesive_element_diagnostics, update_autonomous_damage,
)
from .config import ElasticProperties
from .fem import (assemble_mechanics,in_plane_constitutive_state,plane_strain_D,
                  plane_stress_D,solve_dirichlet)
from .mesh import BoundaryData, rebuild_tri_mesh


MODEL_ID = "native-plane-strain-autonomous-bilinear-specimen-v1"


@dataclass
class BilinearSpecimenState:
    mesh: object
    boundary: BoundaryData
    material: ElasticProperties
    elasticity_D: np.ndarray
    displacement: np.ndarray
    ep_gp: np.ndarray
    rho_gp: np.ndarray
    damage: np.ndarray
    cohesive_network: CohesiveNetwork
    opening_m: float = 0.0
    step_index: int = 0
    qualification_material_id: str = ""
    plane_state: str = "plane_strain"
    eps_zz: float | None = 0.0
    sigma_zz_Pa: float | None = None


def _structured_half(width_m, half_height_m, nx, ny, *, upper, node_offset=0):
    xs=np.linspace(0.0,float(width_m),int(nx)+1)
    ys=(np.linspace(0.0,float(half_height_m),int(ny)+1) if upper
        else np.linspace(-float(half_height_m),0.0,int(ny)+1))
    nodes=np.asarray([(x,y) for y in ys for x in xs],float)
    elems=[]
    stride=int(nx)+1
    for j in range(int(ny)):
        for i in range(int(nx)):
            a=node_offset+j*stride+i; b=a+1; c=a+stride; d=c+1
            elems.extend(((a,b,d),(a,d,c)))
    return nodes,np.asarray(elems,int)


def build_specimen(*, width_m=40.0e-6, height_m=20.0e-6, nx=16,
                   ny_per_half=4, precrack_fraction=0.25,
                   material=None, law=None,
                   qualification_material_id="CONSTRUCTED_R05_BILINEAR_V1",
                   plane_state="plane_strain",eps_zz=None,sigma_zz_Pa=None):
    """Build a real duplicated-interface cracked body with native CZM edges."""
    if not (0.0 <= float(precrack_fraction) < 1.0):
        raise ValueError("precrack_fraction must be in [0,1)")
    if int(nx)<2 or int(ny_per_half)<1:
        raise ValueError("specimen requires nx>=2 and ny_per_half>=1")
    material=ElasticProperties() if material is None else material
    if plane_state not in {"plane_strain","plane_stress","generalized_plane_strain"}:
        raise ValueError("unsupported plane_state")
    if plane_state=="plane_strain":
        if sigma_zz_Pa is not None or eps_zz not in (None,0,0.0):
            raise ValueError("plane strain requires eps_zz=0")
        eps_zz=0.0
    elif plane_state=="plane_stress":
        if eps_zz is not None or sigma_zz_Pa not in (None,0,0.0):
            raise ValueError("plane stress requires free transverse strain")
        sigma_zz_Pa=0.0
    elif (eps_zz is None)==(sigma_zz_Pa is None):
        raise ValueError("generalized plane strain requires exactly one transverse control")
    law=(AutonomousBilinearLaw(5.0e18,2.0e9,20.0) if law is None else law)
    lower_nodes,lower_elems=_structured_half(
        width_m,height_m/2,nx,ny_per_half,upper=False,node_offset=0,
    )
    upper_offset=len(lower_nodes)
    upper_nodes,upper_elems=_structured_half(
        width_m,height_m/2,nx,ny_per_half,upper=True,node_offset=upper_offset,
    )
    nodes=np.vstack((lower_nodes,upper_nodes)); elems=np.vstack((lower_elems,upper_elems))
    mesh=rebuild_tri_mesh(nodes,elems)
    tol=max(width_m,height_m)*1.0e-12
    top=np.flatnonzero(np.abs(nodes[:,1]-height_m/2)<=tol)
    bottom=np.flatnonzero(np.abs(nodes[:,1]+height_m/2)<=tol)
    boundary=BoundaryData(
        top_nodes=top,bot_nodes=bottom,
        left_bot=int(bottom[np.argmin(nodes[bottom,0])]),
        right_bot=int(bottom[np.argmax(nodes[bottom,0])]),
        notch_nodes=np.asarray([],int),
    )
    lower_seam=np.flatnonzero(np.abs(lower_nodes[:,1])<=tol)
    upper_seam=upper_offset+np.flatnonzero(np.abs(upper_nodes[:,1])<=tol)
    lower_seam=lower_seam[np.argsort(nodes[lower_seam,0])]
    upper_seam=upper_seam[np.argsort(nodes[upper_seam,0])]
    precrack_end=float(precrack_fraction)*float(width_m)
    elements=[]
    for i in range(int(nx)):
        midpoint=.5*(nodes[lower_seam[i],0]+nodes[lower_seam[i+1],0])
        failed=midpoint<=precrack_end+tol
        elements.append(CohesiveElement(
            plus_nodes=(int(upper_seam[i]),int(upper_seam[i+1])),
            minus_nodes=(int(lower_seam[i]),int(lower_seam[i+1])),
            normal=np.asarray((0.,1.)),tangent=np.asarray((1.,0.)),
            length=float(nodes[lower_seam[i+1],0]-nodes[lower_seam[i],0]),
            damage=1.0 if failed else 0.0,
            status="committed" if failed else "active",front_id=0,event_index=i,
            barrier_kind="autonomous_bilinear",
            metadata={"qualification_only":True,"initial_precrack":bool(failed)},
        ))
    network=CohesiveNetwork(
        elements=elements,penalty_normal_Pa_per_m=law.normal_stiffness_Pa_per_m,
        penalty_tangent_Pa_per_m=law.normal_stiffness_Pa_per_m,
        constitutive_mode="autonomous_irreversible_bilinear",autonomous_law=law,
    )
    return BilinearSpecimenState(
        mesh,boundary,material,(plane_strain_D(material) if plane_state in {
            "plane_strain","generalized_plane_strain"
        } and sigma_zz_Pa is None else plane_stress_D(material)),np.zeros(mesh.ndof),
        np.zeros((3,mesh.ne)),np.zeros(mesh.ne),np.zeros(mesh.nn),network,
        qualification_material_id=str(qualification_material_id),plane_state=plane_state,
        eps_zz=None if eps_zz is None else float(eps_zz),
        sigma_zz_Pa=None if sigma_zz_Pa is None else float(sigma_zz_Pa),
    )


def _transverse_diagnostics(state):
    conn=state.mesh.elems
    edofs=np.column_stack((2*conn[:,0],2*conn[:,0]+1,2*conn[:,1],
                           2*conn[:,1]+1,2*conn[:,2],2*conn[:,2]+1))
    strain=np.einsum("eij,ej->ei",state.mesh.B_e,state.displacement[edofs])-state.ep_gp.T
    _sig,szz,ezz,_potential=in_plane_constitutive_state(
        strain,state.elasticity_D,state.material,plane_state=state.plane_state,
        eps_zz=state.eps_zz,sigma_zz_Pa=state.sigma_zz_Pa,
    )
    return {
        "transverse_control":("prescribed_sigma_zz" if state.sigma_zz_Pa is not None
                              and state.plane_state=="generalized_plane_strain"
                              else "free_transverse_resultant" if state.plane_state=="plane_stress"
                              else "prescribed_eps_zz"),
        "prescribed_eps_zz":state.eps_zz,
        "prescribed_sigma_zz_Pa":state.sigma_zz_Pa,
        "minimum_eps_zz":float(np.min(ezz)),"maximum_eps_zz":float(np.max(ezz)),
        "minimum_sigma_zz_Pa":float(np.min(szz)),
        "maximum_sigma_zz_Pa":float(np.max(szz)),
    }


def advance_opening(state: BilinearSpecimenState, opening_m: float, *,
                    damage_tolerance=1.0e-12, maximum_iterations=256):
    """Equilibrate one prescribed opening and commit autonomous CZM history."""
    target=float(opening_m)
    if target<0.0:
        raise ValueError("specimen opening must be nonnegative")
    reaction=0.0; increment=0.0
    for iteration in range(1,int(maximum_iterations)+1):
        K,R,*_=assemble_mechanics(
            state.mesh,state.displacement,state.ep_gp,state.rho_gp,state.damage,
            state.elasticity_D,state.material,cohesive_network=state.cohesive_network,
            plane_state=state.plane_state,eps_zz=state.eps_zz,
            sigma_zz_Pa=state.sigma_zz_Pa,
        )
        state.displacement,reaction=solve_dirichlet(
            K,R,state.displacement,state.boundary,target/2.0,-target/2.0,
        )
        increment=update_autonomous_damage(state.cohesive_network,state.displacement)
        if increment<=float(damage_tolerance):
            break
    else:
        raise RuntimeError("autonomous cohesive equilibrium did not converge")
    # Re-equilibrate once with the committed terminal history.
    K,R,*_=assemble_mechanics(
        state.mesh,state.displacement,state.ep_gp,state.rho_gp,state.damage,
        state.elasticity_D,state.material,cohesive_network=state.cohesive_network,
        plane_state=state.plane_state,eps_zz=state.eps_zz,
        sigma_zz_Pa=state.sigma_zz_Pa,
    )
    state.displacement,reaction=solve_dirichlet(
        K,R,state.displacement,state.boundary,target/2.0,-target/2.0,
    )
    state.opening_m=target; state.step_index+=1
    rows=[cohesive_element_diagnostics(e,state.displacement,state.cohesive_network)
          for e in state.cohesive_network.elements]
    result={
        "model_id":MODEL_ID,"step_index":state.step_index,"opening_m":target,
        "reaction_N_per_m":float(reaction),"iterations":iteration,
        "maximum_damage_increment":float(increment),
        "maximum_interface_opening_m":max(row["normal_jump_m"] for row in rows),
        "maximum_damage":max(row["damage"] for row in rows),
        "failed_element_count":state.cohesive_network.failed_count(),
        "active_element_count":state.cohesive_network.active_count(),
        "qualification_material_id":state.qualification_material_id,
        "plane_state":state.plane_state,
        "production_default":False,
    }
    result.update(_transverse_diagnostics(state))
    return result


def _solve_grip_vector(K,R,u,boundary,*,opening_m,shear_m):
    """Incremental solve with both grip components explicitly prescribed."""
    prescribed=np.zeros(len(u),dtype=bool); target=np.zeros(len(u),dtype=float)
    top=np.asarray(boundary.top_nodes,int); bottom=np.asarray(boundary.bot_nodes,int)
    for nodes,ux,uy in ((top,shear_m/2.0,opening_m/2.0),
                        (bottom,-shear_m/2.0,-opening_m/2.0)):
        prescribed[2*nodes]=True; prescribed[2*nodes+1]=True
        target[2*nodes]=ux; target[2*nodes+1]=uy
    free=~prescribed; csr=K.tocsr()
    delta=target[prescribed]-u[prescribed]
    rhs=-R[free]-csr[np.ix_(free,prescribed)]@delta
    result=np.asarray(u,float).copy()
    result[free]+=spsolve(csr[np.ix_(free,free)],rhs)
    result[prescribed]=target[prescribed]
    full=np.asarray(R)+csr@(result-np.asarray(u))
    return result,float(np.sum(full[2*top])),float(np.sum(full[2*top+1]))


def advance_mixed_grips(state: BilinearSpecimenState, *, opening_m: float,
                        shear_m: float, damage_tolerance=1.0e-12,
                        maximum_iterations=256):
    """Native cracked-body mode-I/mode-II grip step with normal CZM damage."""
    opening=float(opening_m); shear=float(shear_m)
    if opening<0.0:
        raise ValueError("specimen opening must be nonnegative")
    reaction_x=reaction_y=increment=0.0
    for iteration in range(1,int(maximum_iterations)+1):
        K,R,*_=assemble_mechanics(
            state.mesh,state.displacement,state.ep_gp,state.rho_gp,state.damage,
            state.elasticity_D,state.material,cohesive_network=state.cohesive_network,
            plane_state=state.plane_state,eps_zz=state.eps_zz,
            sigma_zz_Pa=state.sigma_zz_Pa,
        )
        state.displacement,reaction_x,reaction_y=_solve_grip_vector(
            K,R,state.displacement,state.boundary,opening_m=opening,shear_m=shear,
        )
        increment=update_autonomous_damage(state.cohesive_network,state.displacement)
        if increment<=float(damage_tolerance):
            break
    else:
        raise RuntimeError("mixed-mode cohesive equilibrium did not converge")
    K,R,*_=assemble_mechanics(
        state.mesh,state.displacement,state.ep_gp,state.rho_gp,state.damage,
        state.elasticity_D,state.material,cohesive_network=state.cohesive_network,
        plane_state=state.plane_state,eps_zz=state.eps_zz,
        sigma_zz_Pa=state.sigma_zz_Pa,
    )
    state.displacement,reaction_x,reaction_y=_solve_grip_vector(
        K,R,state.displacement,state.boundary,opening_m=opening,shear_m=shear,
    )
    state.opening_m=opening; state.step_index+=1
    rows=[cohesive_element_diagnostics(e,state.displacement,state.cohesive_network)
          for e in state.cohesive_network.elements]
    mode=("mode_I" if shear==0.0 else "mode_II" if opening==0.0 else "mixed_I_II")
    result={
        "model_id":MODEL_ID,"step_index":state.step_index,"in_plane_mode":mode,
        "opening_m":opening,"shear_m":shear,"reaction_x_N_per_m":reaction_x,
        "reaction_y_N_per_m":reaction_y,"iterations":iteration,
        "maximum_damage_increment":float(increment),
        "maximum_normal_jump_m":max(row["normal_jump_m"] for row in rows),
        "maximum_absolute_tangential_jump_m":max(abs(row["tangential_jump_m"]) for row in rows),
        "maximum_absolute_tangential_traction_Pa":max(abs(row["tangential_traction_Pa"]) for row in rows),
        "failed_element_count":state.cohesive_network.failed_count(),
        "plane_state":state.plane_state,"qualification_material_id":state.qualification_material_id,
        "production_default":False,
    }
    result.update(_transverse_diagnostics(state))
    return result


def state_dict(state: BilinearSpecimenState) -> dict:
    """JSON-safe active specimen checkpoint including cohesive history."""
    return {
        "schema":MODEL_ID+"/checkpoint-1","qualification_material_id":state.qualification_material_id,
        "nodes":state.mesh.nodes.tolist(),"elements":state.mesh.elems.tolist(),
        "boundary":{"top_nodes":state.boundary.top_nodes.tolist(),
                    "bot_nodes":state.boundary.bot_nodes.tolist(),
                    "left_bot":state.boundary.left_bot,"right_bot":state.boundary.right_bot,
                    "notch_nodes":state.boundary.notch_nodes.tolist()},
        "material":{"E":state.material.E,"nu":state.material.nu},
        "displacement":state.displacement.tolist(),"ep_gp":state.ep_gp.tolist(),
        "rho_gp":state.rho_gp.tolist(),"damage":state.damage.tolist(),
        "cohesive_network":state.cohesive_network.state_dict(),
        "opening_m":state.opening_m,"step_index":state.step_index,
        "plane_state":state.plane_state,
        "eps_zz":state.eps_zz,"sigma_zz_Pa":state.sigma_zz_Pa,
    }


def from_state_dict(payload: dict) -> BilinearSpecimenState:
    if payload.get("schema")!=MODEL_ID+"/checkpoint-1":
        raise ValueError("unsupported bilinear specimen checkpoint")
    mesh=rebuild_tri_mesh(np.asarray(payload["nodes"],float),np.asarray(payload["elements"],int))
    row=payload["boundary"]
    boundary=BoundaryData(np.asarray(row["top_nodes"],int),np.asarray(row["bot_nodes"],int),
                          int(row["left_bot"]),int(row["right_bot"]),np.asarray(row["notch_nodes"],int))
    material=ElasticProperties(E=float(payload["material"]["E"]),nu=float(payload["material"]["nu"]))
    plane_state=str(payload.get("plane_state","plane_strain"))
    eps_zz=payload.get("eps_zz",0.0 if plane_state=="plane_strain" else None)
    sigma_zz_Pa=payload.get("sigma_zz_Pa",0.0 if plane_state=="plane_stress" else None)
    elasticity=(plane_strain_D(material) if plane_state in {
        "plane_strain","generalized_plane_strain"
    } and sigma_zz_Pa is None else plane_stress_D(material))
    return BilinearSpecimenState(
        mesh,boundary,material,elasticity,np.asarray(payload["displacement"],float),
        np.asarray(payload["ep_gp"],float),np.asarray(payload["rho_gp"],float),
        np.asarray(payload["damage"],float),CohesiveNetwork.from_state_dict(payload["cohesive_network"]),
        float(payload["opening_m"]),int(payload["step_index"]),str(payload["qualification_material_id"]),
        plane_state,None if eps_zz is None else float(eps_zz),
        None if sigma_zz_Pa is None else float(sigma_zz_Pa),
    )


def write_checkpoint(state: BilinearSpecimenState, path: Path) -> str:
    encoded=(json.dumps(state_dict(state),sort_keys=True,separators=(",",":"))+"\n").encode()
    Path(path).write_bytes(encoded)
    return hashlib.sha256(encoded).hexdigest()


def read_checkpoint(path: Path) -> BilinearSpecimenState:
    return from_state_dict(json.loads(Path(path).read_text()))


__all__=["MODEL_ID","BilinearSpecimenState","advance_mixed_grips","advance_opening","build_specimen",
         "from_state_dict","read_checkpoint","state_dict","write_checkpoint"]
