"""Field-evaluated FEM reconciliation on the production path-envelope mesh.

This module keeps the v10.0.5.11 thermodynamic comparison but constructs each
mesh with the v10.0.5.18.3.4 path-envelope provider.  The controlled refinement
coordinate is the envelope support spacing, not the initial-tip grading value.
No kinetic state is advanced by this elastic benchmark.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Iterable

import numpy as np

from .config import ElasticProperties, GeometryConfig, MeshConfig
from .crystal import cubic_plane_strain_D
from .fixed_grip_elastic_audit_v10058 import (
    _J_rows_for_state,
    _solve_elastic_state,
)
from .fem import assemble_mechanics, elastic_energy_densities, solve_dirichlet
from .mesh import make_boundary_data, rebuild_tri_mesh
from .mode_i_first_passage_v9_18_5_3 import _compact_without_quality_abort
from .path_aware_growth_envelope_v10051834 import (
    _make_path_aware_mesh,
    _path_envelope_resolution,
    _reachable_envelope,
    _support_centers,
)
from .physical_refinement_mesh_v100510 import (
    clear_physical_refinement_v100510,
    configure_physical_refinement_v100510,
)
@dataclass(frozen=True)
class ReconciliationConfig:
    width_m: float = 2.0e-3
    height_m: float = 4.0e-3
    crack_m: float = 0.5e-3
    notch_half_thickness_m: float = 80.0e-6
    total_grip_opening_m: float = 0.2e-6
    nx: int = 24
    ny: int = 48
    tip_h_fine_m: float = 2.0e-6
    tip_ratio: float = 1.20
    physical_refinement_radius_m: float = 330.0e-6
    process_zone_m: float = 50.0e-6
    physical_event_m: float = 5.0e-6
    target_plus_guard_m: float = 15.0e-6
    energy_perturbation_m: float = 22.0e-6
    virtual_coordinate_perturbation_m: float = 50.0e-9
    minimum_global_forward: float = 0.05
    crystal_theta_deg: float = 17.5
    C11_Pa: float = 523.0e9
    C12_Pa: float = 203.0e9
    C44_Pa: float = 160.0e9
    kappa: float = 1.0e-6
    relative_tolerance: float = 0.02


def _relative_change(coarser: float, finer: float) -> float:
    return abs(float(finer) - float(coarser)) / max(abs(float(finer)), 1.0e-300)


def unequal_second_order_forward_release_rate(
    a0_m: float,
    a1_m: float,
    a2_m: float,
    U0_J_per_m: float,
    U1_J_per_m: float,
    U2_J_per_m: float,
) -> dict[str, float]:
    """Return ``-dU/da`` at the first of three unequal actual crack stations."""
    h1 = float(a1_m) - float(a0_m)
    h2 = float(a2_m) - float(a1_m)
    if h1 <= 0.0 or h2 <= 0.0:
        raise ValueError("actual crack stations must increase strictly")
    f0, f1, f2 = map(float, (U0_J_per_m, U1_J_per_m, U2_J_per_m))
    derivative = (
        -(2.0 * h1 + h2) * f0 / (h1 * (h1 + h2))
        + (h1 + h2) * f1 / (h1 * h2)
        - h1 * f2 / (h2 * (h1 + h2))
    )
    G_h = (f0 - f1) / h1
    G_span = (f0 - f2) / (h1 + h2)
    G = -derivative
    return {
        "left_forward_spacing_m": h1,
        "right_forward_spacing_m": h2,
        "station_spacing_asymmetry": abs(h1 - h2) / (0.5 * (h1 + h2)),
        "G_forward_first_interval_J_per_m2": G_h,
        "G_forward_full_span_J_per_m2": G_span,
        "G_second_order_forward_J_per_m2": G,
        "one_step_two_step_relative_difference": abs(G_h - G_span)
        / max(abs(G), 1.0e-300),
        "formula": "unequal_station_quadratic_forward_derivative_at_a0",
    }


def _field_norms(state: dict[str, Any], mesh: Any) -> dict[str, float]:
    area = np.asarray(mesh.area_e, dtype=float)
    sigma = np.asarray(state["sigma_gp"], dtype=float)
    return {
        "displacement_l2_dof_norm_m": float(np.linalg.norm(state["u"])),
        "stress_area_l2_Pa_sqrt_m2": float(
            math.sqrt(np.sum(np.sum(sigma * sigma, axis=0) * area))
        ),
        "stress_area_mean_Pa": float(
            np.sum(np.linalg.norm(sigma, axis=0) * area) / np.sum(area)
        ),
    }


def _damage_operation_measures(
    state: dict[str, Any], mesh: Any, half_thickness_m: float, kappa: float
) -> dict[str, float]:
    """Measure the actual nodal-band operation used by the stiffness solve."""
    d_gp = np.mean(np.asarray(state["d"], dtype=float)[mesh.elems], axis=1)
    area = np.asarray(mesh.area_e, dtype=float)
    damage_area = float(np.sum(d_gp * area))
    stiffness_loss = 1.0 - ((1.0 - d_gp) ** 2 + float(kappa))
    stiffness_loss_area = float(
        np.sum(stiffness_loss * area) / max(1.0 - float(kappa), 1.0e-300)
    )
    band_height = 2.0 * float(half_thickness_m)
    return {
        "nodal_damage_area_m2": damage_area,
        "stiffness_loss_area_m2": stiffness_loss_area,
        "nodal_damage_equivalent_length_m": damage_area / band_height,
        "stiffness_loss_equivalent_length_m": stiffness_loss_area / band_height,
    }


def _solve_with_prescribed_damage(
    mesh: Any,
    boundary: Any,
    material: ElasticProperties,
    D: np.ndarray,
    damage: np.ndarray,
    total_grip_opening_m: float,
    kappa: float,
) -> dict[str, float]:
    """Equilibrate one elastic mesh while retaining an exact nodal damage state."""
    u0 = np.zeros(mesh.ndof, dtype=float)
    ep_gp = np.zeros((3, mesh.ne), dtype=float)
    rho_gp = np.zeros(mesh.ne, dtype=float)
    Kmat, Rint, _, _, _, _ = assemble_mechanics(
        mesh, u0, ep_gp, rho_gp, damage, D, material, kappa=float(kappa)
    )
    u, reaction = solve_dirichlet(
        Kmat,
        Rint,
        u0,
        boundary,
        0.5 * float(total_grip_opening_m),
        -0.5 * float(total_grip_opening_m),
    )
    _, _, sigma_gp, _, _, _ = assemble_mechanics(
        mesh, u, ep_gp, rho_gp, damage, D, material, kappa=float(kappa)
    )
    stored, _ = elastic_energy_densities(mesh, u, ep_gp, sigma_gp, D)
    return {
        "stored_energy_J_per_m": float(np.sum(stored * mesh.area_e)),
        "reaction_N_per_unit_thickness": float(reaction),
    }


def _plateau_weight(nodes: np.ndarray, tip: np.ndarray, outer_m: float) -> np.ndarray:
    radius = np.linalg.norm(np.asarray(nodes, float) - tip[None, :], axis=1)
    inner = 0.25 * float(outer_m)
    q = np.zeros(len(radius), dtype=float)
    q[radius <= inner] = 1.0
    annulus = (radius > inner) & (radius < float(outer_m))
    q[annulus] = (float(outer_m) - radius[annulus]) / (float(outer_m) - inner)
    return q


def _virtual_extension_release(
    mesh: Any,
    boundary: Any,
    material: ElasticProperties,
    D: np.ndarray,
    base_state: dict[str, Any],
    total_grip_opening_m: float,
    kappa: float,
    outer_m: float,
    perturbation_m: float,
) -> dict[str, float]:
    """Differentiate energy under the same plateau virtual operation as J."""
    tip = np.asarray([base_state["effective_crack_m"], 0.0], dtype=float)
    q = _plateau_weight(mesh.nodes, tip, outer_m)
    energies: list[float] = []
    for sign in (-1.0, 1.0):
        nodes = np.asarray(mesh.nodes, float).copy()
        nodes[:, 0] += sign * float(perturbation_m) * q
        moved = rebuild_tri_mesh(nodes, mesh.elems, tip_centers=tip, validate=True)
        solved = _solve_with_prescribed_damage(
            moved,
            boundary,
            material,
            D,
            np.asarray(base_state["d"], dtype=float),
            total_grip_opening_m,
            kappa,
        )
        energies.append(float(solved["stored_energy_J_per_m"]))
    G = -(energies[1] - energies[0]) / (2.0 * float(perturbation_m))
    return {
        "outer_radius_m": float(outer_m),
        "coordinate_perturbation_m": float(perturbation_m),
        "minus_energy_J_per_m": energies[0],
        "plus_energy_J_per_m": energies[1],
        "G_virtual_extension_J_per_m2": float(G),
        "damage_state_held_fixed": True,
        "topology_held_fixed": True,
        "boundary_nodes_held_fixed": True,
    }


def evaluate_level(config: ReconciliationConfig, support_ratio: float) -> dict[str, Any]:
    geom = GeometryConfig(
        Lx=config.width_m,
        Ly=config.height_m,
        a0=config.crack_m,
        notch_half_thickness=config.notch_half_thickness_m,
    )
    mesh_cfg = MeshConfig(
        nx=config.nx,
        ny=config.ny,
        jitter=0.0,
        tip_h_fine=config.tip_h_fine_m,
        tip_ratio=config.tip_ratio,
    )
    directions, _, hull = _reachable_envelope(
        geom,
        config.target_plus_guard_m,
        config.minimum_global_forward,
        181,
    )
    centers = _support_centers(
        hull,
        directions,
        np.asarray([config.crack_m, 0.0]),
        config.target_plus_guard_m,
    )
    configure_physical_refinement_v100510(config.physical_refinement_radius_m)
    try:
        raw, construction = _make_path_aware_mesh(
            geom,
            mesh_cfg,
            hull,
            centers,
            config.process_zone_m,
            float(support_ratio),
            42,
        )
        mesh, quality = _compact_without_quality_abort(raw, centers)
    finally:
        clear_physical_refinement_v100510()
    resolution = _path_envelope_resolution(
        mesh, hull, config.physical_event_m, config.process_zone_m
    )
    material = ElasticProperties()
    D = cubic_plane_strain_D(
        config.C11_Pa,
        config.C12_Pa,
        config.C44_Pa,
        config.crystal_theta_deg,
    )
    boundary = make_boundary_data(mesh, geom)
    # Keep the thermodynamic perturbation independent of both tip grading and
    # event length.  Twenty-two micrometres is the recovered v10.0.5.11 actual
    # corridor-station spacing (500, 522, 544 um).
    stations = [
        config.crack_m + index * config.energy_perturbation_m
        for index in range(3)
    ]
    states = [
        _solve_elastic_state(
            mesh,
            boundary,
            material,
            D,
            crack_m=station,
            half_thickness_m=config.notch_half_thickness_m,
            total_grip_opening_m=config.total_grip_opening_m,
            kappa=config.kappa,
        )
        for station in stations
    ]
    release = unequal_second_order_forward_release_rate(
        *(state["effective_crack_m"] for state in states),
        *(state["U_el_density_J_per_m"] for state in states),
    )
    damage_measures = [
        _damage_operation_measures(
            state, mesh, config.notch_half_thickness_m, config.kappa
        )
        for state in states
    ]
    damage_release = unequal_second_order_forward_release_rate(
        *(row["nodal_damage_equivalent_length_m"] for row in damage_measures),
        *(state["U_el_density_J_per_m"] for state in states),
    )
    stiffness_release = unequal_second_order_forward_release_rate(
        *(row["stiffness_loss_equivalent_length_m"] for row in damage_measures),
        *(state["U_el_density_J_per_m"] for state in states),
    )
    contours = _J_rows_for_state(
        mesh,
        states[0],
        material,
        contour_outer_m=(180.0e-6, 240.0e-6, 300.0e-6),
        width_m=config.width_m,
        height_m=config.height_m,
        half_thickness_m=config.notch_half_thickness_m,
        tip_h_fine_m=float(construction["support_spacing_m"]),
    )
    virtual_rows = [
        _virtual_extension_release(
            mesh,
            boundary,
            material,
            D,
            states[0],
            config.total_grip_opening_m,
            config.kappa,
            outer,
            min(
                0.01 * construction["support_spacing_m"],
                config.virtual_coordinate_perturbation_m,
            ),
        )
        for outer in (180.0e-6, 240.0e-6, 300.0e-6)
    ]
    for contour, virtual in zip(contours, virtual_rows):
        virtual["native_J_J_per_m2"] = float(contour["J_full_J_per_m2"])
        virtual["native_J_over_virtual_G"] = float(
            contour["J_full_J_per_m2"]
            / virtual["G_virtual_extension_J_per_m2"]
        )
    J_values = [float(row["J_full_J_per_m2"]) for row in contours]
    G = float(release["G_second_order_forward_J_per_m2"])
    base = states[0]
    return {
        "support_h_over_L_pz": float(support_ratio),
        "support_spacing_m": float(construction["support_spacing_m"]),
        "node_count": int(mesh.nn),
        "triangle_count": int(mesh.ne),
        "minimum_triangle_quality": float(quality["minimum_initial_triangle_quality"]),
        "maximum_sampled_hbar_m": float(resolution["maximum_sampled_hbar_tip_m"]),
        "maximum_sampled_hbar_over_L_pz": float(
            resolution["maximum_sampled_hbar_tip_over_L_pz"]
        ),
        "effective_crack_stations_m": [
            float(state["effective_crack_m"]) for state in states
        ],
        "damage_operation_measures": damage_measures,
        "top_reaction_N_per_unit_thickness": float(
            base["Ftop_N_per_thickness"]
        ),
        "stored_energy_J_per_m": float(base["U_el_density_J_per_m"]),
        "matrix_energy_J_per_m": float(base["U_el_matrix_J_per_m"]),
        "energy_closure_relative_error": float(
            base["energy_closure_relative_error"]
        ),
        "fixed_grip_G_J_per_m2": G,
        "damage_area_normalized_G_J_per_m2": float(
            damage_release["G_second_order_forward_J_per_m2"]
        ),
        "stiffness_loss_area_normalized_G_J_per_m2": float(
            stiffness_release["G_second_order_forward_J_per_m2"]
        ),
        "forward_derivative_relative_error": float(
            release["one_step_two_step_relative_difference"]
        ),
        "native_full_energy_J_contours": contours,
        "matched_virtual_extension_energy_contours": virtual_rows,
        "native_full_energy_J_median_J_per_m2": float(np.median(J_values)),
        "native_J_over_fixed_grip_G": float(np.median(J_values) / G),
        "independent_primary_observer": "same_mesh_fixed_grip_energy_derivative",
        "field_norms": _field_norms(base, mesh),
    }


def run_reconciliation(
    support_ratios: Iterable[float] = (0.245, 0.18, 0.12),
    config: ReconciliationConfig = ReconciliationConfig(),
) -> dict[str, Any]:
    ratios = [float(value) for value in support_ratios]
    if len(ratios) != 3 or not all(
        finer < coarser for coarser, finer in zip(ratios, ratios[1:])
    ):
        raise ValueError("three strictly decreasing support ratios are required")
    levels = [evaluate_level(config, ratio) for ratio in ratios]
    for level in levels:
        outer = level["matched_virtual_extension_energy_contours"][-1]
        level["matched_outer_virtual_G_J_per_m2"] = float(
            outer["G_virtual_extension_J_per_m2"]
        )
        level["matched_outer_J_over_virtual_G"] = float(
            outer["native_J_over_virtual_G"]
        )
    metrics = (
        "top_reaction_N_per_unit_thickness",
        "stored_energy_J_per_m",
        "fixed_grip_G_J_per_m2",
        "native_full_energy_J_median_J_per_m2",
        "matched_outer_virtual_G_J_per_m2",
    )
    changes = {
        metric: {
            "coarse_to_medium": _relative_change(
                levels[0][metric], levels[1][metric]
            ),
            "medium_to_fine": _relative_change(
                levels[1][metric], levels[2][metric]
            ),
        }
        for metric in metrics
    }
    maximum = max(row["medium_to_fine"] for row in changes.values())
    maximum_parity_error = max(
        abs(level["matched_outer_J_over_virtual_G"] - 1.0) for level in levels
    )
    passed = bool(
        maximum <= config.relative_tolerance
        and maximum_parity_error <= config.relative_tolerance
    )
    return {
        "schema": "fem-baseline-reconciliation-v1",
        "status": "PASS_SUPPORT_AND_MATCHED_OPERATION" if passed else "FAIL",
        "physics_advanced": False,
        "mesh_provider": (
            "v10.0.5.18.3.4 path-aware physical reachable-envelope provider"
        ),
        "refinement_axis": "path-envelope support spacing",
        "common_observer_is_field_independent": True,
        "algebraic_K_squared_over_Eprime_used_as_validation": False,
        "observer_correspondence": {
            "projected_max_x_damage_band_derivative_matches_J_operation": False,
            "projected_max_x_role": (
                "finite nodal-band growth diagnostic; actual stiffness-loss area "
                "is not proportional to maximum damaged-node x on this mesh"
            ),
            "matched_operation": (
                "centered total stored-energy derivative under the identical "
                "plateau virtual material-coordinate extension used by J"
            ),
            "matched_outer_radius_m": 300.0e-6,
            "maximum_J_over_virtual_G_relative_error": maximum_parity_error,
            "relative_tolerance": config.relative_tolerance,
            "passed": maximum_parity_error <= config.relative_tolerance,
        },
        "config": asdict(config),
        "levels": levels,
        "relative_changes": changes,
        "maximum_medium_to_fine_relative_change": maximum,
    }


__all__ = [
    "ReconciliationConfig",
    "evaluate_level",
    "run_reconciliation",
    "unequal_second_order_forward_release_rate",
]
