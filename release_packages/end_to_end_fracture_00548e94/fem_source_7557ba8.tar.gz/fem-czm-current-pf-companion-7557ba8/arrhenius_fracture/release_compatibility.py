"""Semantic compatibility checks for retained point-release entry paths.

The package version identifies the current assembled code. Historical native
entry points remain supported when they share the same 10.0.5.18 family and
their numeric point release does not postdate the assembled package.
"""
from __future__ import annotations

import re


CURRENT_RELEASE = "10.0.5.18.4.0"
FAMILY_PREFIX = (10, 0, 5, 18)


def numeric_release(value: str) -> tuple[int, ...]:
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)*", str(value)):
        raise ValueError(f"release must be dot-separated nonnegative integers: {value!r}")
    return tuple(int(part) for part in str(value).split("."))


def supports_historical_entry(package_release: str, entry_release: str) -> bool:
    package = numeric_release(package_release)
    entry = numeric_release(entry_release)
    if package[:4] != FAMILY_PREFIX or entry[:4] != FAMILY_PREFIX:
        return False
    width = max(len(package), len(entry))
    return package + (0,) * (width - len(package)) >= entry + (0,) * (width - len(entry))


__all__ = ["CURRENT_RELEASE", "FAMILY_PREFIX", "numeric_release", "supports_historical_entry"]
