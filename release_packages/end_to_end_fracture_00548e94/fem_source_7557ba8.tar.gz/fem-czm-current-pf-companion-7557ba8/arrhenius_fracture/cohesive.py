"""Arrhenius cohesive-interface support for sharp-front and kinetic-CZM modes.

Cohesive interfaces remain a mechanical representation of Arrhenius cleavage
progress.  No critical traction, opening, fracture energy, or second failure
criterion is evaluated here.  The v10 kinetic mode may create a trial interface
with ``damage=B``; the legacy modes retain abrupt ``damage=1`` insertion.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np
from scipy import sparse

EV_J = 1.602176634e-19
KB_EV_PER_K = 8.617333262145e-5


@dataclass(frozen=True)
class BilinearPotentialLaw:
    """Finite-support potential consumed directly by interface assembly.

    This is opt-in.  The historical penalty/degradation law remains the
    network default and therefore retains its prior identity.
    """
    peak_traction_Pa: float
    separation_work_J_m2: float
    peak_fraction: float = 0.25

    def __post_init__(self) -> None:
        if self.peak_traction_Pa <= 0.0 or self.separation_work_J_m2 <= 0.0:
            raise ValueError("cohesive peak and work must be positive")
        if not 0.0 < self.peak_fraction < 1.0:
            raise ValueError("peak_fraction must be strictly between zero and one")

    @property
    def support_end_m(self) -> float:
        return 2.0 * self.separation_work_J_m2 / self.peak_traction_Pa

    @property
    def peak_opening_m(self) -> float:
        return self.peak_fraction * self.support_end_m

    def response(self, opening_m: float) -> tuple[float, float, float]:
        """Return traction [Pa], consistent tangent [Pa/m], work [J/m2]."""
        d = max(float(opening_m), 0.0)
        dp, df, tc = self.peak_opening_m, self.support_end_m, self.peak_traction_Pa
        if d <= dp:
            return tc*d/dp, tc/dp, 0.5*tc*d*d/dp
        if d <= df:
            traction = tc*(df-d)/(df-dp)
            work = 0.5*tc*dp + tc*(df*(d-dp)-0.5*(d*d-dp*dp))/(df-dp)
            return traction, -tc/(df-dp), work
        return 0.0, 0.0, self.separation_work_J_m2


@dataclass(frozen=True)
class AutonomousBilinearLaw:
    """Conventional irreversible opening-only bilinear cohesive law."""

    normal_stiffness_Pa_per_m: float
    peak_traction_Pa: float
    separation_work_J_m2: float

    def __post_init__(self) -> None:
        if min(self.normal_stiffness_Pa_per_m, self.peak_traction_Pa,
               self.separation_work_J_m2) <= 0.0:
            raise ValueError("bilinear stiffness, peak and work must be positive")
        if not self.peak_opening_m < self.final_opening_m:
            raise ValueError("bilinear law requires peak opening below final opening")

    @property
    def peak_opening_m(self) -> float:
        return self.peak_traction_Pa / self.normal_stiffness_Pa_per_m

    @property
    def final_opening_m(self) -> float:
        return 2.0 * self.separation_work_J_m2 / self.peak_traction_Pa

    def damage_at_history(self, maximum_tensile_opening_m: float) -> float:
        kappa = max(float(maximum_tensile_opening_m), 0.0)
        dp, df = self.peak_opening_m, self.final_opening_m
        if kappa <= dp:
            return 0.0
        if kappa >= df:
            return 1.0
        return float(df * (kappa - dp) / (kappa * (df - dp)))

    def response(self, opening_m: float, maximum_tensile_opening_m: float):
        opening = max(float(opening_m), 0.0)
        damage = self.damage_at_history(maximum_tensile_opening_m)
        traction = (1.0 - damage) * self.normal_stiffness_Pa_per_m * opening
        tangent = (1.0 - damage) * self.normal_stiffness_Pa_per_m
        return traction, tangent, damage


@dataclass(frozen=True)
class ActivatedBilinearBarrier:
    """Fitted bilinear activation barrier; independent of autonomous damage."""

    B0_A_times_Gamma_eV: float
    peak_traction_Pa: float
    attempt_frequency_s: float

    def __post_init__(self) -> None:
        if min(self.B0_A_times_Gamma_eV, self.peak_traction_Pa,
               self.attempt_frequency_s) <= 0.0:
            raise ValueError("activated bilinear parameters must be positive")

    def barrier_eV(self, tensile_traction_Pa: float) -> float:
        q = max(float(tensile_traction_Pa), 0.0)
        if q >= self.peak_traction_Pa:
            return 0.0
        return self.B0_A_times_Gamma_eV * (1.0 - q / self.peak_traction_Pa) ** 2

    def rate_s(self, tensile_traction_Pa: float, temperature_K: float) -> float:
        if float(temperature_K) <= 0.0:
            raise ValueError("temperature must be positive")
        if float(tensile_traction_Pa) >= self.peak_traction_Pa:
            return float("inf")
        return self.attempt_frequency_s * np.exp(
            -self.barrier_eV(tensile_traction_Pa)
            / (KB_EV_PER_K * float(temperature_K))
        )


@dataclass
class CohesiveElement:
    """Zero-thickness two-node line interface controlled by an Arrhenius clock."""

    plus_nodes: tuple[int, int]
    minus_nodes: tuple[int, int]
    normal: np.ndarray
    tangent: np.ndarray
    length: float
    damage: float = 1.0
    clock: float = 0.0
    status: str = "committed"
    front_id: int = -1
    event_index: int = 0
    barrier_kind: str = "exp_floor"
    metadata: dict = field(default_factory=dict)
    maximum_tensile_opening_m: float = 0.0

    def __post_init__(self) -> None:
        self.normal = np.asarray(self.normal, dtype=float)
        self.tangent = np.asarray(self.tangent, dtype=float)
        nrm = float(np.linalg.norm(self.normal))
        trm = float(np.linalg.norm(self.tangent))
        if nrm <= 0.0 or trm <= 0.0:
            raise ValueError("cohesive normal/tangent must be non-zero")
        self.normal /= nrm
        self.tangent /= trm
        self.damage = float(np.clip(self.damage, 0.0, 1.0))
        self.clock = float(np.clip(self.clock, 0.0, 1.0))
        self.length = float(max(self.length, 0.0))
        self.status = str(self.status)
        self.maximum_tensile_opening_m = max(
            float(self.maximum_tensile_opening_m), 0.0
        )

    @property
    def nodes4(self) -> tuple[int, int, int, int]:
        return (*self.plus_nodes, *self.minus_nodes)

    def set_clock_damage(self, B: float, coupling: str = "clock_linear") -> None:
        q = float(np.clip(B, 0.0, 1.0))
        if q + 1.0e-14 < self.clock:
            raise ValueError("trial cohesive clock/damage must be monotonic")
        mode = str(coupling).strip().lower()
        if mode == "clock_linear":
            damage = q
        elif mode == "abrupt":
            damage = 1.0 if q >= 1.0 - 1.0e-12 else 0.0
        else:
            raise ValueError("cohesive opening coupling must be abrupt or clock_linear")
        self.clock = q
        self.damage = float(np.clip(damage, self.damage, 1.0))
        self.status = "committed" if self.damage >= 1.0 - 1.0e-12 else "trial"


@dataclass
class CohesiveNetwork:
    """Collection of Arrhenius-controlled cohesive interfaces."""

    elements: List[CohesiveElement] = field(default_factory=list)
    penalty_normal_Pa_per_m: float = 1.0e18
    penalty_tangent_Pa_per_m: float = 1.0e18
    compression_penalty_factor: float = 1.0
    constitutive_mode: str = "legacy_penalty_degradation"
    potential_law: Optional[BilinearPotentialLaw] = None
    autonomous_law: Optional[AutonomousBilinearLaw] = None
    activated_barrier: Optional[ActivatedBilinearBarrier] = None
    kinetic_time_unit: str = "s"

    def __post_init__(self) -> None:
        if self.constitutive_mode not in {
            "legacy_penalty_degradation", "reversible_bilinear_potential",
            "autonomous_irreversible_bilinear", "activated_bilinear",
        }:
            raise ValueError("unknown cohesive constitutive_mode")
        if self.constitutive_mode == "reversible_bilinear_potential" and self.potential_law is None:
            raise ValueError("potential mode requires potential_law")
        if self.constitutive_mode == "autonomous_irreversible_bilinear" and self.autonomous_law is None:
            raise ValueError("autonomous mode requires autonomous_law")
        if self.constitutive_mode == "activated_bilinear" and self.activated_barrier is None:
            raise ValueError("activated mode requires activated_barrier")
        if self.kinetic_time_unit != "s":
            raise ValueError("native Arrhenius cohesive clocks use seconds")

    def add(self, elem: CohesiveElement) -> None:
        self.elements.append(elem)

    def active_count(self) -> int:
        return sum(1 for e in self.elements if e.damage < 1.0 - 1e-14)

    def failed_count(self) -> int:
        return sum(1 for e in self.elements if e.damage >= 1.0 - 1e-14)

    def to_rows(self) -> np.ndarray:
        rows = []
        for i, e in enumerate(self.elements):
            rows.append([
                i, e.front_id, e.event_index,
                e.plus_nodes[0], e.plus_nodes[1],
                e.minus_nodes[0], e.minus_nodes[1],
                e.length, e.damage, e.clock,
                e.tangent[0], e.tangent[1],
                e.normal[0], e.normal[1],
            ])
        return np.asarray(rows, dtype=float) if rows else np.zeros((0, 14), dtype=float)

    def state_dict(self) -> dict:
        """JSON-safe constitutive and irreversible state for native restart."""
        return {
            "schema": "cohesive-network-state/1",
            "penalty_normal_Pa_per_m": self.penalty_normal_Pa_per_m,
            "penalty_tangent_Pa_per_m": self.penalty_tangent_Pa_per_m,
            "compression_penalty_factor": self.compression_penalty_factor,
            "constitutive_mode": self.constitutive_mode,
            "kinetic_time_unit": self.kinetic_time_unit,
            "potential_law": None if self.potential_law is None else {
                "peak_traction_Pa": self.potential_law.peak_traction_Pa,
                "separation_work_J_m2": self.potential_law.separation_work_J_m2,
                "peak_fraction": self.potential_law.peak_fraction,
            },
            "autonomous_law": None if self.autonomous_law is None else {
                "normal_stiffness_Pa_per_m": self.autonomous_law.normal_stiffness_Pa_per_m,
                "peak_traction_Pa": self.autonomous_law.peak_traction_Pa,
                "separation_work_J_m2": self.autonomous_law.separation_work_J_m2,
            },
            "activated_barrier": None if self.activated_barrier is None else {
                "B0_A_times_Gamma_eV": self.activated_barrier.B0_A_times_Gamma_eV,
                "peak_traction_Pa": self.activated_barrier.peak_traction_Pa,
                "attempt_frequency_s": self.activated_barrier.attempt_frequency_s,
            },
            "elements": [{
                "plus_nodes": list(element.plus_nodes),
                "minus_nodes": list(element.minus_nodes),
                "normal": element.normal.tolist(),
                "tangent": element.tangent.tolist(),
                "length": element.length,
                "damage": element.damage,
                "clock": element.clock,
                "status": element.status,
                "front_id": element.front_id,
                "event_index": element.event_index,
                "barrier_kind": element.barrier_kind,
                "metadata": element.metadata,
                "maximum_tensile_opening_m": element.maximum_tensile_opening_m,
            } for element in self.elements],
        }

    @classmethod
    def from_state_dict(cls, payload: dict) -> "CohesiveNetwork":
        if payload.get("schema") != "cohesive-network-state/1":
            raise ValueError("unsupported cohesive-network restart schema")
        potential = payload.get("potential_law")
        autonomous = payload.get("autonomous_law")
        activated = payload.get("activated_barrier")
        elements = [CohesiveElement(
            plus_nodes=tuple(row["plus_nodes"]),
            minus_nodes=tuple(row["minus_nodes"]),
            normal=np.asarray(row["normal"], dtype=float),
            tangent=np.asarray(row["tangent"], dtype=float),
            length=row["length"], damage=row["damage"], clock=row["clock"],
            status=row["status"], front_id=row["front_id"],
            event_index=row["event_index"], barrier_kind=row["barrier_kind"],
            metadata=dict(row.get("metadata", {})),
            maximum_tensile_opening_m=row.get("maximum_tensile_opening_m", 0.0),
        ) for row in payload["elements"]]
        return cls(
            elements=elements,
            penalty_normal_Pa_per_m=payload["penalty_normal_Pa_per_m"],
            penalty_tangent_Pa_per_m=payload["penalty_tangent_Pa_per_m"],
            compression_penalty_factor=payload["compression_penalty_factor"],
            constitutive_mode=payload["constitutive_mode"],
            potential_law=None if potential is None else BilinearPotentialLaw(**potential),
            autonomous_law=None if autonomous is None else AutonomousBilinearLaw(**autonomous),
            activated_barrier=None if activated is None else ActivatedBilinearBarrier(**activated),
            kinetic_time_unit=payload["kinetic_time_unit"],
        )


def update_autonomous_damage(
    network: CohesiveNetwork, u: np.ndarray
) -> float:
    """Commit the maximum-opening history before residual/tangent assembly."""
    if network.constitutive_mode != "autonomous_irreversible_bilinear":
        return 0.0
    maximum_increment = 0.0
    A = _jump_operator()
    for elem in network.elements:
        nodes = np.asarray(elem.nodes4, dtype=int)
        edofs = np.empty(8, dtype=int)
        edofs[0::2] = 2 * nodes
        edofs[1::2] = 2 * nodes + 1
        opening = max(float(elem.normal @ (A @ np.asarray(u)[edofs])), 0.0)
        old_damage = elem.damage
        elem.maximum_tensile_opening_m = max(
            elem.maximum_tensile_opening_m, opening
        )
        elem.damage = max(
            elem.damage,
            network.autonomous_law.damage_at_history(
                elem.maximum_tensile_opening_m
            ),
        )
        elem.status = "committed" if elem.damage >= 1.0 - 1.0e-12 else "active"
        maximum_increment = max(maximum_increment, elem.damage - old_damage)
    return maximum_increment


def _jump_operator() -> np.ndarray:
    """Map 8 interface dofs to midpoint displacement jump [ux, uy]."""
    A = np.zeros((2, 8), dtype=float)
    A[0, 0] = 0.5; A[1, 1] = 0.5
    A[0, 2] = 0.5; A[1, 3] = 0.5
    A[0, 4] = -0.5; A[1, 5] = -0.5
    A[0, 6] = -0.5; A[1, 7] = -0.5
    return A


def cohesive_element_diagnostics(
    elem: CohesiveElement,
    u: np.ndarray,
    network: CohesiveNetwork,
) -> dict[str, float | str]:
    A = _jump_operator()
    p0, p1 = elem.plus_nodes
    m0, m1 = elem.minus_nodes
    nodes = np.array([p0, p1, m0, m1], dtype=int)
    edofs = np.empty(8, dtype=int)
    edofs[0::2] = 2 * nodes
    edofs[1::2] = 2 * nodes + 1
    jump = A @ np.asarray(u, dtype=float)[edofs]
    dn = float(elem.normal @ jump)
    dt = float(elem.tangent @ jump)
    intact = max(1.0 - float(elem.damage), 0.0)
    kn = float(network.penalty_normal_Pa_per_m)
    kt = float(network.penalty_tangent_Pa_per_m)
    if dn >= 0.0 and network.constitutive_mode == "autonomous_irreversible_bilinear":
        tn, kn_eff, _ = network.autonomous_law.response(
            dn, elem.maximum_tensile_opening_m
        )
        work0 = 0.5 * network.autonomous_law.normal_stiffness_Pa_per_m * dn * dn
    elif dn >= 0.0 and network.constitutive_mode == "reversible_bilinear_potential":
        tn0, _, work0 = network.potential_law.response(dn)
        kn_eff = 0.0
        tn = intact * tn0
    else:
        kn_eff = kn * (max(float(network.compression_penalty_factor), 0.0) if dn < 0.0 else intact)
        tn = kn_eff * dn
        work0 = 0.5 * kn_eff * dn * dn
    kt_eff = kt * intact
    tt = kt_eff * dt
    return {
        "normal_jump_m": dn,
        "tangential_jump_m": dt,
        "normal_traction_Pa": tn,
        "tangential_traction_Pa": tt,
        "damage": float(elem.damage),
        "clock": float(elem.clock),
        "status": str(elem.status),
        "normal_work_J_m2": intact * work0,
        "constitutive_mode": network.constitutive_mode,
        "kinetic_time_unit": network.kinetic_time_unit,
    }


def cohesive_contribution(
    network: Optional[CohesiveNetwork],
    u: np.ndarray,
    ndof: int,
) -> tuple[sparse.csr_matrix, np.ndarray]:
    """Assemble cohesive tangent and internal force with unilateral contact."""
    if network is None or not network.elements:
        return sparse.csr_matrix((ndof, ndof)), np.zeros(ndof)

    A = _jump_operator()
    rows = []
    cols = []
    vals = []
    R = np.zeros(ndof, dtype=float)

    kn = float(network.penalty_normal_Pa_per_m)
    kt = float(network.penalty_tangent_Pa_per_m)
    kc_factor = float(max(network.compression_penalty_factor, 0.0))

    for elem in network.elements:
        p0, p1 = elem.plus_nodes
        m0, m1 = elem.minus_nodes
        nodes = np.array([p0, p1, m0, m1], dtype=int)
        edofs = np.empty(8, dtype=int)
        edofs[0::2] = 2 * nodes
        edofs[1::2] = 2 * nodes + 1
        ue = u[edofs]
        jump = A @ ue

        n = elem.normal
        t = elem.tangent
        dn = float(n @ jump)
        dtt = float(t @ jump)
        intact = max(1.0 - float(elem.damage), 0.0)
        autonomous_mode = (
            dn >= 0.0
            and network.constitutive_mode == "autonomous_irreversible_bilinear"
        )
        potential_mode = (
            dn >= 0.0
            and network.constitutive_mode == "reversible_bilinear_potential"
        )
        if autonomous_mode:
            tn, kn_eff, _ = network.autonomous_law.response(
                dn, elem.maximum_tensile_opening_m
            )
            work0 = 0.5 * network.autonomous_law.normal_stiffness_Pa_per_m * dn * dn
        elif potential_mode:
            tn0, tangent0, work0 = network.potential_law.response(dn)
            kn_eff = intact * tangent0
            tn = intact * tn0
        else:
            kn_eff = kn * (kc_factor if dn < 0.0 else intact)
            tn = kn_eff * dn
            work0 = 0.5 * kn_eff * dn * dn
        kt_eff = kt * intact
        Kglob = kn_eff * np.outer(n, n) + kt_eff * np.outer(t, t)

        L = max(float(elem.length), 0.0)
        Ke = A.T @ Kglob @ A * L
        traction = tn * n + kt_eff * dtt * t
        Re = A.T @ traction * L
        np.add.at(R, edofs, Re)

        elem.metadata.update({
            "normal_jump_m": dn,
            "tangential_jump_m": dtt,
            "normal_traction_Pa": tn,
            "tangential_traction_Pa": kt_eff * dtt,
            "damage": float(elem.damage),
            "clock": float(elem.clock),
            "status": str(elem.status),
            "normal_work_J_m2": intact * work0,
            "constitutive_mode": network.constitutive_mode,
            "kinetic_time_unit": network.kinetic_time_unit,
        })

        ii = np.repeat(edofs[:, None], 8, axis=1)
        jj = np.repeat(edofs[None, :], 8, axis=0)
        rows.append(ii.ravel()); cols.append(jj.ravel()); vals.append(Ke.ravel())

    if not rows:
        return sparse.csr_matrix((ndof, ndof)), R
    rr = np.concatenate(rows); cc = np.concatenate(cols); vv = np.concatenate(vals)
    K = sparse.csr_matrix((vv, (rr, cc)), shape=(ndof, ndof))
    return K, R


__all__ = [
    "ActivatedBilinearBarrier", "AutonomousBilinearLaw", "BilinearPotentialLaw",
    "CohesiveElement",
    "CohesiveNetwork",
    "cohesive_element_diagnostics",
    "cohesive_contribution", "update_autonomous_damage",
]
