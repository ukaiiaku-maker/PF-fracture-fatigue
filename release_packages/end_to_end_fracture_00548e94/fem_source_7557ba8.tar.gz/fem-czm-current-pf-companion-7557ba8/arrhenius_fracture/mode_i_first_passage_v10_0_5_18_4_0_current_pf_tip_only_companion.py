"""Tip-only FEM/CZM companion for the current immutable PF kernel family.

This entry leaves the historical theta-zero parity guard unchanged.  It swaps
that guard transactionally for the current kernel, applies the already-audited
empty-wake compatibility adapter, and otherwise executes the native tip-only
theta-zero FEM/CZM stack without the full-field overlay.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

from . import mode_i_first_passage_v10_0_5_18_4_0_theta0_pf_parity as _tip_only
from .active_only_kernel_family_compat_v10051840 import (
    installed_active_only_kernel_family_compat,
)
from . import mode_i_first_passage_v10_0_5_13_barrier_only as _barrier


MODEL_ID = "FEM_CZM_current_PF_1447653_tip_only_companion_v1"
AUDIT_FILE = "current_pf_tip_only_companion_contract_v1.json"
CURRENT_KERNEL_SHA256 = "d41b08f69ae773009f65f4c0094ef5436ba7f0f290a94172e5b894d09a41f7c3"
CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT = (
    "1447653d199f0b43cb475951092d69444c9b785f6fdf518c723792abb3b1f5e5"
)
HISTORICAL_KERNEL_SHA256 = _tip_only.REFERENCE_KERNEL_SHA256


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _contract(argv, family, *, completed, error):
    return {
        "schema": MODEL_ID,
        "created_or_updated_utc": _utc_now(),
        "run_completed_without_exception": bool(completed),
        "runtime_error_type": None if error is None else type(error).__name__,
        "runtime_error": None if error is None else str(error),
        "entry": __name__,
        "native_full_order_builder": _tip_only._base.MODEL_ID,
        "current_dependency": {
            "path": str(family),
            "sha256": _tip_only._sha256(family),
            "mechanical_configuration_fingerprint": (
                CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT
            ),
        },
        "historical_guard_preserved": {
            "kernel_sha256": HISTORICAL_KERNEL_SHA256,
            "modified": False,
        },
        "qualification": (
            "current-input native tip-only FEM/CZM companion; no full-field overlay"
        ),
        "continuum_accommodation": "elastic bulk with moving tip MPZ only",
        "hazard_mode": "exponential",
        "event_length_mode": "threshold_scaled",
        "crack_backend": "adaptive_czm_atomic_path_corridor",
        "argv": list(argv),
    }


def _persisted_refinement_payload(
    out: Path, requested_radius_m: float, fallback: dict
) -> dict:
    """Recover audit metadata from the solver's actual compact-mesh record."""
    path = out / "compact_corridor_mesh_v91852.json"
    if not path.is_file():
        return fallback
    payload = json.loads(path.read_text())
    actual = payload.get("production_refinement_radius_m")
    preserved = bool(payload.get("physical_refinement_metadata_preserved", False))
    provider_verified = bool(
        payload.get("production_physical_provider_detected", False)
        and payload.get("path_aware_physical_refinement_active", False)
        and payload.get("path_aware_physical_refinement_policy")
        == "global_forward_reachable_envelope_process_zone_support_with_initial_tip_grading"
    )
    if actual is None or not preserved or not provider_verified or not math.isclose(
        float(actual), float(requested_radius_m), rel_tol=1.0e-12, abs_tol=1.0e-15
    ):
        return fallback
    recovered = dict(fallback)
    recovered.update({
        "actual_radius_m": float(actual),
        "actual_radius_um": float(actual) * 1.0e6,
        "policy": payload.get("path_aware_physical_refinement_policy"),
        "actual_radius_verified": True,
        "metadata_fallback_reason": "verified_persisted_compact_corridor_mesh",
        "persisted_mesh_record": str(path),
        "persisted_node_count": int(payload["node_count"]),
        "persisted_hbar_tip_m": float(payload["initial_hbar_tip_m"]),
        "persisted_provider_verified": True,
    })
    return recovered


def main(argv: list[str] | None = None):
    args = list(sys.argv[1:] if argv is None else argv)
    out_raw = _tip_only._option_value(args, "--out")
    family_raw = _tip_only._option_value(args, "--signed-kernel-family")
    if out_raw is None or family_raw is None:
        raise SystemExit(f"{MODEL_ID} requires --out and --signed-kernel-family")
    out = Path(out_raw).expanduser().resolve()
    family = Path(family_raw).expanduser().resolve()
    if not family.is_file():
        raise SystemExit(f"current companion kernel is missing: {family}")
    if _tip_only._sha256(family) != CURRENT_KERNEL_SHA256:
        raise SystemExit("current tip-only companion kernel SHA-256 mismatch")
    payload = json.loads(family.read_text())
    observed = payload.get("mechanical_configuration_fingerprint")
    if observed != CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT:
        raise SystemExit(
            "current tip-only companion mechanical configuration mismatch: "
            f"observed {observed!r}"
        )

    out.mkdir(parents=True, exist_ok=True)
    _tip_only._require_text(args, "--parameter-option", _tip_only.REFERENCE_OPTION)
    _tip_only._require_text(args, "--temperatures", "1000")
    _tip_only._require_text(args, "--bulk-plasticity-mode", "tip_only")
    _tip_only._require_text(args, "--j-decomposition", "cluster")
    _tip_only._require_int(args, "--nx", 36)
    _tip_only._require_int(args, "--ny", 72)
    _tip_only._require_int(args, "--n-stagger", 2)
    _tip_only._require_int(args, "--max-fronts", 1)
    _tip_only._require_float(args, "--crystal-theta-deg", 0.0)
    _tip_only._require_float(args, "--dU", 2.0e-7)
    _tip_only._require_float(args, "--dt", 8.4)
    _tip_only._require_float(args, "--tip-h-fine", 1.0e-6)
    _tip_only._require_float(args, "--tip-ratio", 1.20)
    _tip_only._require_float(args, "--da-phys", 5.0e-6)
    _tip_only._require_float(args, "--adaptive-event-target", 0.15)
    original_guard = _tip_only.REFERENCE_KERNEL_SHA256
    original_mesh_payload = _barrier._mesh_payload

    def mesh_payload_with_persisted_record(mesh, requested_radius_m):
        observed = original_mesh_payload(mesh, requested_radius_m)
        if observed.get("actual_radius_verified", False):
            return observed
        return _persisted_refinement_payload(out, requested_radius_m, observed)

    completed = False
    error = None
    (out / AUDIT_FILE).write_text(json.dumps(
        _contract(args, family, completed=False, error=None),
        indent=2, sort_keys=True,
    ) + "\n")
    try:
        _tip_only.REFERENCE_KERNEL_SHA256 = CURRENT_KERNEL_SHA256
        _barrier._mesh_payload = mesh_payload_with_persisted_record
        with installed_active_only_kernel_family_compat(out):
            # Execute the native atomic-path stack directly while the caller
            # selects its already-qualified exponential/threshold-scaled clock.
            # A new PF arm uses the same clock modes for the common problem.
            result = _tip_only._base.main(args)
        completed = True
        return result
    except BaseException as exc:
        error = exc
        raise
    finally:
        _tip_only.REFERENCE_KERNEL_SHA256 = original_guard
        _barrier._mesh_payload = original_mesh_payload
        contract = _contract(args, family, completed=completed, error=error)
        contract["historical_guard_preserved"]["runtime_restored"] = (
            _tip_only.REFERENCE_KERNEL_SHA256 == HISTORICAL_KERNEL_SHA256
        )
        (out / AUDIT_FILE).write_text(
            json.dumps(contract, indent=2, sort_keys=True) + "\n"
        )


if __name__ == "__main__":
    main()


__all__ = [
    "AUDIT_FILE", "CURRENT_KERNEL_SHA256",
    "CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT", "MODEL_ID", "main",
]
