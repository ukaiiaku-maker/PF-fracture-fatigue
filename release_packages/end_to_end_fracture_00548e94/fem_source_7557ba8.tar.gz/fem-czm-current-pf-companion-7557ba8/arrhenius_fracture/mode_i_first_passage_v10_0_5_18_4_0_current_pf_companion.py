"""Explicit companion entry for the current immutable PF kernel family.

This module does not alter the historical theta-zero parity entry or its
``a85b57...`` guard.  It reuses the same native full-order FEM/CZM builder on a
separate branch while binding the run to the presently available
``1447653...`` PF mechanical configuration and its exact ``d41b08...`` bytes.
The result is a qualified companion calculation, not a recreation of the
historical ``e239710...`` configuration.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sys

from . import (
    mode_i_first_passage_v10_0_5_18_4_0_theta0_pf_full_field_production as _production,
)

MODEL_ID = "FEM_CZM_current_PF_1447653_companion_v1"
AUDIT_FILE = "current_pf_companion_contract_v1.json"
CURRENT_KERNEL_SHA256 = "d41b08f69ae773009f65f4c0094ef5436ba7f0f290a94172e5b894d09a41f7c3"
CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT = (
    "1447653d199f0b43cb475951092d69444c9b785f6fdf518c723792abb3b1f5e5"
)
HISTORICAL_KERNEL_SHA256 = _production._base._control.REFERENCE_KERNEL_SHA256
HISTORICAL_MECHANICAL_CONFIGURATION_FINGERPRINT = (
    "e23971019aca58e8e3319a207153c4faa3ead76417e1d537ec00c2ed2986e815"
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _contract(argv, family, *, completed, error):
    return {
        "schema": MODEL_ID,
        "created_or_updated_utc": _utc_now(),
        "run_completed_without_exception": bool(completed),
        "runtime_error_type": None if error is None else type(error).__name__,
        "runtime_error": None if error is None else str(error),
        "entry": __name__,
        "native_full_order_builder": _production.MODEL_ID,
        "current_dependency": {
            "path": str(family),
            "sha256": _production._base._control._sha256(family),
            "mechanical_configuration_fingerprint": (
                CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT
            ),
        },
        "historical_guard_preserved": {
            "entry": _production._base._control.MODEL_ID,
            "kernel_sha256": HISTORICAL_KERNEL_SHA256,
            "mechanical_configuration_fingerprint": (
                HISTORICAL_MECHANICAL_CONFIGURATION_FINGERPRINT
            ),
            "modified": False,
        },
        "qualification": (
            "separate current-input companion; not byte-identical historical parity"
        ),
        "continuum_transport": {
            "bulk_model": "v10.4.1_bulk_peierls_taylor_detailed_balance_exact_port",
            "bulk_density_transport": False,
            "classification": "full-field local constitutive evolution without spatial density transport",
        },
        "crack_backend": "adaptive_czm_atomic_path_corridor",
        "argv": list(argv),
    }


def main(argv: list[str] | None = None):
    args = list(sys.argv[1:] if argv is None else argv)
    control = _production._base._control
    out_raw = control._option_value(args, "--out")
    family_raw = control._option_value(args, "--signed-kernel-family")
    if out_raw is None or family_raw is None:
        raise SystemExit(f"{MODEL_ID} requires --out and --signed-kernel-family")
    out = Path(out_raw).expanduser().resolve()
    family = Path(family_raw).expanduser().resolve()
    if not family.is_file():
        raise SystemExit(f"current companion kernel is missing: {family}")
    observed_sha = control._sha256(family)
    if observed_sha != CURRENT_KERNEL_SHA256:
        raise SystemExit(
            "current companion kernel SHA-256 mismatch: "
            f"expected {CURRENT_KERNEL_SHA256}, observed {observed_sha}"
        )
    payload = json.loads(family.read_text())
    observed_configuration = payload.get("mechanical_configuration_fingerprint")
    if observed_configuration != CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT:
        raise SystemExit(
            "current companion mechanical configuration mismatch: expected "
            f"{CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT}, observed "
            f"{observed_configuration!r}"
        )
    out.mkdir(parents=True, exist_ok=True)
    original_guard = control.REFERENCE_KERNEL_SHA256
    completed = False
    error = None
    contract = _contract(args, family, completed=False, error=None)
    (out / AUDIT_FILE).write_text(json.dumps(contract, indent=2, sort_keys=True) + "\n")
    try:
        control.REFERENCE_KERNEL_SHA256 = CURRENT_KERNEL_SHA256
        result = _production.main(args)
        completed = True
        return result
    except BaseException as exc:
        error = exc
        raise
    finally:
        control.REFERENCE_KERNEL_SHA256 = original_guard
        contract = _contract(args, family, completed=completed, error=error)
        contract["historical_guard_preserved"]["runtime_restored"] = (
            control.REFERENCE_KERNEL_SHA256 == HISTORICAL_KERNEL_SHA256
        )
        (out / AUDIT_FILE).write_text(
            json.dumps(contract, indent=2, sort_keys=True) + "\n"
        )


if __name__ == "__main__":
    main()


__all__ = [
    "AUDIT_FILE", "CURRENT_KERNEL_SHA256",
    "CURRENT_MECHANICAL_CONFIGURATION_FINGERPRINT", "MODEL_ID", "main",
]
