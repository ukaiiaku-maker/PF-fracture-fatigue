"""Bounded monotonic 2-D FEM adapter for v11 mechanistic branching.

This is a separate production loop.  It reuses the established mesh, FEM,
plasticity, material, and v10.2.28 engine construction, but never enters the
legacy probabilistic branching code in :mod:`sharp_front`.
"""
from __future__ import annotations

from dataclasses import replace
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import sys
import time
from typing import Any, Mapping

import numpy as np

from .branch_checkpoint_v11 import (
    ProductionBranchCheckpoint, restore_branch_checkpoint, write_branch_checkpoint,
)
from .branch_cluster_guard_v11 import evaluate_unresolved_cluster_guard
from .branch_scale_identity_v11 import (
    resolve_branch_scale_identity, selected_local_J_contour_radius,
)
from .branch_cluster_v11 import BranchClusterState, create_unresolved_branch_cluster
from .branch_output_v11 import (
    BRANCH_EVENT_FIELDS, ENERGY_FIELDS, FRONT_FIELDS, PROVIDER_FIELDS, TRIAL_FIELDS,
    BranchOutputWriter,
)
from .branch_snapshot_v11 import write_topology_snapshot
from .crack_network_v11 import CrackNetworkState, ROOT_BRANCH_ID
from .directional_competition_v11 import (
    DirectionalCompetitionState, DirectionalRate, preview_production_cleavage_rate,
    tungsten_cleavage_candidates,
)
from .hazard_energy_event_gate_v10230 import hazard_resistance_J_per_m2
from .live_topology_kernel_registry_v11 import PREBRANCH_PROVIDER_ID
from .live_topology_kernel_v11 import LiveTopologyRequest, PROVIDER_ID
from .live_topology_runtime_v11 import LiveTopologyRuntime
from .adaptive_multitip_mesh_v11 import adapt_accepted_state_for_trials, mesh_fingerprint
from .network_metrics_v11 import crack_growth_metrics
from .production_step_loop_v11 import (
    AcceptedStepContext, DirectionalStepRefinementRequired, advance_accepted_step,
)
from .process_update_semantics_v11 import (
    classify_process_update, require_full_accepted_interval_consumption,
)
from .topology_transaction_v11 import (
    LiveFEMTopologyState, TopologyArm, TopologyTrialResult,
    apply_causal_sharp_wake_trial_geometry, clip_arm_at_first_intersection,
    execute_topology_trial, extend_network_arm, mark_coalesced,
)
from .tip_directional_observation_v11 import (
    apply_post_interval_event_renewal, observations_from_provider,
    marginal_trial_origin, require_same_tip_coupling,
    require_observation_state_contract,
    require_uncontaminated_replay_checkpoint,
    realized_topology_arm_lengths, select_shared_process_renewal_distance,
    select_controlling_observation, selected_event_owner,
    serialize_directional_observation,
)


MODEL_ID = "v11.mechanistic_branching.production_fem_adapter/1"


def _hash(value: Any) -> str:
    return hashlib.sha256(pickle.dumps(value, protocol=5)).hexdigest()


def _stored_energy(mesh, displacement, ep_gp, sigma_gp, D) -> float:
    from .fem import elastic_energy_densities
    density, _ = elastic_energy_densities(mesh, displacement, ep_gp, sigma_gp, D)
    return float(np.sum(density * mesh.area_e))


def _mesh_identity(mesh) -> str:
    digest = hashlib.sha256()
    digest.update(np.ascontiguousarray(mesh.nodes).tobytes())
    digest.update(np.ascontiguousarray(mesh.elems).tobytes())
    return digest.hexdigest()


def _serializable_fields(owner) -> dict[str, Any]:
    result = {}
    for name, value in owner.__dict__.items():
        if callable(value) or name == "mpz":
            continue
        try:
            pickle.dumps(value, protocol=5)
        except Exception:
            continue
        result[name] = value
    return result


def _capture_shared_engine(engine) -> dict[str, Any]:
    return {
        "schema": "v11.shared-production-engine-state/1",
        "engine_type": type(engine).__name__,
        "engine_fields": _serializable_fields(engine),
        "mpz_type": type(engine.mpz).__name__,
        "mpz_fields": _serializable_fields(engine.mpz),
    }


def _restore_shared_engine(engine, payload: Mapping[str, Any]):
    if payload.get("schema") != "v11.shared-production-engine-state/1":
        raise ValueError("unsupported shared production-engine state")
    if payload.get("engine_type") != type(engine).__name__:
        raise RuntimeError("restart engine type differs from initialized production engine")
    engine_fields = payload.get("engine_fields", {})
    mpz_fields = payload.get("mpz_fields", {})
    # A restart is an exact accepted-state restore. Drop serializable defaults
    # introduced by the fresh initializer but absent from the checkpoint. This
    # is especially important for an already migrated family: otherwise the
    # initializer can leave an unrecorded second set of process controls alive.
    from .restart_family_migration_v11 import (
        _drop_serializable_fields_absent_from_checkpoint,
    )
    _drop_serializable_fields_absent_from_checkpoint(
        engine, engine_fields, frozenset({"mpz"})
    )
    _drop_serializable_fields_absent_from_checkpoint(
        engine.mpz, mpz_fields, frozenset()
    )
    restored_fields = copy.deepcopy({"engine": engine_fields, "mpz": mpz_fields})
    for name, value in restored_fields["engine"].items():
        setattr(engine, name, value)
    for name, value in restored_fields["mpz"].items():
        setattr(engine.mpz, name, value)
    from .current_source_runtime_bindings import (
        ENGINE_IDS, rehydrate_current_source_runtime_bindings,
    )
    if type(engine).__name__ in ENGINE_IDS:
        rehydrate_current_source_runtime_bindings(engine)
    return engine


def _write_restore_only_sentinel(
    *,
    target: Path,
    restart_path: str,
    restored: ProductionBranchCheckpoint,
    state: LiveFEMTopologyState,
    engine: Any,
    runtime: LiveTopologyRuntime,
    source_cache_root: Path,
    destination_cache_root: Path,
    start_step: int,
    physical_time: float,
    accepted_load: float,
) -> None:
    """Seal the real production restore path immediately before its first solve.

    This observer is default-off and deliberately has no continuation mode. It
    is reached only after the production entrypoint has restored and rebound a
    checkpoint, and it exits before mesh adaptation, interval construction, a
    provider lookup, or a mechanics/process update can begin.
    """
    from .restart_family_migration_v11 import (
        _family_references, canonical_hash, family_digest, process_state_digest,
        rng_digest,
    )

    manifest_path = Path(restart_path).resolve()
    manifest = json.loads(manifest_path.read_text())
    state_path = manifest_path.with_name(manifest["state_file"])
    migration = dict(restored.restart_family_migration_provenance or {})
    captured = _capture_shared_engine(engine)
    engine_refs = _family_references(engine)
    mpz_refs = _family_references(engine.mpz)
    family = engine_refs.get("_state_kernel_family")
    if family is None or mpz_refs.get("_signed_kernel") is not family:
        raise RuntimeError("restore-only sentinel found split engine/MPZ family identity")

    migration_count_before = int(
        restored.shared_process_state.get("engine_fields", {}).get(
            "_restart_family_migration_count", 0
        )
    )
    migration_count_after = int(getattr(engine, "_restart_family_migration_count", 0))
    runtime_audit = runtime.audit_payload()
    solve_count = int(runtime_audit.get("live_fem_solve_count", -1))
    accepted_provider_states = int(runtime_audit.get("accepted_provider_state_count", -1))
    checks = {
        "migration_count_remains_one": migration_count_before == migration_count_after == 1,
        "second_migration_not_performed": migration_count_after == migration_count_before,
        "target_family_hash_matches_migration": bool(migration.get("target_family_sha256")),
        "target_family_fingerprint_present": bool(
            migration.get("target_family_physics_fingerprint")
        ),
        "target_bound_family_digest_matches": (
            family_digest(family) == migration.get("target_bound_family_digest")
        ),
        "engine_mpz_same_target_object": engine._state_kernel_family is engine.mpz._signed_kernel,
        "only_target_family_reachable": (
            set(engine_refs) == {"_state_kernel_family"}
            and set(mpz_refs) == {"_signed_kernel"}
            and {id(value) for value in (*engine_refs.values(), *mpz_refs.values())}
            == {id(family)}
        ),
        "old_family_unreachable": migration.get("old_family_reachable_after_migration") is False,
        "accepted_state_unchanged": all(
            canonical_hash(getattr(restored.state, name))
            == canonical_hash(getattr(state, name))
            for name in restored.state.__dataclass_fields__
        ),
        "process_state_unchanged": (
            process_state_digest(restored.shared_process_state)
            == process_state_digest(captured)
        ),
        "rng_threshold_state_unchanged": (
            rng_digest(restored.shared_process_state) == rng_digest(captured)
        ),
        "physical_time_unchanged": physical_time == float(restored.physical_time_s),
        "accepted_opening_unchanged": accepted_load == float(restored.accepted_load),
        "provider_cache_rebound_before_lookup": (
            source_cache_root != destination_cache_root
            and Path(runtime.cache_root).resolve() == destination_cache_root
        ),
        "provider_solve_count_zero": solve_count == 0,
        "accepted_provider_state_count_zero": accepted_provider_states == 0,
        "accepted_interval_not_begun": (
            start_step == int(state.event_counters.get("accepted_steps", 0)) + 1
        ),
        "no_pf_worker_started": True,
    }
    if not all(checks.values()):
        failed = sorted(key for key, value in checks.items() if not value)
        raise RuntimeError(f"production restore-only sentinel failed: {failed}")

    payload = {
        "schema": "pf_branching_production_restore_only_sentinel_v5_4_1/1",
        "qualification": "PASS",
        "boundary": "CAPABILITY_DEMONSTRATION_NOT_VALIDATED_BRANCHING_PHYSICS",
        "source_checkpoint": str(manifest_path),
        "source_checkpoint_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "source_checkpoint_state": str(state_path.resolve()),
        "source_checkpoint_state_sha256": hashlib.sha256(state_path.read_bytes()).hexdigest(),
        "migration_count_before_restore": migration_count_before,
        "migration_count_after_restore": migration_count_after,
        "migration_provenance": migration,
        "target_bound_family_digest": family_digest(family),
        "source_provider_cache_root": str(source_cache_root),
        "destination_provider_cache_root": str(destination_cache_root),
        "runtime_provider_audit": runtime_audit,
        "restored_physical_time_s": float(restored.physical_time_s),
        "restored_accepted_opening_m": float(restored.accepted_load),
        "restored_projected_extension_m": float(restored.projected_extension_m),
        "restored_physical_extension_m": float(restored.physical_extension_m),
        "next_step_if_authorized": int(start_step),
        "checks": checks,
        "provider_lookup_performed": False,
        "mechanics_solve_performed": False,
        "process_or_stochastic_update_performed": False,
        "accepted_interval_begun": False,
        "worker_started": False,
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n")
    os.replace(temporary, target)


def _request(
    state: LiveFEMTopologyState, candidates, *, args, cfg, runtime_step: int,
    cluster: BranchClusterState | None,
) -> LiveTopologyRequest:
    candidate_map = _candidate_map(candidates)
    by_tip = {}
    for tip in state.crack_network.active_tip_ids:
        physical_id = state.crack_network.branch(tip).local_state.get("candidate_id")
        by_tip[tip] = (
            (candidate_map[physical_id],) if physical_id in candidate_map
            else tuple(candidates)
        )
    geometry = {
        name: float(getattr(cfg.geometry, name))
        for name in ("Lx", "Ly", "a0", "notch_half_thickness")
    }
    frame = (
        {"mode": "single_front"}
        if cluster is None else {
            "mode": "shared_unresolved_cluster", "cluster_id": cluster.cluster_id,
            "junction_xy_m": list(cluster.junction_xy_m),
        }
    )
    mat = state.material
    return LiveTopologyRequest(
        mesh=state.mesh, boundary=state.boundary,
        displacement=state.displacement, ep_gp=state.ep_gp, rho_gp=state.rho_gp,
        damage=state.damage, elasticity_D=state.elasticity_D, material=mat,
        cohesive_network=state.cohesive_network, crack_network=state.crack_network,
        candidates_by_tip=by_tip,
        mechanical_configuration_fingerprint=str(os.environ.get("MECHANICAL_CONFIG_SHA256", "v10.2.28-installed")),
        specimen_geometry=geometry,
        boundary_condition_identity=f"symmetric_opening:step={runtime_step}",
        elastic_constants={"E_Pa": float(mat.E), "nu": float(mat.nu), "Eprime_Pa": float(mat.Eprime)},
        cluster_frame=frame, mpz_station_coordinates_m=(), wake_station_coordinates_m=(),
        contour_radius_m=float(getattr(args, "rJ", None) or max(args.L_pz, 1.0e-6)),
        exclude_radius_m=max(float(getattr(state.mesh, "hbar_tip", 0.0) or state.mesh.hbar), 1.0e-12),
        provider_contract_contour_radius_m=_provider_contract_interaction_length(args),
    )


def _provider_contract_interaction_length(args) -> float:
    path = os.environ.get("MECHANICAL_CONFIG", "").strip()
    if not path:
        family = os.environ.get("SIGNED_KERNEL_FAMILY_JSON", "").strip()
        sibling = Path(family).resolve().parent / "mechanical_configuration.json" if family else None
        if sibling is not None and sibling.is_file():
            path = str(sibling)
    if path:
        from .kernel_configuration_v10227 import load_configuration
        return float(load_configuration(path).interaction_length_m)
    return float(getattr(args, "rJ", None) or max(args.L_pz, 1.0e-6))


def _direct_measurement(state, candidates, args) -> dict[str, Any]:
    from .fem import assemble_mechanics
    from .j_integral import compute_J_integral
    Kmat, Rint, sigma, seq, s1, psi = assemble_mechanics(
        state.mesh, state.displacement, state.ep_gp, state.rho_gp, state.damage,
        state.elasticity_D, state.material, cohesive_network=state.cohesive_network,
    )
    segments = [
        (np.asarray(a), np.asarray(b)) for branch in state.crack_network.branches
        for a, b in zip(branch.path, branch.path[1:])
    ]
    branch = state.crack_network.branch(state.crack_network.active_tip_ids[0])
    directional = []
    ell = float(getattr(args, "rJ", None) or max(args.L_pz, 1.0e-6))
    contract_ell = _provider_contract_interaction_length(args)
    exclude = max(float(getattr(state.mesh, "hbar_tip", 0.0) or state.mesh.hbar), 1.0e-12)
    for candidate in candidates:
        _, _, info = compute_J_integral(
            state.mesh, state.displacement, sigma, psi, state.damage,
            np.asarray(branch.tip), np.asarray(candidate.direction_xy), state.material,
            ell=ell, crack_segments=segments, exclude_radius=exclude,
        )
        signed = float(info.get("J_signed", info.get("J", 0.0)))
        positive = max(signed, 0.0)
        if contract_ell == ell:
            contract_info = info
        else:
            _, _, contract_info = compute_J_integral(
                state.mesh, state.displacement, sigma, psi, state.damage,
                np.asarray(branch.tip), np.asarray(candidate.direction_xy), state.material,
                ell=contract_ell, crack_segments=segments, exclude_radius=exclude,
            )
        contract_signed = float(
            contract_info.get("J_signed", contract_info.get("J", 0.0))
        )
        contract_positive = max(contract_signed, 0.0)
        directional.append({
            "candidate_id": candidate.candidate_id,
            "signed_J_J_per_m2": signed,
            "positive_J_J_per_m2": positive,
            "K_directional_Pa_sqrt_m": math.sqrt(float(state.material.Eprime) * positive),
            "J_provider_contract_signed_J_per_m2": contract_signed,
            "J_provider_contract_positive_J_per_m2": contract_positive,
            "K_provider_contract_Pa_sqrt_m": math.sqrt(
                float(state.material.Eprime) * contract_positive
            ),
            "provider_contract_contour_radius_m": contract_ell,
            "provider_contract_auxiliary_direction_xy": list(candidate.direction_xy),
            "provider_contract_integration": contract_info,
        })
    return {
        # The accepted solver supplies the authoritative Dirichlet reaction;
        # this helper owns only directional configurational measurements.
        "reaction_force": 0.0,
        "recoverable_potential_energy_J_per_m": state.stored_energy_J_per_m,
        "directional": directional,
    }


def solve_accepted_state_v12_hook(
    current, context, *, accepted_load: float, trial_fraction: float,
    args, cfg, base, material, elasticity_D, candidates,
):
    """Reusable exact extraction of the reviewed V5.4.2 accepted solve.

    This is the former ``run`` closure with its captured values explicit.  It
    intentionally performs the identical staggered FEM/plasticity sequence.
    """
    from .fem import assemble_mechanics, solve_dirichlet
    from .plasticity import update_plasticity

    trial_load = float(accepted_load) + float(args.dU) * float(trial_fraction)
    u = current.displacement.copy()
    ep = current.ep_gp.copy()
    rho = current.rho_gp.copy()
    sigma = None
    reaction = 0.0
    for _ in range(int(args.n_stagger)):
        Kmat, Rint, sigma, seq, s1, psi = assemble_mechanics(
            current.mesh, u, ep, rho, current.damage, elasticity_D, material,
            cohesive_network=current.cohesive_network,
        )
        u, reaction = solve_dirichlet(
            Kmat, Rint, u, current.boundary, 0.5 * trial_load, -0.5 * trial_load
        )
        Kmat, Rint, sigma, seq, s1, psi = assemble_mechanics(
            current.mesh, u, ep, rho, current.damage, elasticity_D, material,
            cohesive_network=current.cohesive_network,
        )
        plast = base.PlasticityModel(cfg.plasticity_barrier, material)
        ep, rho, _ = update_plasticity(
            ep, rho, sigma, material, float(args.temperatures[0]),
            context.duration_s, plast, cfg.dislocations,
        )
    Kmat, Rint, sigma, seq, s1, psi = assemble_mechanics(
        current.mesh, u, ep, rho, current.damage, elasticity_D, material,
        cohesive_network=current.cohesive_network,
    )
    u, reaction = solve_dirichlet(
        Kmat, Rint, u, current.boundary, 0.5 * trial_load, -0.5 * trial_load
    )
    Kmat, Rint, sigma, seq, s1, psi = assemble_mechanics(
        current.mesh, u, ep, rho, current.damage, elasticity_D, material,
        cohesive_network=current.cohesive_network,
    )
    energy = _stored_energy(current.mesh, u, ep, sigma, elasticity_D)
    solved = replace(
        current, displacement=u, ep_gp=ep, rho_gp=rho,
        stored_energy_J_per_m=energy,
    )
    measurement = _direct_measurement(solved, candidates, args)
    measurement["reaction_force"] = float(reaction)
    return solved, np.asarray(sigma).copy(), measurement


def evolve_process_engine_v12_hook(
    engine, controlling_observation, accepted_state, accepted_sigma, *,
    accepted_state_id: str, stress_field_state_id: str,
    pre_event_topology_fingerprint: str, duration_s: float,
    temperature_K: float, pre_progress: float,
    permitted_physical_hazard_action: float,
):
    """Execute the V5.4.2 pre-event process interval without topology renewal.

    This is the reusable production form of ``update_shared``.  Directional
    competition remains the sole cleavage/topology clock.  The returned
    engine is an isolated accepted candidate; callers commit it only after the
    complete interval validates and perform moving-frame renewal separately.
    """
    require_observation_state_contract(
        controlling_observation,
        accepted_state_id=accepted_state_id,
        stress_field_state_id=stress_field_state_id,
        pre_event_topology_fingerprint=pre_event_topology_fingerprint,
    )
    require_same_tip_coupling(
        controlling_observation.tip_id, controlling_observation.tip_id,
    )
    from .anisotropic_emission_v10174 import (
        bind_explicit_accepted_tensor_drive,
        install_explicit_accepted_tensor_drive,
    )
    bound_drive = bind_explicit_accepted_tensor_drive(
        mesh=accepted_state.mesh, sigma_gp=accepted_sigma,
        damage=accepted_state.damage,
        tip_xy=np.asarray(controlling_observation.tip_xy_m),
        config=engine.anisotropic_cfg,
        accepted_state_id=accepted_state_id,
        stress_field_state_id=stress_field_state_id,
    )
    engine_trial = copy.deepcopy(engine)
    prior_drive = getattr(engine_trial, "_anisotropic_drive", None) or {}
    # These counters order drives only within one physical engine.  Derive
    # them from restored engine state so fresh-process observer diagnostics do
    # not alter checkpoint identity or restart equivalence.
    bound_drive["drive_serial"] = int(
        getattr(engine_trial, "_anisotropic_drive_serial", -1)
    ) + 1
    bound_drive["mechanics_serial"] = int(
        prior_drive.get("mechanics_serial", -1)
    ) + 1
    install_explicit_accepted_tensor_drive(engine_trial, bound_drive)
    engine_trial.B = float(pre_progress)
    if hasattr(engine_trial, "hazard_action_current"):
        engine_trial.hazard_action_current = float(pre_progress)
    if hasattr(engine_trial, "hazard_threshold_action"):
        engine_trial.hazard_threshold_action = 1.0e300
    engine_trial._directional_topology_owns_cleavage = True
    legacy_rng_before = _hash(getattr(engine_trial, "_hazard_rng", None))
    info = engine_trial.step(
        float(controlling_observation.directional_K_Pa_sqrt_m),
        float(temperature_K), float(duration_s),
    )
    legacy_rng_after = _hash(getattr(engine_trial, "_hazard_rng", None))
    info["interval_evolved"] = True
    info.update(require_full_accepted_interval_consumption(info, duration_s))
    info["legacy_process_fired"] = bool(info.get("fired", False))
    info["legacy_process_rng_hash_before"] = legacy_rng_before
    info["legacy_process_rng_hash_after"] = legacy_rng_after
    info["directional_event_selected"] = False
    info["directional_event_completion_time_s"] = None
    info["explicit_accepted_tensor_drive"] = bound_drive
    if abs(float(info.get("da", 0.0))) > 1.0e-18:
        raise RuntimeError("legacy process observer advanced crack geometry")
    decision = classify_process_update(
        info, directional_event_expected=False,
        permitted_physical_hazard_action=float(permitted_physical_hazard_action),
    )
    if decision.refinement_required:
        raise DirectionalStepRefinementRequired(
            decision.physical_hazard_action_step,
            float(permitted_physical_hazard_action),
            refinement_reason=(decision.refinement_reason or "process_update_refinement"),
            diagnostics={**decision.diagnostics, "info": info},
        )
    return engine_trial, info


def _candidate_map(candidates):
    return {candidate.candidate_id: candidate for candidate in candidates}


def _realized_trial_network(state, proposal, candidates, da_phys, cluster):
    cmap = _candidate_map(candidates)
    network = state.crack_network
    trial_cluster = cluster
    if proposal.action_type == "two_arm" and cluster is None:
        network, trial_cluster = create_unresolved_branch_cluster(
            network, parent_branch_id=ROOT_BRANCH_ID,
            candidate_ids=proposal.member_candidate_ids,
            event_index=state.competition.competition_event_index + 1,
            shared_process_state=dict(state.tip_process_state),
            conserved_ledgers={name: float(state.energy_ledgers.get(name, 0.0)) for name in (
                "retained", "mobile", "escaped", "recovered", "stored_energy",
                "emission_work", "unconsumed_action",
            )},
        )
    arms = []
    for candidate_id in proposal.member_candidate_ids:
        candidate = cmap[candidate_id]
        if trial_cluster is None:
            branch_id = ROOT_BRANCH_ID
        else:
            branch_id = next(
                item for item in trial_cluster.arm_branch_ids
                if network.branch(item).local_state.get("candidate_id") == candidate_id
            )
        start = network.branch(branch_id).tip
        end = (
            start[0] + da_phys * candidate.direction_xy[0],
            start[1] + da_phys * candidate.direction_xy[1],
        )
        arms.append((candidate, TopologyArm(
            candidate_id=candidate_id, branch_id=branch_id, start_xy_m=start,
            end_xy_m=end, event_reward_m=da_phys, hazard_dissipation_J_per_m=0.0,
        )))
    return network, trial_cluster, tuple(arms)


def run_2d(args, *, parent_capture=None, inherited_primary_race=False):
    from . import sharp_front as base
    from .fem import assemble_mechanics, plane_strain_D, solve_dirichlet
    from .mesh import make_boundary_data, make_tri_mesh
    from .plasticity import update_plasticity

    if bool(getattr(args, "fatigue_cycles", False)):
        raise SystemExit("v11 mechanistic branching supports monotonic loading only")
    if str(args.crack_backend) != "sharp_wake":
        raise SystemExit("v11 mechanistic branching requires the sharp_wake backend")
    cfg = base.make_emergent_config()
    cfg.mesh.nx = args.nx; cfg.mesh.ny = args.ny
    cfg.mesh.tip_h_fine = getattr(args, "tip_h_fine", 0.0) or 0.0
    cfg.mesh.tip_ratio = getattr(args, "tip_ratio", 1.15)
    cfg.loading.n_steps = args.steps; cfg.loading.dU_top = args.dU; cfg.loading.dt = args.dt
    mat = cfg.material
    mesh = make_tri_mesh(cfg.geometry, cfg.mesh, seed=42)
    boundary = make_boundary_data(mesh, cfg.geometry)
    if getattr(args, "crystal_aniso", False):
        from .crystal import W_C11, W_C12, W_C44, cubic_plane_strain_D
        D = cubic_plane_strain_D(
            float(getattr(args, "crystal_C11", None) or W_C11),
            float(getattr(args, "crystal_C12", None) or W_C12),
            float(getattr(args, "crystal_C44", None) or W_C44),
            float(getattr(args, "crystal_theta_deg", 0.0) or 0.0),
        )
    else:
        D = plane_strain_D(mat)
    engine = base.build_engine(args, mat)
    da_phys = float(args.da_phys if args.da_phys is not None else max(5.0 * base.eng_r_pz_hint(args), 2.0e-6))
    engine.f.da = da_phys
    scale_identity = resolve_branch_scale_identity(args, mesh)
    engine.f.max_advances_per_step = 1
    theta = float(getattr(args, "crystal_theta_deg", 0.0) or 0.0)
    candidates = tungsten_cleavage_candidates(
        theta_deg=theta, include_110=bool(getattr(args, "crystal_include_110", False)),
        gamma_110_rel=float(getattr(args, "gamma_110_rel", 1.3) or 1.3),
    )
    seed = int(os.environ.get("CLEAVAGE_HAZARD_SEED", getattr(args, "hazard_seed", 3621) or 3621))
    competition = DirectionalCompetitionState.initialize(candidates, global_hazard_seed=seed)
    maximum_fronts = int(os.environ.get("PF_CURRENT_SOURCE_MAX_FRONTS", "2"))
    if maximum_fronts not in (1, 2):
        raise SystemExit("current-source bounded capability requires one or two fronts")
    network = replace(
        CrackNetworkState.one_tip(((0.0, 0.0), (float(cfg.geometry.a0), 0.0))),
        branching_enabled=maximum_fronts > 1,
    )
    damage = np.zeros(mesh.nn)
    damage[(mesh.nodes[:, 0] <= cfg.geometry.a0) & (np.abs(mesh.nodes[:, 1]) <= cfg.geometry.notch_half_thickness)] = 1.0
    displacement = np.zeros(mesh.ndof); ep_gp = np.zeros((3, mesh.ne)); rho_gp = np.full(mesh.ne, engine.f.rho0)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    audit_path = out / "v11_branching_model_audit.json"
    if audit_path.is_file():
        audit = json.loads(audit_path.read_text())
        audit["runtime_scale_identity"] = scale_identity.to_dict()
        persistent = getattr(engine, "_persistent_site_cfg", None)
        selection_path = out / "v10_2_22_parameter_selection.json"
        selection = json.loads(selection_path.read_text()) if selection_path.is_file() else {}
        selected_source_zone = selection.get("persistent_site_config", {}).get("source_zone_length_m")
        audit["source_zone_length_m"] = float(
            persistent.source_zone_length_m if persistent is not None else selected_source_zone
        )
        audit["source_zone_length_source"] = "selected_material_manifest.persistent_site_config.source_zone_length_m"
        temporary = audit_path.with_name(audit_path.name + ".tmp")
        temporary.write_text(json.dumps(audit, indent=2, sort_keys=True, allow_nan=False) + "\n")
        os.replace(temporary, audit_path)
    writer = BranchOutputWriter(out)
    cache_root = Path(os.environ.get("KERNEL_CACHE_ROOT", out / "live_kernel_cache"))
    runtime = LiveTopologyRuntime(str(cache_root)); cluster = None
    physical_time = 0.0; accepted_load = 0.0; termination = None; start_step = 1
    state = LiveFEMTopologyState(
        mesh=mesh, boundary=boundary, damage=damage, displacement=displacement,
        ep_gp=ep_gp, rho_gp=rho_gp, elasticity_D=D, material=mat,
        cohesive_network=None, crack_network=network, competition=competition,
        tip_process_state={"shared_engine_model": type(engine).__name__},
        junction_process_state={"crack_representation": "sharp_wake_causal_v11"}, energy_ledgers={name: 0.0 for name in (
            "retained", "mobile", "escaped", "recovered", "stored_energy",
            "emission_work", "unconsumed_action", "topology_release_J_per_m",
            "hazard_dissipation_J_per_m",
        )}, rng_state=np.random.default_rng(seed).bit_generator.state,
        event_counters={"topology_actions": 0, "shared_state_updates": 0},
        stored_energy_J_per_m=0.0,
    )
    restart_path = os.environ.get("V11_BRANCH_RESTART_CHECKPOINT", "").strip()
    if not restart_path:
        write_topology_snapshot(
            out, state, step=0, reason="initiation", physical_extension_m=0.0,
            branch_birth_count=0, latest_action=None,
        )
    if restart_path:
        restored = restore_branch_checkpoint(restart_path)
        restart_name = Path(restart_path).name
        if not restart_name.startswith("step") or len(restart_name) < 11:
            raise RuntimeError("restart checkpoint filename does not encode its accepted step")
        restart_step = int(restart_name[4:11])
        require_uncontaminated_replay_checkpoint(
            restart_step, first_selected_event_step=287,
        )
        expected_branching_policy = maximum_fronts > 1
        if bool(restored.state.crack_network.branching_enabled) != expected_branching_policy:
            raise RuntimeError(
                "restart branching policy differs from the requested maximum-fronts policy"
            )
        requested_target_m = float(
            getattr(args, "target_crack_extension_um", float("inf"))
        ) * 1.0e-6
        if requested_target_m <= restored.projected_extension_m:
            raise RuntimeError(
                "restart target must exceed the accepted checkpoint extension: "
                f"target={requested_target_m:.17g} "
                f"checkpoint={restored.projected_extension_m:.17g}"
            )
        source_cache_root = Path(restored.provider_cache_identity).resolve()
        destination_cache_root = cache_root.resolve()
        if source_cache_root == destination_cache_root:
            raise RuntimeError(
                "restart must fork to a fresh cache root; source evidence is immutable"
            )
        state = restored.state
        restored_junction = dict(state.junction_process_state)
        restored_junction["crack_representation"] = "sharp_wake_causal_v11"
        state = replace(state, junction_process_state=restored_junction)
        # A continuation is a provenance-linked output fork.  The routing and
        # solve counters resume exactly, but every newly generated provider
        # state belongs to the destination.  Reusing the serialized source
        # cache path would silently mutate immutable evidence.
        runtime = replace(restored.provider_runtime, cache_root=str(destination_cache_root))
        physical_time = restored.physical_time_s
        accepted_load = restored.accepted_load
        cluster = restored.branch_clusters[0] if restored.branch_clusters else None
        mesh = state.mesh; boundary = state.boundary; D = state.elasticity_D; mat = state.material
        start_step = int(state.event_counters.get("accepted_steps", 0)) + 1
        source_manifest = json.loads(Path(restart_path).read_text())
        restart_provenance = {
            "schema": "v11.branching-restart-output-fork/1",
            "source_checkpoint": str(Path(restart_path).resolve()),
            "source_checkpoint_state_sha256": source_manifest["state_sha256"],
            "source_checkpoint_topology_fingerprint": restored.topology_fingerprint,
            "source_checkpoint_mesh_identity": restored.mesh_identity,
            "source_checkpoint_accepted_steps": start_step - 1,
            "source_checkpoint_projected_extension_m": restored.projected_extension_m,
            "source_checkpoint_physical_time_s": restored.physical_time_s,
            "source_checkpoint_accepted_load_m": restored.accepted_load,
            "source_checkpoint_termination_reason": restored.termination_reason,
            "requested_target_extension_m": requested_target_m,
            "source_provider_cache_root": str(source_cache_root),
            "destination_provider_cache_root": str(destination_cache_root),
            "source_cache_rebound_to_destination": True,
            "accepted_state_and_rng_restored_without_advance": True,
        }
        provenance_path = out / "restart_fork_provenance.json"
        temporary = provenance_path.with_name(provenance_path.name + ".tmp")
        temporary.write_text(
            json.dumps(restart_provenance, indent=2, sort_keys=True, allow_nan=False) + "\n"
        )
        os.replace(temporary, provenance_path)
        if restored.shared_process_state.get("schema") == "v11.multi-tip-engine-bundle/2":
            from .resolved_production_v11 import continue_resolved_production
            return continue_resolved_production(
                args=args, cfg=cfg, state=state, shared_engine=engine,
                runtime=runtime, cluster=None, candidates=candidates,
                writer=writer, out=out, cache_root=cache_root,
                physical_time=physical_time, accepted_load=accepted_load,
                start_step=start_step, engine_factory=lambda: base.build_engine(args, mat),
                resume_bundle=restored.shared_process_state,
                resume_competitions=restored.front_competitions,
                resume_clusters=restored.branch_clusters,
            )
        engine = _restore_shared_engine(engine, restored.shared_process_state)
        restore_only_target = os.environ.get(
            "PF_V5_4_1_RESTORE_ONLY_SENTINEL_OUT", ""
        ).strip()
        if restore_only_target:
            _write_restore_only_sentinel(
                target=Path(restore_only_target), restart_path=restart_path,
                restored=restored, state=state, engine=engine, runtime=runtime,
                source_cache_root=source_cache_root,
                destination_cache_root=destination_cache_root,
                start_step=start_step,
                physical_time=physical_time, accepted_load=accepted_load,
            )
            return None
        if (
            (
                restored.termination_reason == "branch_cluster_independent_tip_handoff_required"
                or bool(restored.handoff_guard_diagnostics.get("handoff_required"))
            )
            and cluster is not None
        ):
            from .resolved_production_v11 import continue_resolved_production
            return continue_resolved_production(
                args=args, cfg=cfg, state=state, shared_engine=engine,
                runtime=runtime, cluster=cluster, candidates=candidates,
                writer=writer, out=out, cache_root=cache_root,
                physical_time=physical_time, accepted_load=accepted_load,
                start_step=start_step, engine_factory=lambda: base.build_engine(args, mat),
            )
    last_measurement = {}; latest_sigma = None; latest_interval_rates = (); latest_live_result = None
    prebranch_snapshot_written = False
    adaptation_required = True

    for step in range(start_step, int(args.steps) + 1):
        if adaptation_required:
            adaptation_start = time.perf_counter()
            inventory = {tip: tuple(candidates) for tip in state.crack_network.active_tip_ids}
            previous_generation = int(state.event_counters.get("mesh_generation", 0))
            previous_operation = int(state.event_counters.get("refinement_operation_index", 0))
            state, adaptation = adapt_accepted_state_for_trials(
                state, inventory, da_phys_m=da_phys,
                tip_h_fine_m=float(getattr(args, "tip_h_fine", 0.0) or 1.0e-6),
                contour_radius_m=float(getattr(args, "rJ", None) or args.L_pz),
                crack_band_radius_m=0.5e-6, accepted_load_m=accepted_load,
                starting_generation=previous_generation,
                starting_operation_index=previous_operation,
            )
            if adaptation.lineages:
                counters = dict(state.event_counters)
                counters["mesh_generation"] = adaptation.lineages[-1].mesh_generation
                counters["refinement_operation_index"] = adaptation.lineages[-1].refinement_operation_index
                junction = dict(state.junction_process_state)
                junction["mesh_refinement"] = {
                    "latest": adaptation.lineages[-1].to_dict(),
                    "physical_topology_fingerprint": _hash(state.crack_network),
                    "mechanical_discretization_fingerprint": mesh_fingerprint(state.mesh),
                }
                state = replace(state, event_counters=counters, junction_process_state=junction)
                mesh = state.mesh; boundary = state.boundary
                growth_now = crack_growth_metrics(
                    state.crack_network, initial_crack_length_m=cfg.geometry.a0,
                )
                record = {
                    "step": step, "physical_time_s": physical_time,
                    "root_to_tip_extension_um": (
                        growth_now.max_root_to_tip_path_extension_m * 1.0e6
                    ),
                    "node_count": state.mesh.nn, "element_count": state.mesh.ne,
                    "active_tip_count": len(state.crack_network.active_tip_ids),
                    "levels_added": len(adaptation.lineages),
                    "elements_marked": sum(len(item.refined_parent_element_ids) for item in adaptation.lineages),
                    "elements_added_by_conformity": sum(item.elements_added_by_conformity for item in adaptation.lineages),
                    "minimum_active_tip_hbar_m": min(adaptation.active_tip_hbar_m.values()),
                    "maximum_active_tip_hbar_m": max(adaptation.active_tip_hbar_m.values()),
                    "parent_energy_J_per_m": adaptation.parent_energy_J_per_m,
                    "prolonged_energy_J_per_m": adaptation.prolonged_energy_J_per_m,
                    "refined_equilibrium_energy_J_per_m": adaptation.refined_equilibrium_energy_J_per_m,
                    "parent_vs_prolonged_relative_error": adaptation.parent_vs_prolonged_relative_error,
                    "refined_equilibrium_relative_correction": adaptation.refined_equilibrium_relative_correction,
                    "reaction_prolongated_N_per_m": adaptation.reaction_prolongated_N_per_m,
                    "reaction_refined_equilibrium_N_per_m": adaptation.reaction_refined_equilibrium_N_per_m,
                    "adaptation_wall_time_s": time.perf_counter() - adaptation_start,
                    "provider_solve_count": runtime.live_fem_solve_count,
                    "cumulative_mark_operations": adaptation.refinement_marking_diagnostics["cumulative_mark_operations"],
                    "unique_initial_parent_elements_affected": adaptation.refinement_marking_diagnostics["unique_initial_parent_elements_affected"],
                    "physical_marked_area_m2_by_level": [
                        item["physical_marked_area_m2"]
                        for item in adaptation.refinement_marking_diagnostics["levels"]
                    ],
                }
                with (out / "mesh_adaptations.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
                with (out / "refinement_marking_diagnostics.jsonl").open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps({
                        "step": step,
                        "root_to_tip_extension_um": record["root_to_tip_extension_um"],
                        **adaptation.refinement_marking_diagnostics,
                    }, sort_keys=True, allow_nan=False) + "\n")
                adaptation_checkpoint = ProductionBranchCheckpoint(
                    state=state, shared_process_state=_capture_shared_engine(engine),
                    physical_time_s=physical_time, accepted_load=accepted_load,
                    mesh_identity=_mesh_identity(state.mesh),
                    boundary_condition_state={"opening_m": accepted_load}, provider_runtime=runtime,
                    provider_cache_identity=str(cache_root.resolve()),
                    topology_fingerprint=_hash((state.crack_network, mesh_fingerprint(state.mesh))),
                    front_competitions={tip: state.competition for tip in state.crack_network.active_tip_ids},
                    branch_clusters=(() if cluster is None else (cluster,)),
                    projected_extension_m=growth_now.max_forward_projected_extension_m,
                    physical_extension_m=growth_now.max_root_to_tip_path_extension_m,
                    handoff_guard_diagnostics={}, termination_reason=None,
                )
                path = out / "checkpoint" / "transitions" / f"step{step:07d}_mesh_adaptation_g{counters['mesh_generation']:04d}.json"
                write_branch_checkpoint(adaptation_checkpoint, path)
                write_branch_checkpoint(adaptation_checkpoint, out / "checkpoint" / "latest.json")
            adaptation_required = False
        trial_fraction = 1.0
        context = AcceptedStepContext(step, physical_time, float(args.dt), _hash((step, state.crack_network, state.competition, mesh_fingerprint(state.mesh))))
        if parent_capture is not None:
            parent_capture.begin(state, engine, physical_time, accepted_load, runtime)

        def solve_accepted(current, _context):
            nonlocal last_measurement, latest_sigma
            solved, latest_sigma, last_measurement = solve_accepted_state_v12_hook(
                current, _context, accepted_load=accepted_load,
                trial_fraction=trial_fraction, args=args, cfg=cfg, base=base,
                material=mat, elasticity_D=D, candidates=candidates,
            )
            return solved

        latest_interval_observations = ()
        latest_interval_pre_event_state = None
        latest_stress_field_state_id = ""

        def rates(current, _context):
            nonlocal latest_interval_rates, latest_interval_observations
            nonlocal latest_interval_pre_event_state, latest_stress_field_state_id
            nonlocal latest_live_result, runtime
            source = last_measurement["directional"]
            provider_tips = ({
                "tip_xy_m": list(current.crack_network.branch(
                    current.crack_network.active_tip_ids[0]
                ).tip),
                "directional": source,
            },)
            if runtime.routing.active_mechanics_provider == PROVIDER_ID:
                request = _request(current, candidates, args=args, cfg=cfg, runtime_step=step, cluster=cluster)
                live, _ = __import__("arrhenius_fracture.kernel_resolver_v11", fromlist=["resolve_live_topology_request"]).resolve_live_topology_request(
                    request, cache_root=runtime.cache_root, accepted=True
                )
                latest_live_result = live
                provider_tips = tuple(live["tips"])
            pre_event_state_id = _hash((
                _context.accepted_state_id,
                current.crack_network,
                current.displacement,
                current.ep_gp,
                current.rho_gp,
            ))
            latest_interval_pre_event_state = current
            latest_stress_field_state_id = _hash((
                pre_event_state_id, latest_sigma, mesh_fingerprint(current.mesh)
            ))
            observations = observations_from_provider(
                current.crack_network,
                provider_tips,
                (candidate.candidate_id for candidate in candidates),
                accepted_state_id=pre_event_state_id,
                topology_fingerprint=_hash(current.crack_network),
                stress_field_state_id=latest_stress_field_state_id,
            )
            by_id = {item.candidate_id: item for item in observations}
            rows = []
            updated_observations = []
            for candidate in candidates:
                observation = by_id[candidate.candidate_id]
                local_signed = observation.signed_J_J_per_m2
                local_valid = observation.local_contour_valid
                marginal = None
                kinetic = max(local_signed, 0.0)
                if not local_valid:
                    tip_id, start = marginal_trial_origin(
                        current.crack_network, observation
                    )
                    raw = TopologyArm(
                        candidate.candidate_id, tip_id, start,
                        (start[0] + da_phys * candidate.direction_xy[0],
                         start[1] + da_phys * candidate.direction_xy[1]), da_phys, 0.0,
                    )
                    arm, target = clip_arm_at_first_intersection(current.crack_network, raw)
                    if arm.event_reward_m <= 0.0:
                        marginal = 0.0
                    else:
                        realized = extend_network_arm(current.crack_network, arm)
                        if target is not None:
                            realized = mark_coalesced(realized, arm.branch_id, target)
                        ephemeral = replace(current.isolated_copy(), crack_network=realized)
                        ephemeral = apply_causal_sharp_wake_trial_geometry(ephemeral, (arm,))
                        marginal_request = _request(
                            ephemeral, candidates, args=args, cfg=cfg,
                            runtime_step=step, cluster=cluster,
                        )
                        marginal_request = replace(
                            marginal_request,
                            cluster_frame={"mode": "candidate_marginal_kinetic_drive"},
                        )
                        runtime, marginal_live = runtime.evaluate_trial(marginal_request)
                        marginal = (
                            float(latest_live_result["base_equilibrium"]["recoverable_potential_energy_J_per_m"])
                            - float(marginal_live["base_equilibrium"]["recoverable_potential_energy_J_per_m"])
                        ) / float(arm.event_reward_m)
                    kinetic = max(float(marginal), 0.0)
                rate = preview_production_cleavage_rate(
                    engine, candidate, signed_J_J_per_m2=kinetic,
                    Eprime_Pa=float(mat.Eprime), temperature_K=float(args.temperatures[0]),
                )
                rows.append(replace(
                    rate, J_local_signed_J_per_m2=local_signed,
                    local_J_valid=local_valid, G_marginal_J_per_m2=marginal,
                    J_kin_used_J_per_m2=kinetic,
                    local_J_invalid_reason=observation.local_contour_invalid_reason,
                ))
                updated_observations.append(observation.with_kinetics(
                    kinetic_J_J_per_m2=kinetic,
                    marginal_J_J_per_m2=marginal,
                    directional_K_Pa_sqrt_m=rate.K_directional_Pa_sqrt_m,
                    rate_per_s=rate.lambda_per_s,
                ))
            latest_interval_rates = tuple(rows)
            latest_interval_observations = tuple(updated_observations)
            return latest_interval_rates

        trial_requests = {}; trial_live_results = {}; trial_clusters = {}; trial_drives = {}
        trial_observations = {}
        trial_realized_arm_lengths = {}

        def trial_action(current, proposal):
            nonlocal runtime, prebranch_snapshot_written, latest_live_result
            if proposal.action_type == "two_arm" and maximum_fronts == 1:
                return TopologyTrialResult(
                    False, current, proposal.action_id, 0.0, 0.0, 0.0,
                    "branching_disabled_matched_control",
                )
            if proposal.action_type == "two_arm" and not prebranch_snapshot_written:
                write_topology_snapshot(
                    out, current, step=step, reason="before_first_branch",
                    physical_extension_m=current.crack_network.total_physical_crack_length_m - cfg.geometry.a0,
                    branch_birth_count=int(current.event_counters.get("branch_birth_count", 0)),
                    latest_action=current.event_counters.get("latest_successful_action"),
                )
                prebranch_snapshot_written = True
            if runtime.routing.active_mechanics_provider == PREBRANCH_PROVIDER_ID:
                request0 = _request(current, candidates, args=args, cfg=cfg, runtime_step=step, cluster=None)
                runtime, live0 = runtime.transition(
                    step=step, state_hash=context.accepted_state_id,
                    legacy_result=last_measurement, request=request0,
                    protected_state=(current.competition, pickle.dumps(engine, protocol=5)),
                )
                latest_live_result = live0
                writer.provider_transition({
                    "step": step, "from_provider": PREBRANCH_PROVIDER_ID, "to_provider": PROVIDER_ID,
                    "state_hash": context.accepted_state_id, "topology_fingerprint": live0["topology_fingerprint"],
                    "parity_passed": True, "residuals": runtime.routing.transition_parity_results,
                })
            network0, trial_cluster, pairs = _realized_trial_network(current, proposal, candidates, da_phys, cluster)
            rate_by_id = {item.candidate_id: item for item in rates(current, context)}
            trial_observations[proposal.action_id] = latest_interval_observations
            if any(rate_by_id[cid].signed_J_J_per_m2 <= 0.0 for cid in proposal.member_candidate_ids):
                return TopologyTrialResult(False, current, proposal.action_id, 0.0, 0.0, 0.0, "nonpositive_signed_directional_J")
            arms = []
            for candidate, arm in pairs:
                drive = rate_by_id[candidate.candidate_id]
                _, _, barrier = engine.lambda_cleave(engine.sigma_tip(drive.K_directional_Pa_sqrt_m / math.sqrt(candidate.gamma_rel)), float(args.temperatures[0]))
                resistance = hazard_resistance_J_per_m2(
                    barrier_J=barrier, cooperative_hits=float(engine.f.m_hits),
                    burgers_vector_m=float(engine.b), gamma_relative=candidate.gamma_rel,
                )
                arms.append(replace(arm, hazard_dissipation_J_per_m=resistance * arm.event_reward_m))

            def geometry(trial_state, trial_arms):
                realized = network0
                for item in trial_arms:
                    realized = extend_network_arm(realized, item)
                trial_state = replace(
                    trial_state, crack_network=realized,
                    junction_process_state={
                        "crack_representation": "sharp_wake_causal_v11",
                        **({"cluster": trial_cluster} if trial_cluster else {}),
                    },
                )
                return apply_causal_sharp_wake_trial_geometry(trial_state, trial_arms)

            def equilibrate(trial_state):
                nonlocal runtime
                request = _request(trial_state, candidates, args=args, cfg=cfg, runtime_step=step, cluster=trial_cluster)
                runtime, live = runtime.evaluate_trial(request)
                trial_requests[proposal.action_id] = request; trial_clusters[proposal.action_id] = trial_cluster
                trial_live_results[proposal.action_id] = live
                trial_drives[proposal.action_id] = rate_by_id
                return replace(
                    trial_state,
                    displacement=np.asarray(live["base_equilibrium"]["displacement"]),
                    stored_energy_J_per_m=float(live["base_equilibrium"]["recoverable_potential_energy_J_per_m"]),
                )

            result = execute_topology_trial(
                current, proposal, tuple(arms), apply_trial_geometry=geometry,
                equilibrate_fixed_load=equilibrate, network_geometry_already_realized=True,
            )
            if result.accepted:
                trial_realized_arm_lengths[proposal.action_id] = realized_topology_arm_lengths(
                    current.crack_network,
                    result.state.crack_network,
                    proposal.member_candidate_ids,
                )
            return result

        shared_info = {}; shared_coupling = {}
        def update_shared(selected_state, _context, proposal):
            nonlocal runtime, cluster, shared_info, shared_coupling, engine
            observations = (
                trial_observations[proposal.action_id] if proposal is not None
                else latest_interval_observations
            )
            controlling = select_controlling_observation(observations)
            if latest_interval_pre_event_state is None:
                raise RuntimeError("shared update has no accepted pre-event state")
            pre_event_state = latest_interval_pre_event_state
            expected_pre_event_state_id = _hash((
                _context.accepted_state_id,
                pre_event_state.crack_network,
                pre_event_state.displacement,
                pre_event_state.ep_gp,
                pre_event_state.rho_gp,
            ))
            pre_topology_fingerprint = _hash(pre_event_state.crack_network)
            pre_progress = max(
                (hazard.residual_action for hazard in state.competition.hazard_states),
                default=0.0,
            )
            expected = proposal is not None
            target = max(
                float(getattr(args, "adaptive_event_target", 0.15) or 0.15) * 0.5,
                1.0e-6,
            )
            engine_trial, info = evolve_process_engine_v12_hook(
                engine, controlling, pre_event_state, latest_sigma,
                accepted_state_id=expected_pre_event_state_id,
                stress_field_state_id=latest_stress_field_state_id,
                pre_event_topology_fingerprint=pre_topology_fingerprint,
                duration_s=_context.duration_s,
                temperature_K=float(args.temperatures[0]),
                pre_progress=pre_progress,
                permitted_physical_hazard_action=target,
            )
            bound_drive = info.pop("explicit_accepted_tensor_drive")
            # The reusable process hook binds this exact controlling tip.
            # Keep diagnostic ownership local after the hook extraction.
            probe_tip_id = controlling.tip_id
            probe_tip = controlling.tip_xy_m
            info["directional_event_selected"] = expected
            info["directional_event_completion_time_s"] = (
                None if proposal is None else max(proposal.completion_times_s)
            )
            engine = engine_trial
            event_candidate_id, event_tip_id = selected_event_owner(
                proposal, observations
            )
            # The directional topology transaction, rather than the shared
            # engine's independent clock, owns this physical advance.
            realized_lengths = (
                () if proposal is None
                else trial_realized_arm_lengths.get(proposal.action_id, ())
            )
            renewal_distance = (
                0.0 if proposal is None
                else select_shared_process_renewal_distance(realized_lengths)
            )
            renewal = apply_post_interval_event_renewal(
                engine.mpz, info, event_selected=proposal is not None,
                event_distance_m=renewal_distance,
            )
            info["realized_arm_lengths_m"] = list(realized_lengths)
            info["realized_max_tip_advance_m"] = renewal_distance
            info["realized_total_new_crack_length_m"] = sum(realized_lengths)
            info["selected_renewal_distance_m"] = renewal_distance
            info["active_to_wake_transfer"] = float(
                renewal.get("wake_mobile", 0.0) + renewal.get("wake_retained", 0.0)
            )
            info["postrenewal_conservation_residual"] = float(
                info.get("event_moving_frame_conservation", {}).get(
                    "active_plus_wake_plus_sinks_residual", 0.0
                )
            )
            counters = dict(selected_state.event_counters)
            counters["shared_state_updates"] = counters.get("shared_state_updates", 0) + 1
            counters["accepted_steps"] = step
            ledgers = dict(selected_state.energy_ledgers)
            ledgers["retained"] = float(info.get("N_em", 0.0)); ledgers["emission_work"] = float(info.get("W_emit", engine.W_emit))
            shared_info = info
            selected_cluster = (
                trial_clusters.get(proposal.action_id) if proposal is not None
                else cluster
            )
            process_owner_id = (
                selected_cluster.cluster_id if selected_cluster is not None
                else controlling.tip_id
            )
            pre_event_state_id = controlling.accepted_state_id
            post_event_state_id = _hash((
                pre_event_state_id, selected_state.crack_network,
                selected_state.competition,
            ))
            shared_coupling = {
                "controlling_candidate_id": controlling.candidate_id,
                "controlling_scalar_K_tip_id": controlling.tip_id,
                "tensor_probe_tip_id": probe_tip_id,
                "selected_event_candidate_id": event_candidate_id,
                "selected_event_tip_id": event_tip_id,
                "process_owner_id": process_owner_id,
                "pre_event_state_id": pre_event_state_id,
                "post_event_state_id": post_event_state_id,
                "pre_event_topology_fingerprint": controlling.topology_fingerprint,
                "post_event_topology_fingerprint": _hash(selected_state.crack_network),
                "stress_field_state_fingerprint": latest_stress_field_state_id,
                "explicit_accepted_tensor_drive": bound_drive,
                "tensor_sample_coordinates_m": list(probe_tip),
                "observations": observations,
            }
            if proposal is not None:
                runtime = runtime.accept_trial(
                    trial_requests[proposal.action_id],
                    trial_live_results[proposal.action_id],
                )
                cluster = trial_clusters[proposal.action_id]
                if cluster is not None and "birth_step" not in cluster.shared_process_state:
                    cluster = replace(cluster, shared_process_state={
                        **cluster.shared_process_state,
                        "birth_step": int(step),
                        "birth_extension_m": crack_growth_metrics(
                            selected_state.crack_network,
                            initial_crack_length_m=cfg.geometry.a0,
                        ).max_root_to_tip_path_extension_m,
                    })
            return replace(
                selected_state, event_counters=counters, energy_ledgers=ledgers,
                tip_process_state={
                    "shared_engine_model": type(engine).__name__, "B": float(engine.B),
                    "N_em": float(engine.N_em), "W_emit": float(engine.W_emit), "time_s": float(engine.t),
                },
            )

        while True:
            context = replace(context, duration_s=float(args.dt) * trial_fraction)
            try:
                result = advance_accepted_step(
                    state, context, correlation_interval_s=float(engine.f.tau_c),
                    solve_accepted=solve_accepted, evaluate_directional_rates=rates,
                    trial_action=trial_action,
                    update_shared_state_once=update_shared,
                    maximum_directional_action_increment=float(getattr(args, "adaptive_event_target", 0.15) or 0.15),
                )
                break
            except DirectionalStepRefinementRequired as exc:
                if exc.predicted_increment is None or exc.predicted_increment <= 0.0:
                    raise RuntimeError(
                        "v11 process update requested refinement without a positive "
                        "physical hazard action"
                    ) from exc
                shrink = 0.7 * exc.target_increment / exc.predicted_increment
                next_fraction = max(float(getattr(args, "adaptive_min_frac", 1.0e-8)), trial_fraction * min(0.5, shrink))
                if next_fraction >= trial_fraction or next_fraction <= float(getattr(args, "adaptive_min_frac", 1.0e-8)):
                    raise RuntimeError("v11 directional adaptive stepping reached its minimum fraction") from exc
                trial_fraction = next_fraction
        state = result.state
        accepted_load += float(args.dU) * trial_fraction
        physical_time += context.duration_s
        with (out / "directional_rates.jsonl").open("a", encoding="utf-8") as stream:
            hazard_by_candidate = {
                item.candidate_id: item for item in state.competition.hazard_states
            }
            for rate in result.rates:
                hazard = hazard_by_candidate[rate.candidate_id]
                observation = next(
                    item for item in shared_coupling["observations"]
                    if item.candidate_id == rate.candidate_id
                )
                ownership = serialize_directional_observation(
                    observation,
                    controlling_scalar_K_tip_id=shared_coupling["controlling_scalar_K_tip_id"],
                    tensor_probe_tip_id=shared_coupling["tensor_probe_tip_id"],
                    selected_event_tip_id=shared_coupling["selected_event_tip_id"],
                    process_owner_id=shared_coupling["process_owner_id"],
                    pre_event_state_id=shared_coupling["pre_event_state_id"],
                    post_event_state_id=shared_coupling["post_event_state_id"],
                )
                stream.write(json.dumps({
                    "step": step, "physical_time_s": physical_time,
                    "accepted_state_id": context.accepted_state_id,
                    **ownership,
                    "controlling_scalar_K_candidate_id": shared_coupling["controlling_candidate_id"],
                    "selected_event_candidate_id": shared_coupling["selected_event_candidate_id"],
                    "pre_event_topology_fingerprint": shared_coupling["pre_event_topology_fingerprint"],
                    "post_event_topology_fingerprint": shared_coupling["post_event_topology_fingerprint"],
                    "stress_field_state_fingerprint": shared_coupling["stress_field_state_fingerprint"],
                    "tensor_sample_coordinates_m": shared_coupling["tensor_sample_coordinates_m"],
                    "J_local_signed_J_per_m2": rate.J_local_signed_J_per_m2,
                    "local_J_valid": rate.local_J_valid,
                    "local_J_invalid_reason": rate.local_J_invalid_reason,
                    "G_marginal_J_per_m2": rate.G_marginal_J_per_m2,
                    "J_kin_used_J_per_m2": rate.J_kin_used_J_per_m2,
                    "lambda_directional_per_s": rate.lambda_per_s,
                    "accumulated_integrated_hazard_H": hazard.action,
                    "current_threshold_H_star": hazard.current_threshold_action,
                    "directional_event_ordinal": hazard.completed_event_count + 1,
                    "pending_event_ids": [item.event_id for item in hazard.pending_events],
                }, sort_keys=True, allow_nan=False) + "\n")
        selected = next((item for item in result.trials if item.selected), None)
        if selected is not None:
            adaptation_required = True
        for item in result.trials:
            rate_map = trial_drives.get(item.proposal.action_id, {r.candidate_id: r for r in result.rates})
            rec = {field: None for field in TRIAL_FIELDS}
            post_energy = item.result.state.stored_energy_J_per_m
            pre_energy = post_energy + item.result.energy_release_J_per_m
            arm_count = len(item.proposal.member_candidate_ids)
            participating = []
            request_for_trial = trial_requests.get(item.proposal.action_id)
            if request_for_trial is not None:
                participating = list(request_for_trial.crack_network.active_tip_ids)
            before_equilibrium = (latest_live_result or {}).get("base_equilibrium", {})
            after_live = trial_live_results.get(item.proposal.action_id)
            after_equilibrium = {} if after_live is None else after_live.get("base_equilibrium", {})
            reaction_before = before_equilibrium.get("reaction_force")
            reaction_after = after_equilibrium.get("reaction_force")

            def apparent_compliance(reaction):
                from .topology_transaction_v11 import REACTION_ABSOLUTE_FLOOR_N_PER_M
                if reaction is None or not math.isfinite(float(reaction)) or abs(float(reaction)) <= REACTION_ABSOLUTE_FLOOR_N_PER_M:
                    return None
                return float(accepted_load) / abs(float(reaction))

            rec.update({
                "step": step, "physical_time_s": physical_time, "accepted_state_id": context.accepted_state_id,
                "trial_id": item.proposal.action_id, "action_type": item.proposal.action_type,
                "participating_front_ids": participating,
                "candidate_ids": list(item.proposal.member_candidate_ids), "pending_event_ids": list(item.proposal.member_event_ids),
                "completion_times_s": list(item.proposal.completion_times_s),
                "correlation_time_difference_s": max(item.proposal.completion_times_s) - min(item.proposal.completion_times_s),
                "signed_directional_J_J_per_m2": [rate_map[c].signed_J_J_per_m2 for c in item.proposal.member_candidate_ids],
                "positive_directional_J_J_per_m2": [rate_map[c].positive_J_J_per_m2 for c in item.proposal.member_candidate_ids],
                "directional_K_Pa_sqrt_m": [rate_map[c].K_directional_Pa_sqrt_m for c in item.proposal.member_candidate_ids],
                "J_local_signed_J_per_m2": [rate_map[c].J_local_signed_J_per_m2 for c in item.proposal.member_candidate_ids],
                "local_J_valid": [rate_map[c].local_J_valid for c in item.proposal.member_candidate_ids],
                "local_J_invalid_reason": [rate_map[c].local_J_invalid_reason for c in item.proposal.member_candidate_ids],
                "G_marginal_J_per_m2": [rate_map[c].G_marginal_J_per_m2 for c in item.proposal.member_candidate_ids],
                "J_kin_used_J_per_m2": [rate_map[c].J_kin_used_J_per_m2 for c in item.proposal.member_candidate_ids],
                "lambda_directional_per_s": [rate_map[c].lambda_per_s for c in item.proposal.member_candidate_ids],
                "applied_displacement_m": float(accepted_load),
                "reaction_force_before_N_per_m": reaction_before,
                "reaction_force_after_N_per_m": reaction_after,
                "apparent_compliance_before_m2_per_N": apparent_compliance(reaction_before),
                "apparent_compliance_after_m2_per_N": apparent_compliance(reaction_after),
                "topology_fingerprint_before": (latest_live_result or {}).get("topology_fingerprint"),
                "topology_fingerprint_after": None if after_live is None else after_live.get("topology_fingerprint"),
                "proposed_arm_lengths_m": [da_phys] * arm_count,
                "realized_arm_lengths_m": [da_phys] * arm_count if item.result.accepted else [0.0] * arm_count,
                "pretrial_potential_energy_J_per_m": pre_energy,
                "posttrial_potential_energy_J_per_m": post_energy,
                "released_energy_J_per_m": item.result.energy_release_J_per_m,
                "hazard_derived_cost_per_arm_J_per_m": [
                    item.result.hazard_dissipation_J_per_m / arm_count
                ] * arm_count,
                "total_dissipative_cost_J_per_m": item.result.hazard_dissipation_J_per_m,
                "net_energy_margin_J_per_m": item.result.energy_margin_J_per_m,
                "relative_energy_residual": item.result.energy_margin_J_per_m / max(
                    abs(pre_energy), abs(post_energy), item.result.hazard_dissipation_J_per_m, 1.0e-300
                ),
                "geometry_status": "realized" if item.result.accepted else "rolled_back",
                "equilibrium_status": "converged" if item.result.accepted else "trial_vetoed",
                "provider_identity": runtime.routing.active_mechanics_provider,
                "accepted": item.selected, "veto_reason": None if item.selected else item.result.rejection_reason,
                "reservation_result": "accepted" if item.selected else "released",
                "consumption_result": "consumed" if item.selected else "preserved",
                "pretrial_state_hash": context.accepted_state_id,
                "postrollback_state_hash": (
                    None if item.result.accepted else context.accepted_state_id
                ),
                "trial_copy_bytes": item.result.trial_copy_bytes,
                "trial_copy_wall_time_s": item.result.trial_copy_wall_time_s,
            })
            writer.append_trial(rec)
        if selected is not None and selected.proposal.action_type == "two_arm" and cluster is not None:
            arm_branches = tuple(state.crack_network.branch(item) for item in cluster.arm_branch_ids)
            event = {field: None for field in BRANCH_EVENT_FIELDS}
            event.update({
                "event_record_id": selected.proposal.action_id, "step": step,
                "branch_junction": list(cluster.junction_xy_m), "parent_front": cluster.parent_branch_id,
                "arm_front_ids": list(cluster.arm_branch_ids),
                "arm_directions": [branch.current_orientation_rad for branch in arm_branches],
                "plane_identities": list(selected.proposal.member_candidate_ids),
                "event_ids_consumed": list(selected.proposal.member_event_ids),
                "completion_time_difference_s": max(selected.proposal.completion_times_s) - min(selected.proposal.completion_times_s),
                "arm_lengths_m": [sum(math.dist(a, b) for a, b in zip(branch.path, branch.path[1:])) for branch in arm_branches],
                "tip_positions_m": [list(branch.tip) for branch in arm_branches],
                "tip_separation_m": math.dist(arm_branches[0].tip, arm_branches[1].tip),
                "shared_cluster_id": cluster.cluster_id,
                "shared_cluster_state_hash": _hash((engine.B, engine.N_em, engine.W_emit)),
                "topology_fingerprint": runtime.routing.topology_fingerprint,
                "released_energy_J_per_m": selected.result.energy_release_J_per_m,
                "total_cost_J_per_m": selected.result.hazard_dissipation_J_per_m,
                "energy_margin_J_per_m": selected.result.energy_margin_J_per_m,
            })
            writer.branch_event(event)
            counters = dict(state.event_counters)
            counters["branch_birth_count"] = counters.get("branch_birth_count", 0) + 1
            counters["latest_successful_action"] = selected.proposal.action_id
            state = replace(state, event_counters=counters)
            write_topology_snapshot(
                out, state, step=step, reason="branch_birth",
                physical_extension_m=state.crack_network.total_physical_crack_length_m - cfg.geometry.a0,
                branch_birth_count=counters["branch_birth_count"],
                latest_action=selected.proposal.action_id,
                mechanics={
                    "energy_summary": {
                        "released_J_per_m": selected.result.energy_release_J_per_m,
                        "cost_J_per_m": selected.result.hazard_dissipation_J_per_m,
                        "margin_J_per_m": selected.result.energy_margin_J_per_m,
                    }
                },
            )
        writer.energy({
            "step": step, "accepted_state_id": context.accepted_state_id,
            "stored_energy_J_per_m": state.stored_energy_J_per_m,
            "released_energy_J_per_m": selected.result.energy_release_J_per_m if selected else 0.0,
            "dissipative_cost_J_per_m": selected.result.hazard_dissipation_J_per_m if selected else 0.0,
            "residual_J_per_m": selected.result.energy_margin_J_per_m if selected else 0.0,
        })
        for branch in state.crack_network.branches:
            writer.front({
                "step": step, "front_id": branch.branch_id, "parent_front_id": branch.parent_branch_id,
                "status": branch.status, "termination_reason": branch.local_state.get("termination_reason"),
                "tip_x_m": branch.tip[0], "tip_y_m": branch.tip[1],
                "arclength_m": sum(math.dist(a, b) for a, b in zip(branch.path, branch.path[1:])),
            })
        guard = None
        if cluster is not None:
            accepted_live = (
                trial_live_results.get(selected.proposal.action_id)
                if selected is not None else latest_live_result
            )
            live_tips = tuple((accepted_live or {}).get("tips", ()))
            independently_valid = tuple(
                any(
                    np.allclose(item.get("tip_xy_m", ()), state.crack_network.branch(branch_id).tip)
                    and bool(item.get("directional"))
                    and all(bool(direction.get("local_contour_valid", False)) for direction in item["directional"])
                    for item in live_tips
                )
                for branch_id in cluster.arm_branch_ids
            )
            guard = evaluate_unresolved_cluster_guard(
                state.crack_network, cluster,
                branch_handoff_length_m=scale_identity.branch_handoff_length_m,
                local_J_contour_radius_m=selected_local_J_contour_radius(
                    accepted_live, scale_identity.local_J_contour_radius_m,
                ),
                independently_valid_local_J=independently_valid,
            )
            current_scales = scale_identity.with_local_measurements(
                J_contour_radius_m=guard.local_J_contour_radius_m,
                hbar_m=float(getattr(state.mesh, "hbar_tip", 0.0) or state.mesh.hbar),
            )
            writer.cluster({
                "step": step, "cluster_id": cluster.cluster_id,
                "parent_tip": cluster.parent_branch_id,
                "birth_step": cluster.shared_process_state.get("birth_step"),
                "birth_extension_m": cluster.shared_process_state.get("birth_extension_m"),
                "arm_ids": list(cluster.arm_branch_ids),
                "arm_lengths_m": list(guard.arm_arclengths_from_junction_m),
                "unresolved": cluster.unresolved,
                "tip_separation_m": guard.tip_separation_m,
                "process_owner_id": cluster.cluster_id,
                "sufficient_post_junction_length": list(guard.sufficient_post_junction_length),
                "separation_reaches_process_zone": guard.separation_reaches_process_zone,
                "local_contours_overlap": guard.local_contours_overlap,
                "independently_valid_local_J": list(guard.independently_valid_local_J),
                "handoff_required": guard.handoff_required,
                "handoff_step": step if guard.handoff_required else None,
                "junction_reservoir_id": f"reservoir:{cluster.cluster_id}" if guard.handoff_required else None,
                "resolved_tip_engine_ids": list(cluster.arm_branch_ids) if guard.handoff_required else [],
                **{key: current_scales.to_dict()[key] for key in (
                    "physical_process_zone_length_m", "branch_handoff_length_m",
                    "local_J_contour_radius_m", "interaction_integral_length_m",
                    "tip_h_fine_m", "actual_local_hbar_m", "event_length_da_phys_m",
                )},
            })
        checkpoint = ProductionBranchCheckpoint(
            state=state, shared_process_state=_capture_shared_engine(engine),
            physical_time_s=physical_time, accepted_load=accepted_load,
            mesh_identity=_mesh_identity(state.mesh), boundary_condition_state={"opening_m": accepted_load},
            provider_runtime=runtime, provider_cache_identity=str(cache_root.resolve()),
            topology_fingerprint=runtime.routing.topology_fingerprint or _hash(state.crack_network),
            front_competitions={tip: state.competition for tip in state.crack_network.active_tip_ids},
            branch_clusters=(() if cluster is None else (cluster,)),
            projected_extension_m=max(branch.tip[0] for branch in state.crack_network.branches) - cfg.geometry.a0,
            physical_extension_m=state.crack_network.total_physical_crack_length_m - cfg.geometry.a0,
            handoff_guard_diagnostics=(
                {"scale_identity": scale_identity.to_dict()} if guard is None else
                {**guard.to_dict(), "scale_identity": current_scales.to_dict()}
            ),
            termination_reason=None,
        )
        checkpoint_path = out / "checkpoint" / "latest.json"
        write_branch_checkpoint(checkpoint, checkpoint_path)
        if parent_capture is not None and parent_capture.accept(
            checkpoint=checkpoint, context=context, result=result,
            solved_pre_event=latest_interval_pre_event_state,
            pre_event_sigma=latest_sigma, args=args, cfg=cfg,
        ):
            termination = "v13_first_baseline_cleavage_captured"
            break
        if inherited_primary_race and cluster is None and selected is not None:
            from .primary_race_production_v13 import evaluate_production_mark
            if selected.proposal.action_type != "one_arm" or maximum_fronts != 1:
                raise RuntimeError("V13 requires the unchanged branch-disabled canonical parent")
            marked = evaluate_production_mark(
                checkpoint=checkpoint, selected=selected,
                solved_pre_event=latest_interval_pre_event_state, engine=engine,
                args=args, cfg=cfg, context=context,
                accepted_live=trial_live_results[selected.proposal.action_id],
            )
            with (out / "v13_primary_race.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(marked.record, sort_keys=True, allow_nan=False) + "\n")
            if marked.state is not state:
                # Mark bookkeeping is separate from untouched baseline counters.
                write_branch_checkpoint(checkpoint, out / "v13_branch/canonical_single.json")
                state, cluster, runtime = marked.state, marked.cluster, marked.runtime
                maximum_fronts = 2
                growth = crack_growth_metrics(state.crack_network, initial_crack_length_m=cfg.geometry.a0)
                checkpoint = replace(checkpoint, state=state, provider_runtime=runtime,
                    topology_fingerprint=runtime.routing.topology_fingerprint,
                    front_competitions={tip:state.competition for tip in state.crack_network.active_tip_ids},
                    branch_clusters=(cluster,), projected_extension_m=growth.max_forward_projected_extension_m,
                    physical_extension_m=state.crack_network.total_physical_crack_length_m-cfg.geometry.a0)
                write_branch_checkpoint(checkpoint, out / "v13_branch/accepted_pair.json")
                write_branch_checkpoint(checkpoint, checkpoint_path)
                write_topology_snapshot(out, state, step=step, reason="v13_conditional_branch_birth",
                    physical_extension_m=checkpoint.physical_extension_m, branch_birth_count=1,
                    latest_action=selected.proposal.action_id)
                adaptation_required = True
                if checkpoint.projected_extension_m >= float(getattr(args, "target_crack_extension_um", float("inf"))) * 1e-6:
                    termination = "target_reached"
                    break
                continue
        daughter_stop_m = float(
            os.environ.get("PF_QUALIFIED_DAUGHTER_STOP_UM", "inf")
        ) * 1.0e-6
        daughter_lengths = [
            sum(math.dist(a, b) for a, b in zip(branch.path, branch.path[1:]))
            for branch in state.crack_network.branches
            if branch.generation > 0 and branch.status == "active"
        ]
        if daughter_lengths and max(daughter_lengths) >= daughter_stop_m:
            termination = "qualified_daughter_early_stop"
            break
        if guard is not None and guard.handoff_required:
            from .resolved_production_v11 import continue_resolved_production
            return continue_resolved_production(
                args=args, cfg=cfg, state=state, shared_engine=engine,
                runtime=runtime, cluster=cluster, candidates=candidates,
                writer=writer, out=out, cache_root=cache_root,
                physical_time=physical_time, accepted_load=accepted_load,
                start_step=step + 1, engine_factory=lambda: base.build_engine(args, mat),
            )
        growth = crack_growth_metrics(
            state.crack_network, initial_crack_length_m=cfg.geometry.a0,
        )
        extension = growth.max_forward_projected_extension_m
        target = float(getattr(args, "target_crack_extension_um", float("inf"))) * 1e-6
        if extension >= target:
            termination = "target_reached"; break

    termination = termination or "physical_veto_no_branch"
    checkpoint = replace(checkpoint, termination_reason=termination)
    write_branch_checkpoint(checkpoint, out / "checkpoint" / "latest.json")
    final_growth = crack_growth_metrics(
        state.crack_network, initial_crack_length_m=cfg.geometry.a0,
    )
    write_topology_snapshot(
        out, state, step=int(state.event_counters.get("accepted_steps", 0)),
        reason=termination, physical_extension_m=checkpoint.physical_extension_m,
        branch_birth_count=int(state.event_counters.get("branch_birth_count", 0)),
        latest_action=state.event_counters.get("latest_successful_action"),
        growth_metrics=final_growth.to_dict_um(), final=True,
    )
    writer.complete(status=termination, final_checkpoint="checkpoint/latest.json", validation={
        "checkpoint": True, "shared_state_updates": state.event_counters.get("shared_state_updates", 0),
        "topology_actions": state.event_counters.get("topology_actions", 0),
        "provider_transition": runtime.routing.transition_step is not None,
        "live_fem_solve_count": runtime.live_fem_solve_count,
        "accepted_provider_state_count": runtime.accepted_provider_state_count,
    })
    return 0


def _remove_flag_with_value(args, name):
    result = []; index = 0
    while index < len(args):
        token = args[index]
        if token == name:
            index += 2; continue
        if token.startswith(name + "="):
            index += 1; continue
        result.append(token); index += 1
    return result


def main(argv=None, *, audit_already_written=False):
    from . import sharp_front as base
    from . import sharp_front_v10_2_28_audited as entry
    from . import sharp_front_v10_1_7_3 as avalanche_entry
    args = list(sys.argv[1:] if argv is None else argv)
    restart = None
    for index, token in enumerate(args):
        if token.startswith("--v11-restart-checkpoint="):
            restart = token.split("=", 1)[1]
        elif token == "--v11-restart-checkpoint" and index + 1 < len(args):
            restart = args[index + 1]
    for flag in ("--mechanistic-branching", "--audit-only"):
        args = [item for item in args if item != flag]
    maximum_fronts = 2
    for index, token in enumerate(args):
        if token.startswith("--maximum-fronts="):
            maximum_fronts = int(token.split("=", 1)[1])
        elif token == "--maximum-fronts" and index + 1 < len(args):
            maximum_fronts = int(args[index + 1])
    args = _remove_flag_with_value(args, "--maximum-fronts")
    args = _remove_flag_with_value(args, "--hazard-seed")
    args = _remove_flag_with_value(args, "--v11-restart-checkpoint")
    args.extend(["--max-fronts", "1"])
    original = base.run_2d
    original_geometry_diagnostics = avalanche_entry._write_geometry_diagnostics
    old_restart = os.environ.get("V11_BRANCH_RESTART_CHECKPOINT")
    old_maximum_fronts = os.environ.get("PF_CURRENT_SOURCE_MAX_FRONTS")
    old_maximum_births = os.environ.get("PF_CURRENT_SOURCE_MAX_BRANCH_BIRTHS")
    os.environ["PF_CURRENT_SOURCE_MAX_FRONTS"] = str(maximum_fronts)
    os.environ["PF_CURRENT_SOURCE_MAX_BRANCH_BIRTHS"] = str(max(maximum_fronts - 1, 0))
    if restart:
        os.environ["V11_BRANCH_RESTART_CHECKPOINT"] = restart
    inherited_primary_race = "--v13-inherited-primary-race" in args
    if inherited_primary_race:
        if maximum_fronts != 1 or restart:
            raise ValueError("V13 short gate requires a fresh canonical single-front parent")
        from functools import partial
        args.remove("--v13-inherited-primary-race")
        base.run_2d = partial(run_2d, inherited_primary_race=True)
    else:
        base.run_2d = run_2d
    # The v10 wrapper's post-run report is specific to its stochastic-avalanche
    # geometry backend, which this audited adapter intentionally never builds.
    avalanche_entry._write_geometry_diagnostics = lambda _args: None
    try:
        return entry.main(args)
    finally:
        base.run_2d = original
        avalanche_entry._write_geometry_diagnostics = original_geometry_diagnostics
        if old_restart is None:
            os.environ.pop("V11_BRANCH_RESTART_CHECKPOINT", None)
        else:
            os.environ["V11_BRANCH_RESTART_CHECKPOINT"] = old_restart
        if old_maximum_fronts is None:
            os.environ.pop("PF_CURRENT_SOURCE_MAX_FRONTS", None)
        else:
            os.environ["PF_CURRENT_SOURCE_MAX_FRONTS"] = old_maximum_fronts
        if old_maximum_births is None:
            os.environ.pop("PF_CURRENT_SOURCE_MAX_BRANCH_BIRTHS", None)
        else:
            os.environ["PF_CURRENT_SOURCE_MAX_BRANCH_BIRTHS"] = old_maximum_births


if __name__ == "__main__": main()


__all__ = ["MODEL_ID", "main", "run_2d"]
