AST ET AL. 2018 — EXPERIMENTAL DATA FOR JOINT MODEL FITTING
========================================================
Source: J. Ast et al., The brittle-ductile transition of tungsten single crystals
at the micro-scale, Materials & Design 152 (2018) 168–180.
DOI: https://doi.org/10.1016/j.matdes.2018.04.009
Version: open accepted manuscript, 35 PDF pages. See SOURCE.json for URL/hash.

CONTENTS
data/: CSV tables and curves; all_extracted_data.json contains equivalent typed
records. Empty CSV cells / JSON null denote unavailable data, never zero.
metadata/: experimental definitions, axis calibrations, curve registry, known
same-specimen links, coverage and a machine-readable fitting contract.
qa/: recovered points overlaid on original figure panels.
figures/: an overview reconstructed from the extracted values.
reproduction/: Python scripts, minimal source images and a verified PDF fetcher.
FIT_GUIDE.txt: how to combine these observations without mixing definitions or
inflating their independence. The companion Excel workbook is a readable view.

COVERAGE
31 temperature/rate conditions; 73 condition-total tests; 42 tabulated toughness
values (6 LEFM, 13 J-basic final cleavage, 23 J-continuous onset).
8 J–crack-extension curves (629 graphical samples), 18 nominal-K–displacement
curves (1,796 samples), 3 relative-stiffness curves (356 samples), and 2 A2 time
channels (473 samples). Figure5 has 58 records including 8 no-cleavage endpoints.
Four BDT assignments are derived from the same experimental campaign.
Eight per-example author-fit onset readouts are derived, not new specimens.

IMPORTANT DEFINITIONS
J is in N/m (= J/m²). Delta a is extension from the initial notch, not total a.
Continuous-J onset uses Delta a=0.2 µm. Final cleavage, this onset criterion and
initial-crack nominal K are separate observables, even where K units coincide.
The quoted loading-rate groups are initial elastic Kdot, while tests were
displacement-controlled. A2 supplies a representative changing nominal rate.
Figure2a traces are horizontally shifted in the source; recovered displacements
use an approximate displayed loading-origin reference for each trace.

SOURCE DISCREPANCIES
At rate 1.6 MPa√m/s, Table 1 onset K is 7.6 at 75°C and 5.8 at 100°C; Figure 5b
is approximately 8.9 and 7.6 respectively. Both are retained and explicitly flagged.
The table is the primary numerical transcription, not a verified correction of
the figure. No final publisher PDF was available to resolve the difference.
Do not average the alternatives or attach conflicting graph ranges to table means.

DEPENDENCE AND UNCERTAINTY
Table 1 and Figure 5 largely overlap. Figures 3a/b and 2a at 21, 100, 250°C and
rate 0.2 are explicitly linked specimens. Other specimen identities are unknown.
Figure 3 curves are individual examples, not necessarily Table 1 condition means.
Figure 5 error bars are min/max; original SD and subgroup sizes are unavailable.
Coordinate tolerances concern digitization, not experimental uncertainty.
Pixel sampling density does not create additional independent observations.
The visible trace is retained without constitutive fitting, smoothing, or imposed
monotonicity. Wide spans and negative crack-extension estimates are preserved.
J-trace row order is increasing-J raster order; original times are unavailable.
Figure2 graphical cleavage-drop connectors are flagged and not time-resolved data.

VALIDATION
Source table read and checked visually; axes and all labelled target curves
checked against native embedded images; overlays retained. Figure3 received an
independent review confirming all 629 points within 2 native pixels of their color
traces. IDs, row counts, ranges and source alternatives were checked. Numerical
precision in files supports reproducibility and is not a claim of measurement
accuracy. For reporting, retain source table precision (0.1 MPa√m) and sensible
rounded digitized values. No fitted activation barriers are claimed here.
