"""Read the eight author-fit Jq bars in Ast 2018 Fig.3; no curve refitting.

The horizontal bars are graphical evaluations of the authors' black power-law
fits at Delta a=200 nm, for the individually displayed curves. They are derived
readouts of those fits, not additional independent observations or Table1 means.
"""
from pathlib import Path
import csv
import json
import math
import numpy as np
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parent
CAL={"b":{"rate":0.2,"y0":358.,"y1":18.,"J1":1250.,"axis_x":106.5},
     "c":{"rate":0.5,"y0":358.,"y1":18.,"J1":1250.,"axis_x":106.5},
     "d":{"rate":1.6,"y0":358.,"y1":18.,"J1":600.,"axis_x":90.5}}
# Manually identified bar windows, checked visually against each arrow label.
# Panel, temperature, approximate y center, x-reading-window minimum/maximum.
BARS=[("b",250,248,98,118),("b",100,263,98,118),("b",21,296,98,118),
      ("c",250,264,96,118),("c",100,292,96,118),("c",21,301,96,118),
      ("d",100,286,79,99),("d",500,320,79,99)]

def main():
    table=list(csv.DictReader((ROOT.parent/"metadata_agent"/"table1.csv").open()))
    rows=[];meta=[];images={}
    for panel,T,yguess,xlo,xhi in BARS:
        if panel not in images:images[panel]=Image.open(ROOT/f"fig3{panel}_source.png").convert("RGB")
        image=images[panel];gray=np.asarray(image).astype(float).mean(2)
        yy=np.arange(yguess-3,yguess+4)
        darkness=(1-gray[yguess-3:yguess+4,xlo:xhi+1]/255).sum(1)
        # Remove the local narrow-axis background before finding the center of
        # the broad horizontal bar. Arrow/tick antialiasing is covered by +/-1 px.
        weights=np.maximum(darkness-float(np.min(darkness)),0)
        yc=float(np.dot(weights,yy)/weights.sum())
        s=CAL[panel]; scale=s["J1"]/(s["y0"]-s["y1"])
        J=(s["y0"]-yc)*scale
        condition=next(r for r in table if float(r["temperature_C"])==T and float(r["initial_elastic_Kdot_MPa_sqrt_m_per_s"])==s["rate"])
        E=float(condition["young_modulus_GPa"]);nu=float(condition["poisson_ratio"])
        K=lambda v:math.sqrt(v*E/(1000*(1-nu**2)))
        r={"curve_id":f"F3{panel}_T{T}_r{s['rate']:g}","figure_panel":"3"+panel,
          "temperature_C":T,"loading_rate_MPa_sqrt_m_per_s":s["rate"],
          "onset_crack_extension_nm":200,"source_pdf_page":13,
          "bar_reading_x_min_px":xlo,"bar_reading_x_max_px":xhi,
          "bar_reading_y_min_px":yguess-3,"bar_reading_y_max_px":yguess+3,
          "pixel_y_bar_center":round(yc,3),"bar_center_uncertainty_pm_px":1.0,
          "Jq_author_fit_N_per_m":round(J,3),"Jq_digitization_pm_N_per_m":round(scale,3),
          "young_modulus_GPa":E,"poisson_ratio":nu,
          "Kq_author_fit_derived_MPa_sqrt_m":round(K(J),4),
          "Kq_digitization_lower_MPa_sqrt_m":round(K(J-scale),4),
          "Kq_digitization_upper_MPa_sqrt_m":round(K(J+scale),4),
          "table1_condition_id":condition["condition_id"],
          "table1_mean_onset_K_MPa_sqrt_m":condition["Kq_Jcontinuous_onset_MPa_sqrt_m"],
          "derivation":"Kq=sqrt[Jq*E_GPa/(1000*(1-nu^2))]",
          "observation_kind":"derived_readout_of_author_fit_for_displayed_individual_curve",
          "is_independent_observation":False,
          "recommended_fit_use":"derived_check_only_do_not_add_as_independent_point_to_its_parent_curve"}
        rows.append(r)
        meta.append({"curve_id":r["curve_id"],"label_assignment":"Read from labeled Jq arrow to horizontal bar",
            "bar_center_method":"Darkness centroid after local axis-background subtraction in the stated seven-row window",
            "native_row_darkness":{str(int(y)):round(float(w),4) for y,w in zip(yy,darkness)}})
    with (ROOT/"example_curve_authorfit_onsets.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (ROOT/"example_curve_authorfit_onsets.json").write_text(json.dumps(rows,indent=2))
    md={"source_doi":"10.1016/j.matdes.2018.04.009","source":"Fig3b-d horizontal black Jq bars, accepted manuscript PDF page13/printedpage12",
        "count":len(rows),"calibration":CAL,"bar_measurements":meta,
        "physical_definition":"Author power-law fit evaluated at Delta a=200nm; critical J for onset of stable propagation under that convention",
        "not_new_independent_data":True,"not_table1_condition_means":True,
        "no_refitting_performed":True,
        "coordinate_uncertainty":"+/-1 native pixel for bar-center reading only. Includes finite stroke thickness/antialiasing; excludes experimental uncertainty, fit uncertainty, elastic-constant uncertainty and any additional axis-calibration error.",
        "K_conversion":"Same plane-strain J-to-K conversion as paper Eq6: E in GPa, J in N/m, K in MPa sqrt(m); K=sqrt[J E/(1000(1-nu^2))]. E and nu from Table1 at the same temperature.",
        "interpretation":["Use to check reproduction of the authors' onset convention for each displayed curve.",
          "Do not give these derived readouts independent statistical weight alongside their parent J-extension curve.",
          "The Table1 onset values are condition aggregates; these bars summarize individual representative curves and can differ from the condition mean.",
          "The negative/oscillatory raw crack-extension estimates do not redefine onset; the bars evaluate the authors' fitted curve at positive 200nm.",
          "The onset is not first dislocation emission, first deviation from elasticity, final cleavage, or a zero-crack-growth threshold."]}
    (ROOT/"example_curve_authorfit_onsets_metadata.json").write_text(json.dumps(md,indent=2))
    for panel,image in images.items():
        im=image.copy();draw=ImageDraw.Draw(im)
        for r in rows:
            if r["figure_panel"]!="3"+panel:continue
            y=r["pixel_y_bar_center"];lo=r["bar_reading_x_min_px"];hi=r["bar_reading_x_max_px"]
            draw.rectangle((lo-2,y-3,hi+2,y+3),outline=(0,160,230),width=1)
            draw.line((lo-1,y,hi+1,y),fill=(230,0,180),width=1)
        im.resize((im.width*2,im.height*2)).save(ROOT/f"example_onset_bar_overlay_3{panel}.png")
    print(json.dumps([{k:r[k] for k in ["curve_id","pixel_y_bar_center","Jq_author_fit_N_per_m","Kq_author_fit_derived_MPa_sqrt_m","table1_mean_onset_K_MPa_sqrt_m"]} for r in rows],indent=2))

if __name__=="__main__":main()
