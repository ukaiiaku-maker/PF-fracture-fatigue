"""Digitize visible Fig. 2 polylines from the native raster panels in Ast 2018.

The source PDF is an accepted manuscript of doi:10.1016/j.matdes.2018.04.009.
Coordinates are extracted from color-matched pixels, not generated from a fit.
Branch ranges were selected by inspecting each panel. No gap interpolation is
performed. Fig. 2a x offsets are arbitrary; its displacement is relative to an
estimated displayed loading origin. The native pixel coordinates are retained.
"""
from pathlib import Path
import csv
import argparse
import hashlib
import json
import math
import numpy as np
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parent
COLORS={"blue":(23,56,254),"sky":(0,164,254),"cyan":(0,205,205),
 "mint":(0,213,139),"green":(0,221,0),"lime":(164,230,48),
 "yellow":(230,172,40),"orange":(246,131,40),"red":(254,56,56),"red_c":(254,0,0)}
PANELS={
 "a":{"image":"fig2_image_0.png","rate":0.2,"x0":117.,"px_per_um":187.,"y0":542.5,"px_per_K":103.,"top":27.5,"right":884.5,
      "calibration":"Horizontal 1 micrometre bar: pixel 510 to 697. Vertical 0 to 5 MPa sqrt(m): y=542.5 to 27.5. Traces horizontally offset; absolute displacement unavailable."},
 "b":{"image":"fig2_image_1.png","rate":0.5,"x0":70.5,"px_per_um":422./3.5,"y0":357.5,"px_per_K":85.,"top":17.5,"right":492.5,
      "calibration":"Numeric displacement axis: 0 nm at x=70.5; 3500 nm at x=492.5. K=0 at y=357.5 and K=4 at y=17.5."},
 "c":{"image":"fig2_image_3.png","rate":1.6,"x0":70.5,"px_per_um":422./3.5,"y0":357.5,"px_per_K":85.,"top":17.5,"right":492.5,
      "calibration":"Numeric displacement axis: 0 nm at x=70.5; 3500 nm at x=492.5. K=0 at y=357.5 and K=4 at y=17.5."}}

# Branch descriptors: label, coordinate along which sampled, from, to, envelope,
# plus optional cross-coordinate band. 'upper' chooses the high-K centerline and
# 'lower' the low-K centerline, preserving distinct unloading/post-cleavage legs.
SPECS=[
 ("a",-90,"blue",135,[("loading","x",136,173,"upper")]),
 ("a",-55,"sky",189,[("loading","x",190,241,"upper")]),
 ("a",-25,"cyan",247,[("loading","x",248,331,"upper")]),
 ("a",0,"mint",324,[("loading","x",343,477,"upper")]),
 ("a",21,"green",324,[("loading","x",352,870,"upper"),("unloading","x",870,793,"lower")]),
 ("a",50,"lime",324,[("loading","x",337,859,"upper"),("unloading","x",859,763,"lower")]),
 ("a",100,"yellow",324,[("loading","x",328,859,"upper"),("unloading","x",859,760,"lower")]),
 ("a",150,"orange",324,[("loading","x",324,859,"upper"),("unloading","x",859,771,"lower")]),
 ("a",250,"red",324,[("loading","x",324,853,"upper"),("unloading","x",853,792,"lower")]),
 ("b",21,"green",70.5,[("loading","x",75,215,"upper"),("cleavage_drop","y",60,328,"center",(215,222)),
       ("post_cleavage_loading","x",221,315,"upper"),("unloading","x",315,251,"lower")]),
 ("b",50,"lime",70.5,[("loading","x",95,460,"upper"),("unloading","x",460,396,"lower")]),
 ("b",100,"yellow",70.5,[("loading","x",78,418,"upper"),("unloading","x",418,357,"lower")]),
 ("b",150,"orange",70.5,[("loading","x",73,417,"upper"),("unloading","x",417,357,"lower")]),
 ("b",250,"red",70.5,[("loading","x",72,446,"upper"),("unloading","x",446,400,"lower")]),
 ("c",21,"green",70.5,[("loading","x",75,153,"upper"),("cleavage_drop","y",65,346,"center",(154,161)),
       ("post_cleavage_loading","x",160,257,"upper"),("unloading","x",257,219,"lower")]),
 ("c",50,"lime",70.5,[("loading","x",76,188,"upper"),("cleavage_drop","y",50,318,"center",(189,196)),
       ("post_cleavage_loading","x",196,283,"upper"),("unloading","x",283,239,"lower")]),
 ("c",100,"yellow",70.5,[("loading","x",73,491,"upper"),("unloading","x",491,410,"lower")]),
 ("c",500,"red_c",70.5,[("loading","x",72,406,"upper"),("unloading","x",406,362,"lower")]),
]

# Narrow, manually inspected tail corridors distinguish a mostly overprinted
# loading segment from the same-colored unloading segment. These are selection
# guides only; no coordinates are emitted from the guides themselves.
TAIL_GUIDES={
 ("a",21):[(700,215),(750,248),(800,284),(835,310),(870,336)],
 ("a",50):[(700,256),(750,278),(800,301),(840,322),(860,334)],
 ("a",100):[(700,235),(750,255),(800,267),(825,275),(860,289)],
 ("b",50):[(370,133),(400,148),(430,165),(460,186)]}

def runs(v):
    """Contiguous pixel groups; each group must contain at least two pixels."""
    if len(v)==0:return []
    groups=np.split(v,np.flatnonzero(np.diff(v)>1)+1)
    return [g for g in groups if len(g)>=2]

def sample_branch(mask,panel,desc,guide=None):
    label,axis,begin,end,envelope,*extra=desc
    sign=1 if end>=begin else -1
    samples=list(range(round(begin),round(end)+sign,4*sign))
    if samples[-1]!=round(end):samples.append(round(end))
    out=[]
    for u in samples:
        if axis=="x":
            v=np.where(mask[:,u])[0]
            v=v[(v>panel["top"]+1)&(v<panel["y0"]-2)]
        else:
            v=np.where(mask[u,:])[0]
            lo,hi=extra[0]
            v=v[(v>=lo)&(v<=hi)]
        groups=runs(v)
        if not groups:continue
        if envelope=="upper":g=groups[0]
        elif envelope=="lower":g=groups[-1]
        else:g=max(groups,key=len)
        c=float(np.median(g))
        x,y=(float(u),c) if axis=="x" else (c,float(u))
        if label=="loading" and guide and x>=guide[0][0]:
            expected=float(np.interp(x,[p[0] for p in guide],[p[1] for p in guide]))
            if abs(y-expected)>12:continue
        if label=="unloading" and out and y<out[-1][1]-4:
            # The lower envelope has disappeared behind another trace. A
            # surviving loading/post-cleavage branch must not replace it.
            continue
        out.append((x,y,0.5*float(g[-1]-g[0]),axis))
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf",type=Path,default=ROOT.parent/"source"/"Ast_2018_accepted.pdf")
    args=parser.parse_args()
    if any(not (ROOT/p["image"]).exists() for p in PANELS.values()):
        import fitz
        doc=fitz.open(args.pdf)
        embedded=doc[11].get_images()
        for key,index in [("a",0),("b",1),("c",3)]:
            content=doc.extract_image(embedded[index][0])
            (ROOT/PANELS[key]["image"]).write_bytes(content["image"])
    images={key:np.asarray(Image.open(ROOT/p["image"]).convert("RGB")).astype(float) for key,p in PANELS.items()}
    rows=[]; curves=[]
    overlays={k:Image.open(ROOT/p["image"]).convert("RGB") for k,p in PANELS.items()}
    for panel,temp,color,origin,branches in SPECS:
        p=PANELS[panel]; rgb=COLORS[color]
        mask=np.linalg.norm(images[panel]-np.asarray(rgb),axis=2)<20
        curve_id=f"Ast2018_F2{panel}_T{temp:+d}_rate{p['rate']:g}".replace("+","")
        seq=0;branch_meta=[]
        for branch_no,desc in enumerate(branches):
            pts=sample_branch(mask,p,desc,TAIL_GUIDES.get((panel,temp)))
            branch_meta.append({"branch":desc[0],"samples":len(pts),"pixel_selection":desc})
            draw=ImageDraw.Draw(overlays[panel])
            for x,y,width,axis in pts:
                seq+=1
                dx=(x-origin)/p["px_per_um"]
                dy=(p["y0"]-y)/p["px_per_K"]
                rows.append({"curve_id":curve_id,"figure":f"2{panel}","temperature_C":temp,
                  "rate_MPa_sqrt_m_per_s":p["rate"],"sequence_index":seq,"branch_index":branch_no,
                  "branch":desc[0],"displacement_um":round(dx,6),"K_MPa_sqrt_m":round(dy,6),
                  "pixel_x":round(x,3),"pixel_y":round(y,3),
                  "panel_coordinate_um":round((x-p["x0"])/p["px_per_um"],6),
                  "displayed_loading_origin_px":origin,
                  "displacement_reference":"relative_to_displayed_loading_origin" if panel=="a" else "numeric_published_axis",
                  "digitization_x_pixel_um":round(1/p["px_per_um"],8),
                  "digitization_y_pixel_MPa_sqrt_m":round(1/p["px_per_K"],8),
                  "pixel_run_halfwidth":width,"sample_direction":axis,
                  "method":"native_raster_color_mask_centerline","source_pdf_page":12,
                  "measurement_kind":"apparent_LEFM_K_initial_crack_length",
                  "fit_role":"loading_history_candidate" if desc[0]=="loading" else ("event_connector_not_time_resolved" if desc[0]=="cleavage_drop" else "post_event_or_unloading_history"),
                  "is_independent_specimen":False,"is_raw_machine_data":False})
                draw.ellipse((x-1.5,y-1.5,x+1.5,y+1.5),fill="black",outline="white",width=1)
        curves.append({"curve_id":curve_id,"figure":f"2{panel}","temperature_C":temp,"rate_MPa_sqrt_m_per_s":p["rate"],
          "color_rgb":rgb,"displayed_loading_origin_px":origin,"branches":branch_meta,
          "notes":"Visible portions only. Lower-load portions can be overprinted by other colors. Sampling is chronological by labeled loading, drop, post-cleavage and unloading branches; no time axis is supplied."})
    with (ROOT/"fig2_curves.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (ROOT/"fig2_curves.json").write_text(json.dumps(rows,indent=2))
    metadata={"source_title":"The brittle-ductile transition of tungsten single crystals at the micro-scale",
      "doi":"10.1016/j.matdes.2018.04.009","source_pdf":"Ast_2018_accepted.pdf","pdf_page":12,"printed_page":11,
      "source_pdf_sha256":hashlib.sha256(args.pdf.read_bytes()).hexdigest(),
      "panels":PANELS,"curves":curves,"curve_count":len(curves),"point_count":len(rows),"loading_tail_selection_guides":{f"{k[0]}_{k[1]}":v for k,v in TAIL_GUIDES.items()},
      "calibration_uncertainty":"Panel a 1-um bar endpoints estimated to 1 native pixel each; x scale about 0.8% worst-case error. Axis and color centerline locations about 1-2 native pixels; these are digitization uncertainties, not experimental confidence intervals.",
      "important_interpretation":[
       "Fig.2 K is computed using the initial crack length and an LEFM conversion. It is not corrected for crack extension or plasticity and is not the J-equivalent toughness in Table 1.",
       "Fig.2a traces have display offsets. No absolute displacement zero is available. displacement_um subtracts the assigned displayed loading origin; panel_coordinate_um preserves the unshifted graphical coordinate.",
       "For Fig.2a 0 C and higher, overlapping lower-load branches obscure some origins/initial segments. The common displayed origin near pixel 324 is an alignment estimate, not an independent measurement.",
       "Fig.2b,c displacement_um is the published numeric displacement axis in micrometres. Negative/near-zero load baselines are omitted.",
       "Unloading and vertical cleavage drops are included as separately labeled branches. Samples on a curve are correlated graphical samples, not independent specimens.",
       "The vertical cleavage-drop line is a graphical connection, without time resolution; use its endpoints/event interpretation rather than treating its sampled points as separate timed observations.",
       "At color crossings a trace may be occluded. The script skips columns with no qualifying colored run and performs no gap interpolation.",
       "Tail corridors and monotonic unloading direction are used only to select the correct visible branch at overlaps. Coordinates are always color-pixel centers; selection guides do not generate data.",
       "The Fig.3 caption explicitly links its panels a/b to the same three Fig.2a tests at 21, 100 and 250 C, rate 0.2. Those K-displacement, stiffness and J-extension curves are correlated observations of the same specimens. Other figure-to-specimen links and links to Table 1 aggregate values are not uniquely identified.",
       "Full cleavage crosses in Fig.2a occur at -90,-55,-25 and 0 C. Approximate marker coordinates are recorded separately. No additional plastic-onset K is inferred from a subjective tangent construction."
      ]}
    (ROOT/"fig2_metadata.json").write_text(json.dumps(metadata,indent=2))
    markers=[]
    for temp,x,y in [(-90,173,207),(-55,241,159),(-25,334,131),(0,480,143)]:
        p=PANELS["a"];origin=next(s[3] for s in SPECS if s[0]=="a" and s[1]==temp)
        markers.append({"figure":"2a","temperature_C":temp,"rate_MPa_sqrt_m_per_s":0.2,
          "event":"complete_cleavage_plus_marker","pixel_x":x,"pixel_y":y,
          "displacement_relative_um":round((x-origin)/p["px_per_um"],5),
          "apparent_K_MPa_sqrt_m":round((p["y0"]-y)/p["px_per_K"],5),
          "digitization_uncertainty_K_MPa_sqrt_m":round(2/p["px_per_K"],5),
          "definition":"K calculated using initial crack length and LEFM; not J-based final-cleavage K"})
    with (ROOT/"fig2_cleavage_markers.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(markers[0]));w.writeheader();w.writerows(markers)
    for k,img in overlays.items():img.save(ROOT/f"fig2{k}_digitization_overlay.png")
    print(json.dumps({"curves":len(curves),"points":len(rows),"by_curve":{c["curve_id"]:sum(b["samples"] for b in c["branches"]) for c in curves}},indent=2))

if __name__=="__main__":main()
