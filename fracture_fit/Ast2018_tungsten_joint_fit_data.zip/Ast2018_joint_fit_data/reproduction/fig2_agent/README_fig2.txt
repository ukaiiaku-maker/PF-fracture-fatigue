Ast et al. (2018), DOI 10.1016/j.matdes.2018.04.009, Figure 2

EXTRACTION
18 plotted traces, 1796 color-pixel-center samples:
  Fig. 2a, 0.2 MPa sqrt(m)/s: -90, -55, -25, 0, 21, 50, 100, 150, 250 C.
  Fig. 2b, 0.5 MPa sqrt(m)/s: 21, 50, 100, 150, 250 C.
  Fig. 2c, 1.6 MPa sqrt(m)/s: 21, 50, 100, 500 C.
Native raster images have clean curve-specific colors. Centerlines sampled about
every four native pixels are preserved without interpolating occluded segments.
The overlaid white-ring/black-dot PNGs were visually checked against all panels.
Four explicit cleavage crosses in Fig. 2a are separately transcribed.

INTERPRETATION FOR FITTING
These are apparent K values calculated with initial crack length and an LEFM
conversion. They are not the plasticity-corrected J-equivalent K values from
Table 1. In particular, a curve's apparent K at cleavage need not match its
J-basic toughness. Table 1 is an aggregate; these are representative specimens.

Fig. 2a contains horizontally offset traces, an unnumbered x axis and a 1 um
scale bar. Relative displacement is supplied after subtracting an estimated
displayed loading origin. The unshifted panel coordinate and native pixels are
also retained. Absolute specimen displacement cannot be recovered from this
panel. Initial portions of some traces are hidden beneath other colors.
Fig. 2b,c use the published numeric displacement axes, converted nm to um.

Each curve's chronological loading, cleavage-drop, post-cleavage and unloading
branches are labeled. Vertical drops are graphical connections without time
resolution. Their sampled interiors must not be treated as independent timed
measurements. There are no raw instrument histories or specimen IDs here.
The Fig.3 caption explicitly links panels 3a/b to the Fig.2a tests at 21, 100
and 250 C, rate 0.2. Their K-displacement, stiffness and J-extension curves are
correlated observations from the same specimens. Other links are not unique.
Do not count every graphical sample as an independent experiment. No subjective
plastic-onset point was inferred from a newly imposed tangent construction.

DIGITIZATION PRECISION
Panel a: 1 pixel = 0.005348 um and 0.009709 MPa sqrt(m).
Panels b,c: 1 pixel = 0.008294 um and 0.011765 MPa sqrt(m).
Axis/centerline placement uncertainty is about 1-2 native pixels, with extra
uncertainty from line width and color overlap. The 1-um bar calibration carries
about 0.8% worst-case scale uncertainty. These are digitization estimates, not
experimental confidence intervals. Per-point run halfwidth and sampling axis
are retained in CSV.

FILES
fig2_curves.csv/json: all traced points with branch and provenance columns.
fig2_cleavage_markers.csv: four explicit plus markers.
fig2_metadata.json: calibration, branch definitions, source checksum, limits.
digitize_fig2.py: reproduces outputs from the native embedded images; if absent,
extracts them from --pdf PATH (requires PyMuPDF, Pillow, NumPy).
fig2[a,b,c]_digitization_overlay.png: source-panel overlays for visual checking.

QUALITY CHECK
All 18 traces inspected visually; all 1796 samples have nonnegative K.
Unloading-branch progression checked for erroneous swaps to obscured loading
branches. Such crossing-induced ambiguities are skipped rather than filled.
