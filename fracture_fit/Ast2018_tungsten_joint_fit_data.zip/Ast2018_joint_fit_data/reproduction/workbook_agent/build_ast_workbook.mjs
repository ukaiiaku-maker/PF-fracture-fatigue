import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

// Usage: CODEX_PRIMARY_RUNTIME_NODE build_ast_workbook.mjs EXTRACTION_ROOT
const root=path.resolve(process.argv[2] || '/workspace/scratch/c95d64325aa0/ast_extraction');
const out=path.join(root,'outputs');
const qa=path.join(root,'workbook_agent','previews');
await fs.mkdir(out,{recursive:true}); await fs.mkdir(qa,{recursive:true});
const source='https://doi.org/10.1016/j.matdes.2018.04.009';
const navy='#253E57', light='#E9EFF5', gray='#5B6570', ink='#1F2933';

// RFC 4180 parsing preserves quoted commas and newlines; explicit schema below
// converts numeric columns, preserving empty fields as null.
function parseCSV(s){
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(c==='"'){if(quoted&&s[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}
    else if(c===','&&!quoted){row.push(field);field='';}
    else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&s[i+1]==='\n')i++;row.push(field);if(row.some(x=>x!==''))rows.push(row);row=[];field='';}
    else field+=c;
  }
  if(field!==''||row.length){row.push(field);rows.push(row);}
  const hdr=rows.shift();return rows.map(r=>Object.fromEntries(hdr.map((h,j)=>[h,r[j]??''])));
}
const load=async f=>parseCSV(await fs.readFile(path.join(root,f),'utf8'));
const num=v=>v===''||v==null?null:Number(v);
const yes=v=>v==='True'||v==='true'||v===true;
const c=await load('metadata_agent/table1.csv');
const t=await load('metadata_agent/table1_measurements_long.csv');
const j=await load('fig3/J_R_curves.csv');
const f=await load('fig5_agent/fig5_observations.csv');
const k=await load('fig2_agent/fig2_curves.csv');
const s=await load('fig3/relative_stiffness.csv');
const a=await load('metadata_agent/appendix_A2/A2_all_traces_long.csv');
const wb=Workbook.create();
const names=['Overview','Conditions','Toughness','J_curves','Figure5','K_traces','Stiffness','Time_history','Definitions'];
const sheets=Object.fromEntries(names.map(n=>[n,wb.worksheets.add(n)]));
const endCol=n=>{let out='';while(n>0){n--;out=String.fromCharCode(65+n%26)+out;n=Math.floor(n/26);}return out;};

function tableSheet(name,title,note,headers,rows,widths){
  const sh=sheets[name],end=endCol(headers.length),last=6+rows.length;
  sh.showGridLines=false;
  sh.getRange(`A1:${end}${last}`).format.font={name:'Arial',size:10,color:ink};
  sh.getRange(`A1:${end}${last}`).format.verticalAlignment='center';
  sh.getRange('A2').values=[[title]];sh.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:navy};
  sh.getRange('A3').values=[[`Source: Ast et al. (2018), accepted manuscript. ${source}`]];
  sh.getRange('A3').format.font={name:'Arial',size:9,color:gray};
  sh.getRange('A4').values=[[note]];sh.getRange('A4').format.font={name:'Arial',size:10,italic:true,color:gray};
  sh.getRange(`A6:${end}6`).values=[headers];
  if(rows.length)sh.getRange(`A7:${end}${last}`).values=rows;
  const tab=sh.tables.add(`A6:${end}${last}`,true,`${name.replace(/_/g,'')}Data`);
  tab.style='TableStyleMedium2';tab.showFilterButton=true;
  sh.getRange(`A6:${end}6`).format={fill:navy,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center',rowHeight:44};
  sh.getRange(`A7:${end}${last}`).format.rowHeight=21;
  headers.forEach((_,i)=>{const col=endCol(i+1);sh.getRange(`${col}1:${col}${last}`).format.columnWidth=widths[i]??18;});
  sh.freezePanes.freezeRows(6);sh.freezePanes.freezeColumns(1);
  return sh;
}
function fmt(sh,col,last,format){sh.getRange(`${col}7:${col}${last}`).setNumberFormat(format);}

const conditionRows=c.map(r=>[
 r.condition_id,num(r.temperature_C),null,num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s),num(r.young_modulus_GPa),num(r.poisson_ratio),num(r.n_tests_condition_total),
 num(r.Kq_LEFM_MPa_sqrt_m),num(r.Kq_Jbasic_cleavage_MPa_sqrt_m),num(r.Kq_Jcontinuous_onset_MPa_sqrt_m),num(r.onset_crack_extension_um),null,
 (num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s)===1.6&&[75,100].includes(num(r.temperature_C)))?'Table / Fig. 5b conflict':(num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s)===.05&&num(r.temperature_C)===21)?'Fig. 5b marker unresolved':'',
 'Table 1; PDF p. 10'
]);
const cs=tableSheet('Conditions','Published experimental conditions',
 'Table 1 transcription. J(mean Kq) is a conversion of the mean onset Kq, not a measured mean J.',
 ['Condition ID','Temperature (°C)','Temperature (K)','Initial elastic K rate (MPa√m/s)','E (GPa)','Poisson ratio','Tests in condition','LEFM Kq (MPa√m)','Final-cleavage Kq (MPa√m)','Onset Kq at 0.2 µm (MPa√m)','Onset extension (µm)','J(mean onset Kq) (N/m)','Source discrepancy','Source location'],
 conditionRows,[28,14,15,21,12,13,15,20,23,24,19,24,31,23]);
cs.getRange('C7:C37').formulas=c.map((_,i)=>[`=B${i+7}+273.15`]);
cs.getRange('L7:L37').formulas=c.map((_,i)=>[`=IF(ISNUMBER(J${i+7}),J${i+7}^2*(1-F${i+7}^2)*1000/E${i+7},"")`]);
for(const z of ['H','I','J'])fmt(cs,z,37,'0.0');
fmt(cs,'C',37,'0.00');fmt(cs,'D',37,'0.00');fmt(cs,'F',37,'0.00');fmt(cs,'K',37,'0.0');fmt(cs,'L',37,'0.00');
cs.getRange('M7:M37').conditionalFormats.add('containsText',{text:'conflict',format:{fill:'#FFF0CD',font:{color:'#8D4B00',bold:true}}});

const ts=tableSheet('Toughness','Tabulated toughness measurements',
 'Multiple measures may share a condition and specimens. Condition test counts are not per-measure counts.',
 ['Measurement ID','Temperature (°C)','Initial elastic K rate (MPa√m/s)','Observable','Kq (MPa√m)','Condition test count','Condition ID','Dependency group','Source location'],
 t.map(r=>[r.measurement_id,num(r.temperature_C),num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s),r.observable,num(r.value),num(r.n_tests_condition_total),r.condition_id,r.dependency_group,`Table 1; PDF p. ${r.pdf_page}`]),
 [44,14,22,29,18,21,28,45,23]);fmt(ts,'C',48,'0.00');fmt(ts,'E',48,'0.0');

const js=tableSheet('J_curves','J versus crack extension',
 'Digitized correlated samples. Δa is crack extension; slight negative graphical start values are retained.',
 ['Curve ID','Temperature (°C)','Initial elastic K rate (MPa√m/s)','Sample index','Crack extension Δa (nm)','J (N/m)','Δa reading halfwidth (nm)','J reading halfwidth (N/m)','Wide horizontal span','Fit sample flag','Figure panel'],
 j.map(r=>[r.curve_id,num(r.temperature_C),num(r.loading_rate_MPa_sqrt_m_per_s),num(r.point_index),num(r.crack_extension_nm),num(r.J_N_per_m),num(r.crack_extension_digitization_pm_nm),num(r.J_digitization_pm_N_per_m),yes(r.wide_horizontal_segment),yes(r.sample_for_fit),r.figure_panel]),
 [27,14,22,15,25,16,26,25,23,18,14]);
for(const z of ['E','F','G','H'])fmt(js,z,635,'0.00');fmt(js,'C',635,'0.00');

const fsheet=tableSheet('Figure5','Temperature and rate comparison',
 'Min/max ranges belong to graphical means. Open Fig. 5a nominal Kmax is a distinct observable.',
 ['Observation ID','Panel','Temperature (°C)','Initial elastic K rate (MPa√m/s)','Observable','Table K (MPa√m)','Graph K (MPa√m)','Graph min K (MPa√m)','Graph max K (MPa√m)','Reading halfwidth (MPa√m)','Error-bar visibility','Table / figure conflict','Event status','Condition ID'],
 f.map(r=>[r.observation_id,r.figure,num(r.temperature_C),num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s),r.quantity,num(r.K_table_MPa_sqrt_m),num(r.K_digitized_MPa_sqrt_m),num(r.K_min_digitized_MPa_sqrt_m),num(r.K_max_digitized_MPa_sqrt_m),num(r.coordinate_reading_halfwidth_K_MPa_sqrt_m),r.error_bar_visibility,yes(r.material_table_figure_discrepancy),r.event_status,r.condition_id]),
 [46,10,14,22,43,20,20,21,21,24,38,24,44,28]);
fmt(fsheet,'D',64,'0.00');fmt(fsheet,'F',64,'0.0');for(const z of ['G','H','I','J'])fmt(fsheet,z,64,'0.00');
fsheet.getRange('A7:N64').conditionalFormats.addCustom('=$L7=TRUE',{fill:'#FFF0CD'});

const ks=tableSheet('K_traces','Apparent K versus displacement',
 'Fig. 2a uses each trace’s displayed loading origin; 2b,c use published numeric axes. K uses initial crack length.',
 ['Curve ID','Sequence index','Temperature (°C)','Initial elastic K rate (MPa√m/s)','Displacement (µm)','Apparent K (MPa√m)','Branch','Branch index','Panel coordinate (µm)','Figure panel','Sampling direction','Displacement reference'],
 k.map(r=>[r.curve_id,num(r.sequence_index),num(r.temperature_C),num(r.rate_MPa_sqrt_m_per_s),num(r.displacement_um),num(r.K_MPa_sqrt_m),r.branch,num(r.branch_index),num(r.panel_coordinate_um),r.figure,r.sample_direction,r.displacement_reference]),
 [42,17,15,22,27,24,23,16,24,14,21,46]);
fmt(ks,'D',1802,'0.00');fmt(ks,'E',1802,'0.000');fmt(ks,'F',1802,'0.000');fmt(ks,'I',1802,'0.000');

const ss=tableSheet('Stiffness','Relative stiffness versus displacement',
 'Three normalized specimen traces, correlated with crack-extension estimates and related J curves.',
 ['Curve ID','Temperature (°C)','Initial elastic K rate (MPa√m/s)','Sample index','Displacement (nm)','Relative stiffness','Displacement halfwidth (nm)','Stiffness reading halfwidth','Figure panel'],
 s.map(r=>[r.curve_id,num(r.temperature_C),num(r.loading_rate_MPa_sqrt_m_per_s),num(r.point_index),num(r.displacement_nm),num(r.relative_stiffness),num(r.displacement_digitization_pm_nm),num(r.stiffness_digitization_pm),r.figure_panel]),
 [27,15,22,16,22,22,28,28,15]);fmt(ss,'C',362,'0.00');fmt(ss,'E',362,'0.00');fmt(ss,'F',362,'0.0000');fmt(ss,'G',362,'0.00');fmt(ss,'H',362,'0.0000');

const ash=tableSheet('Time_history','Appendix A2 loading history',
 'One specimen. K and its derivative are dependent observations; room temperature is not assigned a number.',
 ['Curve ID','Sample index','Time (s)','Observable','Value (unit in next column)','Unit','Initial elastic K rate (MPa√m/s)','Displacement rate (nm/s)','Temperature label','Temperature (°C)','Time resolution (s)','Value resolution'],
 a.map(r=>[r.curve_id,num(r.point_index),num(r.time_s),r.observable,num(r.value),r.unit,num(r.initial_elastic_Kdot_MPa_sqrt_m_per_s),num(r.displacement_rate_nm_per_s),r.temperature_label,num(r.temperature_C),num(r.time_coordinate_resolution_s),num(r.value_coordinate_resolution)]),
 [25,16,17,24,26,23,23,25,24,18,22,21]);fmt(ash,'C',479,'0.000');fmt(ash,'E',479,'0.000');fmt(ash,'G',479,'0.00');fmt(ash,'K',479,'0.000');fmt(ash,'L',479,'0.000');

const definitions=[
 ['Source edition','Accepted manuscript of Ast et al., Materials & Design 152 (2018), 168–180. All references use PDF page numbers; original paper data and graphical traces are distinguished.'],
 ['Material and geometry','Single-crystal tungsten, (100)[001] crack system. Nominal cantilevers 15 × 4 × 6 µm. See package metadata for notch and loading details.'],
 ['Temperature and rate coverage','Table 1 covers 12 temperatures from −90 to 500 °C and four initial elastic K rates (0.05, 0.2, 0.5, 1.6 MPa√m/s), with an incomplete temperature–rate factorial grid.'],
 ['Initial elastic K rate','The quoted rate characterizes the initial elastic loading segment. It is not constant after plasticity develops; Appendix A2 shows that change.'],
 ['LEFM Kq','Conditional toughness evaluated with initial crack length. It is not automatically a valid material KIc.'],
 ['Final-cleavage Kq','J-basic conditional toughness at final cleavage. It is distinct from stable-growth onset and from maximum nominal K without cleavage.'],
 ['Onset Kq','J-continuous onset criterion at crack extension Δa ≈ 0.2 µm. Figure 5b uses early-cleavage fallback measures where this approach is unavailable.'],
 ['J versus Δa','Δa is crack extension, not total crack length. The extracted curves preserve their published plotted coordinates and fluctuations.'],
 ['J(mean onset Kq)','Calculated as mean(Kq)^2 × (1−ν^2) × 1000 / E(GPa), using the paper’s conversion convention. This is not mean(J), because squaring and averaging do not commute.'],
 ['Fig. 5a open symbols','Specimens without final cleavage evaluated by maximum nominal K on the right axis. These values are not J-equivalent toughness or direct censor thresholds for that variable.'],
 ['Mixed outcomes','21 °C / 0.2, 50 °C / 0.5 and 75 °C / 1.6 each show cleavage and no-cleavage subgroups. Subgroup sample counts are unavailable.'],
 ['Table / figure conflicts','At 1.6 MPa√m/s, Table 1 onset values at 75 and 100 °C are 7.6 and 5.8, while Fig. 5b gives approximately 8.86 and 7.57 MPa√m. Both versions are retained.'],
 ['Unresolved marker','Table 1 gives onset Kq = 11.2 at 21 °C / 0.05 MPa√m/s. Its Fig. 5b marker is not independently recoverable; no graphical value is invented.'],
 ['Error bars','Fig. 5 uses observed specimen minima and maxima, not standard deviations, standard errors, or confidence intervals. Missing recoverable ranges remain blank.'],
 ['Digitization uncertainty','Pixel-reading and visible-trace uncertainty describes extraction resolution, not experimental scatter. Raw pixel coordinates and detailed provenance remain in the CSV package.'],
 ['Repeated data','Table 1 and Fig. 5 describe overlapping observations. Digitized curve samples are correlated; their sample count is not the number of independent experiments.'],
 ['Missing values','Blank cells preserve unavailable or unreported source quantities. They do not imply zero, failure, or survival.'],
 ['Fit use','Joint fitting should use each experimental definition, retain dependence groups, handle the table/figure alternatives explicitly, and avoid treating dense raster samples as independent replicates.'],
 ['Extraction status','Experimental-data extraction only. No model parameters or barriers have been fitted in this workbook.'],
];
const ds=tableSheet('Definitions','Definitions and interpretation',
 'These definitions accompany the measurements and help keep the joint fitting objective consistent.',
 ['Term','Meaning'],definitions,[34,145]);
ds.getRange(`B7:B${6+definitions.length}`).format.wrapText=true;
ds.getRange(`A7:B${6+definitions.length}`).format.rowHeight=44;

const ov=sheets.Overview;ov.showGridLines=false;ov.tabColor=navy;
ov.getRange('A1:F38').format.font={name:'Arial',size:11,color:ink};
ov.getRange('A1:F38').format.verticalAlignment='center';
ov.getRange('A1:A38').format.columnWidth=3;ov.getRange('B1:B38').format.columnWidth=43;
ov.getRange('C1:C38').format.columnWidth=16;ov.getRange('D1:D38').format.columnWidth=74;
ov.getRange('E1:F38').format.columnWidth=12;ov.getRange('A1:F38').format.rowHeight=23;
ov.getRange('B2').values=[['Ast 2018 tungsten experimental data']];ov.getRange('B2').format.font={name:'Arial',size:16,bold:true,color:navy};
ov.getRange('B4').values=[[`Accepted manuscript. ${source}`]];ov.getRange('B4').format.font={name:'Arial',size:10,color:gray};
ov.getRange('B6:D6').values=[['Data','Records','Interpretation']];
ov.getRange('B6:D6').format={fill:navy,font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:26};
const overview=[
 ['Published conditions',null,'12 temperatures; 4 initial elastic loading rates'],
 ['Tabulated toughness values',null,'Three evaluation methods; overlapping specimens'],
 ['J–crack-extension samples',null,'8 graphical curves; correlated samples'],
 ['Figure 5 observations',null,'Includes 8 nominal-Kmax endpoints without cleavage'],
 ['K–displacement samples',null,'18 graphical curves; preserved loading/unloading branches'],
 ['Relative-stiffness samples',null,'3 graphical traces'],
 ['Appendix A2 time-history samples',null,'2 dependent observables from one specimen'],
 ];
ov.getRange('B7:D13').values=overview;
const countDefs=[['Conditions',37],['Toughness',48],['J_curves',635],['Figure5',64],['K_traces',1802],['Stiffness',362],['Time_history',479]];
ov.getRange('C7:C13').formulas=countDefs.map(([n,end])=>[`=COUNTA('${n}'!A7:A${end})`]);
ov.getRange('C7:C15').setNumberFormat('#,##0');
ov.getRange('C7:C15').format.horizontalAlignment='center';
ov.getRange('B15').values=[['Reported tests across conditions']];ov.getRange('C15').formulas=[['=SUM(Conditions!G7:G37)']];
ov.getRange('D15').values=[['Total condition counts; per-observable subgroup sizes unavailable']];
ov.getRange('B17').values=[['Use for a joint experimental fit']];ov.getRange('B17').format.font={bold:true,color:navy};
ov.getRange('B18').values=[['Use the same material parameters with distinct observation definitions.']];
ov.getRange('B19').values=[['Dense digitized samples and repeated presentations are not independent tests.']];
ov.getRange('B21').values=[['Two unresolved source discrepancies']];ov.getRange('B21').format.font={bold:true,color:'#8D4B00'};
ov.getRange('B23:D24').values=[['75 °C; rate 1.6 MPa√m/s',7.6,'Table 1 onset K versus 8.86 MPa√m in Fig. 5b'],['100 °C; rate 1.6 MPa√m/s',5.8,'Table 1 onset K versus 7.57 MPa√m in Fig. 5b']];
ov.getRange('B23:D24').format.fill='#FFF0CD';ov.getRange('C23:C24').setNumberFormat('0.0');
ov.getRange('C23:C24').format.horizontalAlignment='center';
ov.getRange('B26').values=[['Preserve both versions and fit sensitivity alternatives.']];
ov.getRange('B27').values=[['Figure 5 min/max bars belong to the plotted values.']];
ov.getRange('B29').values=[['Traceable formats']];ov.getRange('B29').format.font={bold:true,color:navy};
ov.getRange('B30').values=[['This workbook: readable scientific fields and editable unit conversions.']];
ov.getRange('B31').values=[['Companion CSVs: full pixel coordinates, provenance, flags and extraction details.']];
ov.getRange('B33').values=[['Extraction only. No barrier fit or solver calculation has been performed.']];
ov.getRange('B33').format.font={name:'Arial',size:10,italic:true,color:gray};
try{
 const pic=await fs.readFile(path.join(out,'Ast2018_extracted_data_overview.png'));
 ov.images.add({dataUrl:`data:image/png;base64,${pic.toString('base64')}`,anchor:{from:{row:36,col:1},extent:{widthPx:1000,heightPx:600}}});
}catch(e){if(e.code!=='ENOENT')throw e;}

// Verify formula response to an input change, restoring the published input.
const saved=cs.getRange('B7').values[0][0];
cs.getRange('B7').values=[[saved+1]];
if(Math.abs(cs.getRange('C7').values[0][0]-(saved+1+273.15))>1e-9)throw new Error('Temperature formula did not update');
cs.getRange('B7').values=[[saved]];
wb.recalculate();
const summary=await wb.inspect({kind:'table',range:'Overview!B6:D15',include:'values,formulas',tableMaxRows:10,tableMaxCols:3,maxChars:5000});
const errs=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'Formula error scan',maxChars:4000});
await fs.writeFile(path.join(qa,'inspection.ndjson'),summary.ndjson+'\n'+errs.ndjson+'\n');
console.log(summary.ndjson);console.log(errs.ndjson);
const renderNames=process.env.AST_RENDER_SHEETS?process.env.AST_RENDER_SHEETS.split(','):names;
for(const n of renderNames){
 const range=n==='Overview'?'A1:D34':n==='Definitions'?'A1:B14':'A1:H13';
 const blob=await wb.render({sheetName:n,range,scale:1.2,format:'png'});
 await fs.writeFile(path.join(qa,`${n}.png`),new Uint8Array(await blob.arrayBuffer()));
}
const xlsx=await SpreadsheetFile.exportXlsx(wb);
const file=path.join(out,'Ast2018_tungsten_experimental_data.xlsx');await xlsx.save(file);
console.log('EXPORTED',file);
