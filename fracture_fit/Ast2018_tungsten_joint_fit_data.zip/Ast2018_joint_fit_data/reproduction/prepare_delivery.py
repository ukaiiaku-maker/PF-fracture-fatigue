"""Assemble the Ast 2018 extraction, preserve provenance, and draw an overview.

Run after the individual extraction scripts. No material-model fit is performed.
The canonical CSVs retain source fields and add explicit cross-observation links.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import os
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs'
PKG = OUT / 'Ast2018_joint_fit_data'
URL = 'https://www.dora.lib4ri.ch/empa/dload/empa%3A17075/PDF2/Ast-2018-The_brittle-ductile_transition_of_tungsten-%28accepted_version%29.pdf'
DOI = '10.1016/j.matdes.2018.04.009'
SHA = '7932cab933aebfe75472a35e2b0f9187c9fb96eb26ffe0bb0645f134e6de1130'

def read_csv(path):
    with Path(path).open(newline='') as f:
        return list(csv.DictReader(f))

def dump_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def dump_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False)+'\n')

def copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def typed(v):
    if isinstance(v,(bool,int,float)) or v is None: return v
    if v == '': return None
    if v in ('True', 'False'): return v == 'True'
    try:
        n=float(v)
        return int(n) if n.is_integer() else n
    except (ValueError,TypeError): return v

def typed_rows(rows):
    return [{k:typed(v) for k,v in r.items()} for r in rows]

def condition_id(t, rate):
    return f"T{'m' if t<0 else 'p'}{abs(int(t))}C_rate{rate:g}".replace('.','p')

def specimen_group(t, rate, fig):
    if rate==.2 and t in (21,100,250) and fig in ('2a','3a','3b'):
        return f'Ast2018_linked_F2a_F3ab_T{int(t)}_r0p2'
    return ''

def augment(rows, kind):
    for r in rows:
        t=float(r['temperature_C'])
        rate=float(r.get('initial_elastic_Kdot_MPa_sqrt_m_per_s',
                     r.get('loading_rate_MPa_sqrt_m_per_s',r.get('rate_MPa_sqrt_m_per_s'))))
        r['condition_id']=condition_id(t,rate)
        r['temperature_K']=round(t+273.15,2)
        r['initial_elastic_Kdot_MPa_sqrt_m_per_s']=rate
        fig=r.get('figure_panel',r.get('figure',''))
        r['known_linked_specimen_group']=specimen_group(t,rate,fig)
        r['dependence_note']='Same specimen explicitly linked by Fig3 caption.' if r['known_linked_specimen_group'] else 'No unique specimen identifier recovered; matching condition is not proof of an independent test.'
        if kind=='J': r['crack_extension_um']=float(r['crack_extension_nm'])/1000
        if kind=='stiffness': r['displacement_um']=float(r['displacement_nm'])/1000
    return rows

def plot_overview(table, jr, a2, fig5):
    os.environ.setdefault('MPLCONFIGDIR','/tmp/ast_overview_matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
        'axes.spines.top':False,'axes.spines.right':False,'axes.grid':False,
        'savefig.facecolor':'white','axes.linewidth':.8,'legend.frameon':False})
    fig,axs=plt.subplots(2,3,figsize=(14,8.4),layout='constrained')
    colors={21:'#278549',100:'#ba7a16',250:'#d8463a',500:'#8c2547'}
    for ax,rate,letter in zip(axs[0],[.2,.5,1.6],['a','b','c']):
        for cid in dict.fromkeys(r['curve_id'] for r in jr if float(r['loading_rate_MPa_sqrt_m_per_s'])==rate):
            rr=[r for r in jr if r['curve_id']==cid]; t=int(float(rr[0]['temperature_C']))
            ax.plot([float(r['crack_extension_nm'])/1000 for r in rr],
                    [float(r['J_N_per_m']) for r in rr],color=colors[t],lw=1.2,
                    marker='.',ms=2.5,label=f'{t} °C')
        ax.axvline(.2,color='#666666',ls=':',lw=.9,zorder=0)
        ax.set_xlabel(r'Crack extension, $\Delta a$ (µm)')
        ax.set_ylabel(r'$J$ (N/m)')
        ax.set_xlim(-.22,1.65 if rate!=1.6 else 2.6)
        ax.set_ylim(0,1280 if rate!=1.6 else 615)
        ax.text(.035,.96,f'({letter})  Initial '+r'$\dot K$'+f' = {rate:g} MPa√m/s',transform=ax.transAxes,va='top',fontsize=9.3)
        ax.legend(loc='lower right',fontsize=9)
        ax.tick_params(direction='out')
    rates=[.05,.2,.5,1.6]
    ratecolors={.05:'#7144a0',.2:'#d78a28',.5:'#1876ac',1.6:'#338d58'}
    markers={.05:'o',.2:'s',.5:'^',1.6:'D'}
    for ax,field,label,letter in [
        (axs[1,0],'Kq_Jcontinuous_onset_MPa_sqrt_m',r'Onset $K_q$ (MPa√m)','d'),
        (axs[1,1],'cleavage',r'Cleavage $K_q$ (MPa√m)','e')]:
        for rate in rates:
            rr=[r for r in table if float(r['initial_elastic_Kdot_MPa_sqrt_m_per_s'])==rate]
            xx=[];yy=[]
            for r in rr:
                v=r.get(field,'') if field!='cleavage' else r['Kq_Jbasic_cleavage_MPa_sqrt_m'] or r['Kq_LEFM_MPa_sqrt_m']
                if v!='': xx.append(float(r['temperature_C']));yy.append(float(v))
            ax.plot(xx,yy,linestyle='-',lw=.9,marker=markers[rate],ms=4.5,color=ratecolors[rate],label=f'{rate:g}')
        ax.set_xlabel('Temperature (°C)');ax.set_ylabel(label);ax.set_ylim(0,16.3)
        ax.text(.035,.96,f'({letter})  Table 1',transform=ax.transAxes,va='top',fontsize=10)
        ax.legend(title=r'Initial $\dot K$ (MPa√m/s)',loc='lower right',fontsize=8.5,title_fontsize=8.5,ncol=2)
    # Graphical alternatives are shown separately, never averaged with the table.
    rr=[r for r in fig5 if r['material_table_figure_discrepancy']=='True']
    axs[1,0].scatter([float(r['temperature_C']) for r in rr],[float(r['K_digitized_MPa_sqrt_m']) for r in rr],
        marker='x',s=55,c='#20262d',lw=1.6,zorder=5)
    axs[1,0].text(.035,.07,'× Figure 5b alternative',transform=axs[1,0].transAxes,fontsize=8.5,color='#20262d')
    axs[1,0].set_xlim(-45,525);axs[1,1].set_xlim(-100,90)
    ax=axs[1,2]; ar=ax.twinx(); ar.spines['right'].set_visible(True)
    for obs,a,color,label in [('nominal_KI',ax,'#223746',r'Nominal $K$'),('plotted_loading_rate',ar,'#c8453c',r'Plotted $\dot K$')]:
        rr=[r for r in a2 if r['observable']==obs]
        assert rr, 'Missing plotted A2 observable: '+obs
        a.plot([float(r['time_s']) for r in rr],[float(r['value']) for r in rr],lw=1,color=color,label=label)
        a.tick_params(axis='y',colors=color)
    ax.set_xlabel('Time (s)');ax.set_ylabel(r'Nominal $K$ (MPa√m)',color='#223746')
    ar.set_ylabel(r'Nominal $\dot K$ (MPa√m/s)',color='#c8453c')
    ax.set_xlim(0,5);ax.set_ylim(0,4.2);ar.set_ylim(-.5,2.1)
    ax.text(.035,.96,'(f)  A2: displacement rate 150 nm/s',transform=ax.transAxes,va='top',fontsize=9.5)
    ax.text(.035,.88,'Room temperature',transform=ax.transAxes,va='top',fontsize=9,color='#535e68')
    for a in axs.flat: a.grid(False)
    ar.grid(False)
    for ext in ('png','svg'):
        fig.savefig(OUT/f'Ast2018_extracted_data_overview.{ext}',dpi=220,bbox_inches='tight')
    plt.close(fig)

def main():
    for d in ('data','metadata','qa','figures','reproduction'):
        (PKG/d).mkdir(parents=True,exist_ok=True)
    table=read_csv(ROOT/'metadata_agent/table1.csv')
    tough=read_csv(ROOT/'metadata_agent/table1_measurements_long.csv')
    fig5=read_csv(ROOT/'fig5_agent/fig5_observations.csv')
    jr=augment(read_csv(ROOT/'fig3/J_R_curves.csv'),'J')
    kval=augment(read_csv(ROOT/'fig2_agent/fig2_curves.csv'),'K')
    stiff=augment(read_csv(ROOT/'fig3/relative_stiffness.csv'),'stiffness')
    a2=read_csv(ROOT/'metadata_agent/appendix_A2/A2_all_traces_long.csv')
    bdt=read_csv(ROOT/'metadata_agent/bdt_transitions.csv')
    conflicts=[r for r in fig5 if r['material_table_figure_discrepancy']=='True']
    conflicting_conditions={r['condition_id'] for r in conflicts}
    for r in table:
        r['onset_table_figure_conflict']=r['condition_id'] in conflicting_conditions
    for r in tough:
        r['table_figure_conflict']=(r['condition_id'] in conflicting_conditions and 'continuous' in r['observable'])
        r['table_value_policy']='Preserved numeric Table1 transcription; unresolved Figure5 alternative retained separately.'
    nocleave=[r for r in fig5 if r['event_status']=='no_cleavage']
    if len(nocleave)!=8:
        nocleave=[r for r in fig5 if r['figure']=='5a' and r['marker_fill']=='open']
    datasets={
        'table1_conditions':table,'table1_toughness_long':tough,
        'J_R_curves':jr,'K_displacement_curves':kval,'relative_stiffness':stiff,
        'figure5_observations':fig5,'source_discrepancies':conflicts,
        'no_cleavage_endpoints':nocleave,'BDT_assignments':bdt,'A2_time_history':a2,
        'figure2_cleavage_markers':read_csv(ROOT/'fig2_agent/fig2_cleavage_markers.csv')}
    opt=ROOT/'fig3/example_curve_authorfit_onsets.csv'
    if opt.exists(): datasets['example_curve_authorfit_onsets']=read_csv(opt)
    for name,rows in datasets.items(): dump_csv(PKG/'data'/f'{name}.csv',rows)
    dump_json(PKG/'data'/'all_extracted_data.json', {k:typed_rows(v) for k,v in datasets.items()})
    experiment=json.loads((ROOT/'metadata_agent/metadata.json').read_text())
    copy(ROOT/'metadata_agent/metadata.json',PKG/'metadata'/'experiment.json')
    source={**experiment['source'],'source_url':URL,
        'extraction_date_UTC':'2026-10-24',
        'version_status':'Accepted manuscript extracted. Publisher final PDF was not available for verification; Table1/Fig5 discrepancies remain unresolved.',
        'data_kind':'Numeric table transcription and digitization of published raster plots, not raw acquisition data.',
        'source_pdf_included':False,
        'page_map':{'Table1':10,'Fig2':12,'Fig3':13,'Fig5':16,'Fig8':21,'FigA2':33}}
    dump_json(PKG/'SOURCE.json',source)
    for src,dst in [('fig2_agent/fig2_metadata.json','figure2.json'),('fig3/curve_metadata.json','figure3_curves.json'),
        ('fig5_agent/fig5_metadata.json','figure5.json'),('metadata_agent/appendix_A2/A2_metadata.json','appendix_A2.json')]:
        copy(ROOT/src,PKG/'metadata'/dst)
    for path in (ROOT/'fig3').glob('*onset*metadata*'):
        copy(path,PKG/'metadata'/path.name)
    linked=[]
    for t in (21,100,250):
        group=specimen_group(t,.2,'3b')
        for cid,obs,file in [(f'Ast2018_F2a_T{t}_rate0.2','nominal_K_displacement','K_displacement_curves.csv'),
            (f'F3a_T{t}_r0.2','relative_stiffness','relative_stiffness.csv'),(f'F3b_T{t}_r0.2','J_crack_extension','J_R_curves.csv')]:
            linked.append({'known_linked_specimen_group':group,'curve_id':cid,'observable':obs,'data_file':file,
                'evidence':'Figure3 caption explicitly links these tests to Figure2a. Original specimen IDs unavailable.'})
    dump_csv(PKG/'metadata'/'known_specimen_links.csv',linked)
    registry=[]
    for name,rows,obs in [('J_R_curves',jr,'J_vs_crack_extension'),('K_displacement_curves',kval,'nominal_K_vs_displacement'),
        ('relative_stiffness',stiff,'relative_stiffness_vs_displacement'),('A2_time_history',a2,'time_history')]:
        for cid in dict.fromkeys(r['curve_id'] for r in rows):
            rr=[r for r in rows if r['curve_id']==cid]; r=rr[0]
            registry.append({'curve_id':cid,'data_file':f'data/{name}.csv','observable':obs,
                'temperature_C':r.get('temperature_C',''),'initial_elastic_Kdot_MPa_sqrt_m_per_s':r.get('initial_elastic_Kdot_MPa_sqrt_m_per_s',''),
                'graphical_samples':len(rr),'known_linked_specimen_group':r.get('known_linked_specimen_group',r.get('dependency_group','')),
                'samples_are_independent_raw_data':False,'source_pdf_page':r['source_pdf_page']})
    dump_csv(PKG/'metadata'/'curve_registry.csv',registry)
    coverage={'temperature_rate_conditions':len(table),'condition_total_test_count':sum(int(r['n_tests_condition_total']) for r in table),
        'tabulated_toughness_values':len(tough),'tabulated_toughness_by_observable':dict(Counter(r['observable'] for r in tough)),
        'J_curves':len({r['curve_id'] for r in jr}),'J_graphical_samples':len(jr),
        'nominal_K_displacement_curves':len({r['curve_id'] for r in kval}),'nominal_K_graphical_samples':len(kval),
        'relative_stiffness_curves':len({r['curve_id'] for r in stiff}),'stiffness_graphical_samples':len(stiff),
        'figure5_observation_rows':len(fig5),'no_cleavage_endpoints':len(nocleave),
        'A2_channels':len({r['curve_id'] for r in a2}),'A2_graphical_samples':len(a2),
        'derived_BDT_assignments':len(bdt),'material_table_figure_conflicts':len(conflicts),
        'example_author_fit_onsets':len(datasets.get('example_curve_authorfit_onsets',[]))}
    assert (len(table),len(tough),len(jr),len(kval),len(stiff),len(a2),len(nocleave),len(conflicts))==(31,42,629,1796,356,473,8,2)
    assert len({r['condition_id'] for r in table})==31
    assert len({r['observation_id'] for r in fig5})==58
    for c in conflicts: assert abs(float(c['digitized_minus_table_MPa_sqrt_m']))>.2
    dump_json(PKG/'metadata'/'coverage.json',coverage)
    contract={
        'purpose':'Experimental observations for fitting a common material model through distinct observation operators. No parameters fitted by this extraction.',
        'source_alternatives':{'primary_table_transcription':'data/table1_toughness_long.csv',
            'alternative_figure_means_and_ranges':'data/figure5_observations.csv',
            'unresolved_conflicts':'data/source_discrepancies.csv',
            'rule':'Select a source scenario for each conflicted mean; do not average Table1 with Figure5, count them twice, or attach incompatible plotted ranges to Table1.'},
        'units':{'J':'N/m = J/m^2','K':'MPa sqrt(m)','initial_elastic_Kdot':'MPa sqrt(m)/s',
            'temperature':'C and K where known; all Arrhenius calculations require K','extension':'nm and supplemental um; Delta a, not total a',
            'displacement':'Fig2 um; stiffness nm plus supplemental um','time':'s'},
        'missing':'Empty CSV cell and JSON null mean unavailable, not zero.',
        'event_definitions':{'Jcontinuous_onset':'Author criterion at Delta a=0.2 um, from J resistance curve.',
            'Jbasic_cleavage':'Final unstable cleavage after any preceding plastic work.',
            'LEFM':'Conditional toughness from 95-percent construction or maximum elastic load.',
            'nominal_K':'Initial-crack LEFM normalization of force; not J-equivalent toughness during plasticity.',
            'no_cleavage':'Outcome plus maximum nominal K; no direct lower bound on J-equivalent cleavage toughness without forward observation mapping.'},
        'conversion':{'K_to_J':'J_N_per_m = 1000*K_MPa_sqrt_m**2*(1-nu**2)/E_GPa',
            'J_to_K':'K_MPa_sqrt_m = sqrt(J_N_per_m*E_GPa/(1000*(1-nu**2)))',
            'mean_warning':'J(mean K) is not generally mean J; a deterministic transform is not a new independent observation.'},
        'dependence':{'known_links':'metadata/known_specimen_links.csv',
            'Table1_Figure5':'Overlapping representations of the same condition statistics; Figure5 contributes plotted ranges and no-cleavage endpoints.',
            'Figure2_Figure3':'Explicit same-specimen links at 21,100,250C and rate0.2; other unknown specimen IDs retained as unknown.',
            'Figure3_onsets':'Eight author-fit readouts, if present, derived from the displayed example curves; not replicate measurements or condition means.',
            'A2':'Rate and nominal K originate in one history; correlated channels.',
            'Figure8_BDT':'Derived from existing toughness/cleavage data; useful diagnostic, not additional independent evidence.',
            'sampling':'Rows represent correlated graphical samples. Do not increase experimental precision by increasing raster sampling density.'},
        'fit_policy':{'protocol':'Imposed displacement rate; quoted Kdot labels initial elastic slope only.',
            'curve_order':'J samples ordered by increasing-J raster sweep, not recovered time. Preserve visible horizontal spans and negative inferred extensions.',
            'Fig2a_displacement':'Per-curve displayed loading-origin reference; arbitrary horizontal figure offsets were removed approximately; no absolute displacement recovered.',
            'graphical_connectors':'Fig2 cleavage_drop connectors are not time-resolved trajectories; fit_role identifies them.',
            'uncertainty':'Digitization coordinate tolerance is distinct from specimen scatter. Figure5 bars are min/max, not SD/SEM/CI. Subgroup n unavailable.',
            'geometry':'Use published specimen range and per-specimen nuisance inputs; exact geometries/notch radii are not recovered.',
            'weights':'Choose observable- and specimen-block covariance or justified block weights. No numerical likelihood variances are fabricated in this package.'}}
    dump_json(PKG/'metadata'/'fitting_contract.json',contract)
    guide=(ROOT/'metadata_agent/FIT_GUIDE.txt').read_text()
    guide += ('\nPACKAGE FILENAME CROSSWALK\n'
        'Extractor table1.csv -> data/table1_conditions.csv\n'
        'Extractor table1_measurements_long.csv -> data/table1_toughness_long.csv\n'
        'Extractor fig2_curves.csv -> data/K_displacement_curves.csv\n'
        'Extractor fig5_observations.csv -> data/figure5_observations.csv\n'
        'Extractor A2_all_traces_long.csv -> data/A2_time_history.csv\n'
        'Typed copies of every CSV are included in data/all_extracted_data.json.\n')
    (PKG/'FIT_GUIDE.txt').write_text(guide)
    copy(ROOT/'fig2_agent/README_fig2.txt',PKG/'metadata'/'figure2_notes.txt')
    for folder,pattern in [('fig2_agent','*digitization_overlay.png'),('fig3','*digitization_overlay.png'),
        ('fig5_agent','*overlay.png'),('metadata_agent/appendix_A2','A2_digitization_overlay.png')]:
        for p in (ROOT/folder).glob(pattern): copy(p,PKG/'qa'/p.name)
    for p in (ROOT/'fig3').glob('*onset*overlay*.png'): copy(p,PKG/'qa'/p.name)
    # Preserve the extraction scripts' relative directory layout. The source PDF
    # can be fetched and hash-verified but is not redistributed in this package.
    repro=PKG/'reproduction'
    files=['digitize_fig3.py','prepare_delivery.py','metadata_agent/build_table_metadata.py',
        'metadata_agent/FIT_GUIDE.txt','fig2_agent/digitize_fig2.py','fig2_agent/README_fig2.txt',
        'fig5_agent/extract_fig5.py','metadata_agent/appendix_A2/digitize_A2.py','images/p33_img0.png']
    files += [str(p.relative_to(ROOT)) for p in (ROOT/'fig3').glob('digitize*onset*.py')]
    for f in files: copy(ROOT/f,repro/f)
    (repro/'source').mkdir(exist_ok=True)
    (repro/'requirements.txt').write_text('numpy\nscipy\nPillow\nPyMuPDF\nmatplotlib\n')
    fetch='''"""Fetch and verify the exact accepted manuscript used in this extraction."""
from pathlib import Path
import hashlib, urllib.request
URL = %r
EXPECTED = %r
ROOT = Path(__file__).resolve().parent
target = ROOT / 'source' / 'Ast_2018_accepted.pdf'
target.parent.mkdir(exist_ok=True)
if target.exists():
    payload = target.read_bytes()
else:
    with urllib.request.urlopen(URL, timeout=90) as response:
        payload = response.read()
digest = hashlib.sha256(payload).hexdigest()
if digest != EXPECTED:
    raise RuntimeError('Source version mismatch: expected '+EXPECTED+'; received '+digest)
target.write_bytes(payload)
print('Verified source:', target)
'''%(URL,SHA)
    (repro/'fetch_source.py').write_text(fetch)
    (repro/'README.txt').write_text('''REPRODUCING THE EXTRACTION
Python dependencies are listed in requirements.txt. Run from this directory:

python fetch_source.py
python metadata_agent/build_table_metadata.py
python fig2_agent/digitize_fig2.py
python digitize_fig3.py
python fig5_agent/extract_fig5.py
python metadata_agent/appendix_A2/digitize_A2.py

If included: python fig3/digitize_example_onsets.py
Then: python prepare_delivery.py

This regenerates the figure coordinates, tables, provenance, and the data package.
The source URL is public; network access is needed only to fetch the manuscript.
The table values and Figure5 coordinates are explicit audited transcriptions;
running the scripts reproduces those choices rather than discovering new data.
The black Figure3 fits are excluded from experimental trace data. Optional onset
readouts from those fits are separately labelled derived summaries.

Spreadsheet authoring is separate: the supplied JS workbook script requires
@oai/artifact-tool and its documented runtime. CSV and JSON data do not require it.
No fitting or material simulation is executed by these scripts.
''')
    readme='''AST ET AL. 2018 — EXPERIMENTAL DATA FOR JOINT MODEL FITTING
========================================================
Source: J. Ast et al., The brittle-ductile transition of tungsten single crystals
at the micro-scale, Materials & Design 152 (2018) 168–180.
DOI: https://doi.org/10.1016/j.matdes.2018.04.009
Version: open accepted manuscript, 35 PDF pages. See SOURCE.json for URL/hash.

CONTENTS
data/: CSV tables and curves; all_extracted_data.json contains equivalent typed
records. Empty CSV cells / JSON null denote unavailable data, never zero.
metadata/: experimental definitions, axis calibrations, curve registry, known
same-specimen links, coverage and a machine-readable fitting contract.
qa/: recovered points overlaid on original figure panels.
figures/: an overview reconstructed from the extracted values.
reproduction/: Python scripts, minimal source images and a verified PDF fetcher.
FIT_GUIDE.txt: how to combine these observations without mixing definitions or
inflating their independence. The companion Excel workbook is a readable view.

COVERAGE
31 temperature/rate conditions; 73 condition-total tests; 42 tabulated toughness
values (6 LEFM, 13 J-basic final cleavage, 23 J-continuous onset).
8 J–crack-extension curves (629 graphical samples), 18 nominal-K–displacement
curves (1,796 samples), 3 relative-stiffness curves (356 samples), and 2 A2 time
channels (473 samples). Figure5 has 58 records including 8 no-cleavage endpoints.
Four BDT assignments are derived from the same experimental campaign.
Eight per-example author-fit onset readouts are derived, not new specimens.

IMPORTANT DEFINITIONS
J is in N/m (= J/m²). Delta a is extension from the initial notch, not total a.
Continuous-J onset uses Delta a=0.2 µm. Final cleavage, this onset criterion and
initial-crack nominal K are separate observables, even where K units coincide.
The quoted loading-rate groups are initial elastic Kdot, while tests were
displacement-controlled. A2 supplies a representative changing nominal rate.
Figure2a traces are horizontally shifted in the source; recovered displacements
use an approximate displayed loading-origin reference for each trace.

SOURCE DISCREPANCIES
At rate 1.6 MPa√m/s, Table 1 onset K is 7.6 at 75°C and 5.8 at 100°C; Figure 5b
is approximately 8.9 and 7.6 respectively. Both are retained and explicitly flagged.
The table is the primary numerical transcription, not a verified correction of
the figure. No final publisher PDF was available to resolve the difference.
Do not average the alternatives or attach conflicting graph ranges to table means.

DEPENDENCE AND UNCERTAINTY
Table 1 and Figure 5 largely overlap. Figures 3a/b and 2a at 21, 100, 250°C and
rate 0.2 are explicitly linked specimens. Other specimen identities are unknown.
Figure 3 curves are individual examples, not necessarily Table 1 condition means.
Figure 5 error bars are min/max; original SD and subgroup sizes are unavailable.
Coordinate tolerances concern digitization, not experimental uncertainty.
Pixel sampling density does not create additional independent observations.
The visible trace is retained without constitutive fitting, smoothing, or imposed
monotonicity. Wide spans and negative crack-extension estimates are preserved.
J-trace row order is increasing-J raster order; original times are unavailable.
Figure2 graphical cleavage-drop connectors are flagged and not time-resolved data.

VALIDATION
Source table read and checked visually; axes and all labelled target curves
checked against native embedded images; overlays retained. Figure3 received an
independent review confirming all 629 points within 2 native pixels of their color
traces. IDs, row counts, ranges and source alternatives were checked. Numerical
precision in files supports reproducibility and is not a claim of measurement
accuracy. For reporting, retain source table precision (0.1 MPa√m) and sensible
rounded digitized values. No fitted activation barriers are claimed here.
'''
    (PKG/'README.txt').write_text(readme)
    plot_overview(table,jr,a2,fig5)
    for ext in ('png','svg'): copy(OUT/f'Ast2018_extracted_data_overview.{ext}',PKG/'figures'/f'Ast2018_extracted_data_overview.{ext}')
    finalize()
    print(json.dumps(coverage,indent=2))
    print('Package directory:',PKG)

def finalize():
    """Refresh manifest/zip after the optional workbook arrives."""
    manifest=[]
    for p in sorted(PKG.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS.txt':
            manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(PKG)))
    (PKG/'SHA256SUMS.txt').write_text('\n'.join(manifest)+'\n')
    target=OUT/'Ast2018_tungsten_joint_fit_data.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(PKG.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(OUT))
    print('ZIP:',target,'bytes:',target.stat().st_size)

if __name__=='__main__': main()
