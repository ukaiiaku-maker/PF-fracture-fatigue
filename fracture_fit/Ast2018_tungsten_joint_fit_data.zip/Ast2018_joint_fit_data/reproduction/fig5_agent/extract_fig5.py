"""Reproduce Ast et al. (2018) Fig. 5 digitization from native embedded images.

Manual coordinates are native-image pixels, origin upper left. Table 1 means
are retained separately from independently read graphical means. Error bars
are specimen min/max extents, never standard deviations. No missing endpoint
is inferred by symmetry. Run from any working directory with the extraction
tree intact. Dependencies: PyMuPDF, Pillow; plotting uses matplotlib.
"""
from pathlib import Path
import csv, json, hashlib
import fitz
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PDF = ROOT / 'source' / 'Ast_2018_accepted.pdf'
TABLE = ROOT / 'metadata_agent' / 'table1.json'
DOI = '10.1016/j.matdes.2018.04.009'

# Panel a: [T_C, rate, marker_y, upper_error_y, lower_error_y].
# Means are independent approximate marker-center reads; filled point means
# from Table 1 are authoritative tabulated values, not replaced by these reads.
FILLED_A = [
 [-90,.05,353.5,None,None],[-75,.05,353.5,None,None],[-55,.05,351.5,None,None],
 [-25,.05,294.0,279.5,308.0],[0,.05,204.5,175.0,234.0],
 [-90,.2,350.0,None,None],[-75,.2,348.5,None,None],[-55,.2,346.5,None,None],
 [-25,.2,318.0,None,None],[0,.2,243.5,235.0,251.0],[21,.2,204.5,163.0,246.0],
 [-25,.5,329.0,None,None],[0,.5,263.0,253.5,273.0],[21,.5,232.0,221.0,243.0],
 [50,.5,173.5,145.5,201.0],
 [0,1.6,285.0,None,None],[21,1.6,258.0,None,None],
 [50,1.6,233.0,225.0,242.0],[75,1.6,154.0,108.0,200.0],
]
OPEN_A = [
 [21,.05,356.0,None,None],
 [21,.2,341.8,320.5,363.0],[50,.2,349.5,None,None],
 [50,.5,340.8,338.0,344.5],[75,.5,347.0,None,None],[100,.5,358.5,None,None],
 [75,1.6,358.6,None,None],[100,1.6,365.0,354.0,376.0],
]

# Panel b: the point at 21 C / .05 is not separately recoverable from the
# superposed marks. Its table value is retained with no invented pixel center.
POINTS_B = [
 [-90,.05,353.0,None,None],[-75,.05,353.0,None,None],[-55,.05,351.0,None,None],
 [-90,.2,349.5,None,None],[-75,.2,348.0,None,None],[-55,.2,346.5,None,None],
 [-25,.05,312.0,297.0,None],[-25,.2,318.5,None,None],[-25,.5,328.5,None,None],
 [0,.05,274.0,None,None],[0,.2,256.5,None,None],[0,.5,270.0,None,None],
 [0,1.6,258.5,None,None],
 [21,.05,None,None,None],[21,.2,226.5,None,None],[21,.5,239.0,None,None],
 [21,1.6,246.5,None,253.0],
 [50,.2,224.0,None,None],[50,.5,216.0,202.0,230.0],[50,1.6,244.0,236.5,250.0],
 [75,.2,208.0,None,None],[75,.5,215.5,198.0,233.5],
 [75,1.6,255.2,243.5,267.0],
 [100,.2,176.5,162.0,189.0],[100,.5,204.5,190.0,218.5],
 [100,1.6,277.5,269.0,286.0],
 [150,.2,197.0,184.0,210.0],[150,.5,223.5,211.5,236.0],
 [250,.2,166.5,142.0,191.0],[250,.5,235.0,218.0,252.0],
 [500,1.6,327.0,None,None],
]

CALIB = {
 '5a': {'native_image':'image_0.png','width_px':573,'height_px':472,
        'y_K0_px':409.0,'y_K20_px':60.0,'x_T0C_px':204.8,'x_T100C_px':313.4,
        'x_axis_break':False},
 '5b': {'native_image':'image_1.png','width_px':518,'height_px':472,
        'y_K0_px':408.0,'y_K20_px':63.0,'x_T0C_px':173.8,'x_T100C_px':258.5,
        'x_T500C_px':475.0,'x_axis_break':True,
        'axis_break_note':'Use left linear segment through 250 C; isolated 500 C marker on right segment. Temperatures are prescribed from paper/Table 1, not inferred across axis break.'},
}
COLORS = {.05:(106,56,155),.2:(254,164,73),.5:(23,122,180),1.6:(48,164,40)}

def kval(panel,y):
    c=CALIB[panel]
    return None if y is None else round((c['y_K0_px']-y)*20/(c['y_K0_px']-c['y_K20_px']),4)

def xpos(panel,t):
    c=CALIB[panel]
    if t==500:return c['x_T500C_px']
    return c['x_T0C_px']+t*(c['x_T100C_px']-c['x_T0C_px'])/100

def write_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    HERE.mkdir(exist_ok=True)
    d=fitz.open(PDF)
    for i,im in enumerate(d[15].get_images()):
        (HERE/f'image_{i}.png').write_bytes(d.extract_image(im[0])['image'])
    tab=json.loads(TABLE.read_text())
    idx={(r['temperature_C'],r['initial_elastic_Kdot_MPa_sqrt_m_per_s']):r for r in tab}
    out=[]
    for panel,rows,disposition in [('5a',FILLED_A,'cleavage'),('5a',OPEN_A,'no_cleavage'),('5b',POINTS_B,'onset')]:
      for t,rate,y,yup,ydown in rows:
        tr=idx[(t,rate)]
        if panel=='5a' and disposition=='cleavage':
            col='Kq_LEFM_MPa_sqrt_m' if tr['Kq_LEFM_MPa_sqrt_m'] is not None else 'Kq_Jbasic_cleavage_MPa_sqrt_m'
            quantity='conditional_cleavage_Kq';marker='filled';mean=tr[col]
            status='cleavage_observed_in_subgroup';source='Table1_mean_with_Fig5a_digitized_minmax'
        elif panel=='5a':
            col=None;mean=None;quantity='maximum_nominal_K_no_cleavage';marker='open'
            status='no_cleavage_at_observed_endpoint';source='Fig5a_native_image_digitization'
        else:
            if tr['Kq_Jcontinuous_onset_MPa_sqrt_m'] is not None:
                col='Kq_Jcontinuous_onset_MPa_sqrt_m';marker='open';quantity='conditional_onset_Kq_at_0p2um';status='stable_extension_onset_criterion'
            elif tr['Kq_LEFM_MPa_sqrt_m'] is not None:
                col='Kq_LEFM_MPa_sqrt_m';marker='filled';quantity='early_cleavage_fallback_Kq';status='early_cleavage_LEFM_fallback'
            else:
                col='Kq_Jbasic_cleavage_MPa_sqrt_m';marker='filled';quantity='early_cleavage_fallback_Kq';status='early_cleavage_Jbasic_fallback'
            mean=tr[col];source='Table1_mean_with_Fig5b_digitized_minmax'
        digit=kval(panel,y)
        notes=[]
        conflict=panel=='5b' and rate==1.6 and t in [75,100]
        if conflict:notes.append('MATERIAL_TABLE_FIGURE_DISCREPANCY: Table 1 mean differs from Fig 5b marker by more than image resolution; preserve both and fit sensitivity alternatives. Do not pair tabulated mean with plotted error bars as one consistent observation.')
        if panel=='5b' and rate==.05 and t==21:
            notes.append('Table 1 reports 11.2; corresponding purple marker is not separately recoverable in Fig 5b. Do not infer a figure value from overlapping orange point.')
        if panel=='5a' and disposition=='no_cleavage':
            notes.append('Right axis maximum nominal elastic-formula K. Not J-equivalent fracture toughness; do not use as a censor threshold in the left-axis Kq variable without the experimental observation mapping.')
        if panel=='5a' and (t,rate) in [(21,.2),(50,.5),(75,1.6)]:
            notes.append('Same condition has cleavage and non-cleavage subgroups in Fig 5a; subgroup sizes not reported.')
        if yup is None and ydown is None:eb='not_separately_resolvable_or_not_visible'
        elif yup is None or ydown is None:eb='partly_resolved'
        else:eb='both_endpoints_resolved'
        if y is None:quality='table_only_marker_not_resolved'
        elif conflict:quality='table_figure_discrepancy'
        else:quality='resolved_at_native_image_precision'
        pxerr=1.5
        out.append({
          'observation_id':f'fig{panel}_{tr["condition_id"]}_{disposition}',
          'curve_id':f'fig{panel}_rate{str(rate).replace(".","p")}_{disposition}',
          'condition_id':tr['condition_id'],'figure':panel,'pdf_page':16,'printed_page':15,
          'temperature_C':t,'temperature_K':tr['temperature_K'],'initial_elastic_Kdot_MPa_sqrt_m_per_s':rate,
          'quantity':quantity,'marker_fill':marker,'event_status':status,
          'K_table_MPa_sqrt_m':mean,'K_digitized_MPa_sqrt_m':digit,
          'K_preferred_MPa_sqrt_m':mean if mean is not None else digit,
          'K_min_digitized_MPa_sqrt_m':kval(panel,ydown),
          'K_max_digitized_MPa_sqrt_m':kval(panel,yup),
          'error_bar_meaning':'observed specimen minimum and maximum; not SD/SEM/CI',
          'error_bar_visibility':eb,
          'digitized_minus_table_MPa_sqrt_m':None if digit is None or mean is None else round(digit-mean,4),
          'pixel_x':round(xpos(panel,t),2),'pixel_y':y,
          'pixel_y_upper_error':yup,'pixel_y_lower_error':ydown,
          'coordinate_reading_uncertainty_px':pxerr if y is not None else None,
          'digitization_resolution_K_per_px':round(20/(CALIB[panel]['y_K0_px']-CALIB[panel]['y_K20_px']),6),
          'coordinate_reading_halfwidth_K_MPa_sqrt_m':round(pxerr*20/(CALIB[panel]['y_K0_px']-CALIB[panel]['y_K20_px']),4) if y is not None else None,
          'n_tests_condition_total':tr['n_tests_condition_total'],'n_tests_observable':None,
          'table1_field':col,'source_type':source,'digitization_status':quality,
          'material_table_figure_discrepancy':conflict,
          'independence_group':tr['condition_id'],
          'table_duplicate':mean is not None,'source_doi':DOI,'notes':' '.join(notes),
        })
    write_csv(HERE/'fig5_observations.csv',out)
    (HERE/'fig5_observations.json').write_text(json.dumps(out,indent=2)+'\n')
    for panel in ['5a','5b']:
      im=Image.open(HERE/CALIB[panel]['native_image']).convert('RGB')
      dr=ImageDraw.Draw(im)
      for j,r in enumerate([q for q in out if q['figure']==panel]):
        x,y=r['pixel_x'],r['pixel_y']
        if y is None:continue
        # Magenta cross for manually read center, cyan bars for extracted extents.
        dr.line([(x-2,y),(x+2,y)],fill=(210,0,120),width=1)
        dr.line([(x,y-2),(x,y+2)],fill=(210,0,120),width=1)
        for yy in [r['pixel_y_upper_error'],r['pixel_y_lower_error']]:
          if yy is not None:dr.line([(x-5,yy),(x+5,yy)],fill=(0,160,160),width=1)
        if r['material_table_figure_discrepancy']:
          dr.rectangle((x-9,y-10,x+9,y+8),outline=(210,0,120),width=1)
      im.resize((im.width*3,im.height*3)).save(HERE/f'fig{panel}_overlay.png')
    metadata={
      'source_doi':DOI,'source_pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),
      'method':'Manual native-pixel coordinate reading; linear axis calibration; exact tabulated means preserved separately. No guide lines digitized as observations.',
      'calibrations':CALIB,
      'counts':{'fig5a_observations':27,'fig5a_cleavage':19,'fig5a_no_cleavage_nominal_Kmax':8,'fig5b_conditions':31,'fig5b_marker_centers_recoverable':30,'total_rows':58},
      'coordinate_uncertainty':'Conservative +/-1.5 native pixels for recoverable mean/endpoint coordinates (about +/-0.086 MPa sqrt(m)); not a statistical confidence interval. Temperature/rate labels are from paper conditions, not digitized estimates.',
      'error_bars':'Authors describe max-to-min specimen spread; unresolvable intervals remain null, not zero. Shared source conditions and transformations cause correlations; this is not 58 independent tests.',
      'conflicts':[
        {'figure':'5b','temperature_C':75,'rate':1.6,'table_K':7.6,'digitized_K':kval('5b',255.2),'action':'retain both; sensitivity alternatives; do not combine table mean with plot error bars'},
        {'figure':'5b','temperature_C':100,'rate':1.6,'table_K':5.8,'digitized_K':kval('5b',277.5),'action':'retain both; sensitivity alternatives; do not combine table mean with plot error bars'},
        {'figure':'5b','temperature_C':21,'rate':.05,'table_K':11.2,'digitized_K':None,'action':'table retained; independent plotted marker not resolved'},
      ],
      'new_information_beyond_table1':'Eight maximum nominal K endpoints with no cleavage, mixed disposition of three conditions, recoverable min/max ranges, and two clear table/figure discrepancies.',
      'no_cleavage_observation_warning':'Fig5a right-axis nominal Kmax values and left-axis J-equivalent cleavage Kq values are mechanically different observables despite shared units. Open symbols are not low fracture toughness measurements.',
      'files':{'observations_csv':'fig5_observations.csv','observations_json':'fig5_observations.json','script':'extract_fig5.py','overlays':['fig5a_overlay.png','fig5b_overlay.png']},
    }
    (HERE/'fig5_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps(metadata['counts']))
    print('Conflicts:',json.dumps(metadata['conflicts']))

if __name__=='__main__':main()
