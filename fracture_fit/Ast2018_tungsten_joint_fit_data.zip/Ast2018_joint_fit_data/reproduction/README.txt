REPRODUCING THE EXTRACTION
Python dependencies are listed in requirements.txt. Run from this directory:

python fetch_source.py
python metadata_agent/build_table_metadata.py
python fig2_agent/digitize_fig2.py
python digitize_fig3.py
python fig5_agent/extract_fig5.py
python metadata_agent/appendix_A2/digitize_A2.py

If included: python fig3/digitize_example_onsets.py
Then: python prepare_delivery.py

This regenerates the figure coordinates, tables, provenance, and the data package.
The source URL is public; network access is needed only to fetch the manuscript.
The table values and Figure5 coordinates are explicit audited transcriptions;
running the scripts reproduces those choices rather than discovering new data.
The black Figure3 fits are excluded from experimental trace data. Optional onset
readouts from those fits are separately labelled derived summaries.

Spreadsheet authoring is separate: the supplied JS workbook script requires
@oai/artifact-tool and its documented runtime. CSV and JSON data do not require it.
No fitting or material simulation is executed by these scripts.

Workbook regeneration after Python extraction/assembly:
node workbook_agent/build_ast_workbook.mjs .
