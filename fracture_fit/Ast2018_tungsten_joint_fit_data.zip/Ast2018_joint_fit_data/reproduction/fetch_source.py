"""Fetch and verify the exact accepted manuscript used in this extraction."""
from pathlib import Path
import hashlib, urllib.request
URL = 'https://www.dora.lib4ri.ch/empa/dload/empa%3A17075/PDF2/Ast-2018-The_brittle-ductile_transition_of_tungsten-%28accepted_version%29.pdf'
EXPECTED = '7932cab933aebfe75472a35e2b0f9187c9fb96eb26ffe0bb0645f134e6de1130'
ROOT = Path(__file__).resolve().parent
target = ROOT / 'source' / 'Ast_2018_accepted.pdf'
target.parent.mkdir(exist_ok=True)
if target.exists():
    payload = target.read_bytes()
else:
    with urllib.request.urlopen(URL, timeout=90) as response:
        payload = response.read()
digest = hashlib.sha256(payload).hexdigest()
if digest != EXPECTED:
    raise RuntimeError('Source version mismatch: expected '+EXPECTED+'; received '+digest)
target.write_bytes(payload)
print('Verified source:', target)
