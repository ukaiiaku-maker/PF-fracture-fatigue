"""Recover the visible coloured experimental traces in Ast et al. (2018), Fig. 3.

Run from any directory. Source PDF is deliberately not redistributed; fetch the
open accepted manuscript using the URL in SOURCE.json. No constitutive fitting,
curve smoothing, or artificial monotonicity is applied. The raster cannot recover
the authors' original sampling times. Point order is increasing J (b-d), or
increasing displacement (a), rather than a claim of original temporal order.
"""
from pathlib import Path
import csv, json, hashlib
import numpy as np
from PIL import Image, ImageDraw
import fitz

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "fig3"
OUT.mkdir(exist_ok=True)
PDF = ROOT / "source" / "Ast_2018_accepted.pdf"
COLORS = {"green":(0,221,0),"orange":(230,172,40),"red":(254,56,56)}
PANELS = {
 "a":dict(image_index=0,x0=103.5,x1=484.5,x_value1=3000.0,y0=358.0,y1=33.5,y_value1=1.0,
          box=(104,2,548,357),rate=0.2,series=[("green",21),("orange",100),("red",250)]),
 "b":dict(image_index=1,x0=153.5,x1=530.0,x_value1=1600.0,y0=358.0,y1=18.0,y_value1=1250.0,
          box=(107,19,530,357),rate=0.2,series=[("green",21),("orange",100),("red",250)]),
 "c":dict(image_index=2,x0=153.5,x1=530.0,x_value1=1600.0,y0=358.0,y1=18.0,y_value1=1250.0,
          box=(107,19,530,357),rate=0.5,series=[("green",21),("orange",100),("red",250)]),
 "d":dict(image_index=3,x0=122.0,x1=514.5,x_value1=2500.0,y0=358.0,y1=18.0,y_value1=600.0,
          box=(91,19,514,357),rate=1.6,series=[("orange",100),("red",500)]),
}

def dump_csv(path, rows):
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def mask_color(a, color):
    # Include antialiased mixtures with white, exclude low-saturation pixels.
    base=255-np.array(color,dtype=float)
    v=255-a.astype(float)
    alpha=np.sum(v*base,axis=2)/np.dot(base,base)
    residual=np.linalg.norm(v-alpha[:,:,None]*base,axis=2)
    return (alpha>0.38)&(alpha<1.15)&(residual<16)

def main():
    doc=fitz.open(PDF); page=doc[12]
    metadata=[]; jrows=[]; stiffness=[]
    for panel,s in PANELS.items():
        image=doc.extract_image(page.get_images(full=True)[s["image_index"]][0])
        ip=OUT/f"fig3{panel}_source.png"; ip.write_bytes(image["image"])
        im=Image.open(ip).convert("RGB"); a=np.asarray(im)
        over=im.copy().resize((im.width*2,im.height*2))
        draw=ImageDraw.Draw(over)
        sx=s["x_value1"]/(s["x1"]-s["x0"])
        sy=s["y_value1"]/(s["y0"]-s["y1"])
        for color,T in s["series"]:
            rgb=(254,0,0) if panel=="d" and color=="red" else COLORS[color]
            mask=mask_color(a,rgb)
            xmin,ymin,xmax,ymax=s["box"]
            roi=np.zeros(mask.shape,bool); roi[ymin:ymax+1,xmin:xmax+1]=True; mask &= roi
            cid=f"F3{panel}_T{T}_r{s['rate']:g}"
            ys,xs=np.where(mask)
            if not len(xs): raise ValueError(cid+" has no pixels")
            rows=[]
            # Three-pixel sampling retains the visual irregularity but avoids
            # presenting every antialiased pixel as an independent observation.
            sweep=range(int(xs.min()),int(xs.max())+1,3) if panel=="a" else range(int(ys.max()),int(ys.min())-1,-3)
            for q in sweep:
                if panel=="a":
                    yy,xx=np.where(mask[:,max(q-1,0):q+2]); xx=xx+max(q-1,0)
                else:
                    yy,xx=np.where(mask[max(q-1,0):q+2,:]); yy=yy+max(q-1,0)
                if len(xx)==0: continue
                px=float(np.median(xx)); py=float(np.median(yy))
                x=(px-s["x0"])*sx; y=(s["y0"]-py)*sy
                width=float(np.max(xx)-np.min(xx)); height=float(np.max(yy)-np.min(yy))
                common=dict(curve_id=cid,figure_panel="3"+panel,temperature_C=T,
                  loading_rate_MPa_sqrt_m_per_s=s["rate"],point_index=len(rows),
                  source_pdf_page=13,pixel_x=round(px,2),pixel_y=round(py,2))
                if panel=="a":
                    r={**common,"displacement_nm":round(x,2),"relative_stiffness":round(y,5),
                      "displacement_digitization_pm_nm":round(2*sx,2),
                      "stiffness_digitization_pm":round(max(2.,height/2)*sy,5)}
                else:
                    r={**common,"crack_extension_nm":round(x,2),"J_N_per_m":round(y,3),
                       "x_visible_min_nm":round((float(np.min(xx))-s["x0"])*sx,2),
                       "x_visible_max_nm":round((float(np.max(xx))-s["x0"])*sx,2),
                       "crack_extension_digitization_pm_nm":round(max(2.,width/2)*sx,2),
                       "J_digitization_pm_N_per_m":round(2*sy,3),
                       "wide_horizontal_segment":width>10,
                       "sample_for_fit":len(rows)%3==0}
                r.update(extraction="colour_trace_median_3px_bin",uncertainty_kind="raster_resolution_and_local_visible_span_not_experimental_error")
                rows.append(r)
                if len(rows)%3==1:
                    p=(px*2,py*2); draw.ellipse((p[0]-3,p[1]-3,p[0]+3,p[1]+3),fill="white",outline=(0,70,180),width=1)
            if panel=="a": stiffness.extend(rows)
            else: jrows.extend(rows)
            metadata.append(dict(curve_id=cid,temperature_C=T,loading_rate_MPa_sqrt_m_per_s=s["rate"],
                 figure_panel="3"+panel,pdf_page=13,manuscript_page=12,
                 source_image_width_px=im.width,source_image_height_px=im.height,
                 color=color,point_count=len(rows),
                 x_unit="nm",y_unit="relative_stiffness" if panel=="a" else "N/m",
                 x_calibration_nm_per_pixel=sx,y_calibration_units_per_pixel=sy,
                 calibration={k:s[k] for k in ["x0","x1","x_value1","y0","y1","y_value1"]},
                 original_sampling_times_available=False,
                 ordering="increasing_displacement" if panel=="a" else "increasing_J_raster_sweep_not_recovered_time",
                 original_curve_raw_machine_data=False,
                 source_sha256=hashlib.sha256(PDF.read_bytes()).hexdigest(),
                 black_power_law_fit_excluded=True,
                 approximate_source_pixel_uncertainty=2,
                 displayed_curve_truncated_by_plot_boundary=True if panel=="c" and T==21 else None,
                 end_status=("reaches_right_plot_border" if panel=="c" and T==21 else
                             "near_upper_plot_limit_original_endpoint_unknown" if panel=="d" and T==100 else
                             "visible_trace_endpoint_original_test_endpoint_not_established"),
                 notes=("Negative measured crack-extension estimates retained. Trace remains unsmoothed; horizontal visible spans are saved. "
                        "Condition-level onset values are in Table1; these are representative individual curves with no specimen IDs. "
                        "The displayed black power-law fits and 200 nm criterion are derived summaries, not extra experimental observations.") if panel!="a" else
                       "Relative stiffness of representative specimens also shown in Fig3b and Fig2a. Horizontal loading curves overlap near origin."))
        over.save(OUT/f"fig3{panel}_digitization_overlay.png")
    dump_csv(OUT/"J_R_curves.csv",jrows); dump_csv(OUT/"relative_stiffness.csv",stiffness)
    (OUT/"curve_metadata.json").write_text(json.dumps(metadata,indent=2))
    print(json.dumps({"J_curves":len({r['curve_id'] for r in jrows}),"J_points":len(jrows),
      "stiffness_curves":len({r['curve_id'] for r in stiffness}),"stiffness_points":len(stiffness)},indent=2))

if __name__=="__main__": main()
