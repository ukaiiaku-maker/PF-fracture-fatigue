from pathlib import Path
import csv
import json
import math
import hashlib

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'source' / 'Ast_2018_accepted.pdf'
DOI = '10.1016/j.matdes.2018.04.009'

# Manual transcription of Table 1, independently verified against the rendered
# accepted-manuscript PDF page 10 (printed page 9). A None is a published dash.
source_rows = [
    (-90,415,.28,[.05,.2],[5,3],[3.2,3.4],[None,None],[None,None]),
    (-75,414,.28,[.05,.2],[4,2],[3.2,3.5],[None,None],[None,None]),
    (-55,414,.28,[.05,.2],[3,2],[3.4,3.6],[None,None],[None,None]),
    (-25,413,.28,[.05,.2,.5],[2,2,2],[None]*3,[6.6,5.2,4.6],[5.6,None,None]),
    (0,412,.28,[.05,.2,.5,1.6],[2]*4,[None]*4,[11.7,9.5,8.4,7.1],[7.8,8.8,8.0,8.7]),
    (21,411,.28,[.05,.2,.5,1.6],[2,4,2,2],[None]*4,[None,11.7,10.2,8.7],[11.2,10.5,9.8,9.4]),
    (50,409,.28,[.2,.5,1.6],[2,3,2],[None]*3,[None,13.5,10.1],[10.7,11.1,9.5]),
    (75,408,.28,[.2,.5,1.6],[2,2,3],[None]*3,[None,None,14.6],[11.6,11.2,7.6]),
    (100,407,.28,[.2,.5,1.6],[2]*3,[None]*3,[None]*3,[13.5,11.8,5.8]),
    (150,404,.28,[.2,.5],[2,2],[None]*2,[None]*2,[12.3,10.7]),
    (250,399,.27,[.2,.5],[2,2],[None]*2,[None]*2,[14.0,10.1]),
    (500,385,.26,[1.6],[2],[None],[None],[4.7]),
]

records=[]
measurements=[]
for temp,E,nu,rates,ns,lefm,jbasic,jcont in source_rows:
    assert len(rates)==len(ns)==len(lefm)==len(jbasic)==len(jcont)
    for rate,n,k_l,k_b,k_c in zip(rates,ns,lefm,jbasic,jcont):
        cond=f'T{temp:+d}C_rate{rate:g}'.replace('+','p').replace('-','m').replace('.','p')
        r=dict(condition_id=cond,temperature_C=temp,temperature_K=round(temp+273.15,2),
               young_modulus_GPa=E,poisson_ratio=nu,initial_elastic_Kdot_MPa_sqrt_m_per_s=rate,
               n_tests_condition_total=n,Kq_LEFM_MPa_sqrt_m=k_l,
               Kq_Jbasic_cleavage_MPa_sqrt_m=k_b,Kq_Jcontinuous_onset_MPa_sqrt_m=k_c,
               onset_crack_extension_um=.2,source='Table 1',pdf_page=10,printed_page=9,
               published_precision_K_MPa_sqrt_m=.1,source_doi=DOI,
               missing_value_meaning='published dash; unavailable for that evaluation; not zero; not automatically a no-cleavage outcome',
               n_count_scope='all tests in condition; per-observable sample counts not given')
        records.append(r)
        for obs,val in [('Kq_LEFM',k_l),('Kq_Jbasic_cleavage',k_b),('Kq_Jcontinuous_onset',k_c)]:
            if val is not None:
                measurements.append(dict(measurement_id=f'{cond}_{obs}',condition_id=cond,
                  temperature_C=temp,temperature_K=round(temp+273.15,2),
                  initial_elastic_Kdot_MPa_sqrt_m_per_s=rate,observable=obs,
                  value=val,unit='MPa sqrt(m)',n_tests_condition_total=n,
                  n_tests_measurement=None,source='Table 1',pdf_page=10,printed_page=9,
                  dependency_group=f'Table1_Fig5_{cond}',extraction_method='direct numerical transcription'))

def save_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

save_csv(OUT/'table1.csv',records)
save_csv(OUT/'table1_measurements_long.csv',measurements)
(OUT/'table1.json').write_text(json.dumps(records,indent=2)+'\n')

transitions=[]
for rate,temp in [(.05,0),(.2,21),(.5,50),(1.6,75)]:
    transitions.append(dict(transition_id=f'BDT_rate{rate:g}',
      initial_elastic_Kdot_MPa_sqrt_m_per_s=rate,BDT_temperature_C=temp,
      BDT_temperature_K=round(temp+273.15,2),
      reciprocal_kBT_per_eV=1/(8.617333262145e-5*(temp+273.15)),
      source='Fig. 5(a) dashed transition lines and Fig. 8(b) this-work diamonds',
      pdf_pages='16;21',printed_pages='15;20',
      extraction_method='visual figure coordinates mapped to published experimental temperature grid',
      independently_measured=False,
      qualification='Derived transition classification; Fig8 repeats Fig5 transition temperatures. Lowest-rate transition less clearly localized in authors text.',
      include_with_full_K_temperature_data_as_independent_target=False))
save_csv(OUT/'bdt_transitions.csv',transitions)

metadata={
 'source':{'title':'The brittle-ductile transition of tungsten single crystals at the micro-scale',
  'authors':['J. Ast','J.J. Schwiedrzik','J. Wehrs','D. Frey','M.N. Polyakov','J. Michler','X. Maeder'],
  'journal':'Materials & Design','year':2018,'volume':152,'pages':'168-180','doi':DOI,
  'version':'accepted manuscript','pdf_page_count':35,
  'source_url':'https://www.dora.lib4ri.ch/empa/dload/empa:17075/PDF2/Ast-2018-The_brittle-ductile_transition_of_tungsten-(accepted_version).pdf',
  'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
  'page_convention':'pdf_page is one-based file page; printed page is pdf_page-1 for manuscript body'},
 'table1':{'conditions':len(records),'temperatures_C':[r[0] for r in source_rows],
  'distinct_initial_elastic_Kdot_MPa_sqrt_m_per_s':[.05,.2,.5,1.6],
  'n_tests_all_conditions':sum(r['n_tests_condition_total'] for r in records),
  'reported_LEFM_count':sum(r['Kq_LEFM_MPa_sqrt_m'] is not None for r in records),
  'reported_Jbasic_count':sum(r['Kq_Jbasic_cleavage_MPa_sqrt_m'] is not None for r in records),
  'reported_Jcontinuous_count':sum(r['Kq_Jcontinuous_onset_MPa_sqrt_m'] is not None for r in records),
  'nonmissing_measurements_count':len(measurements),
  'missing_policy':'Preserve source dashes as null/blank. Missing evaluation is not a measured zero and does not by itself establish a censoring disposition.',
  'counts_policy':'Number of tests is for the full T/rate condition. Do not assume it equals the sample count for every displayed toughness statistic.',
  'uncertainty_policy':'Table 1 supplies means/representative condition values at displayed precision; no numerical standard deviations. Figure 5 error bars show minimum-to-maximum spans, not standard errors or confidence intervals.',
  'source_pdf_page':10,'source_printed_page':9},
 'specimen':{'material':'single-crystal tungsten','crack_plane':'(100)','crack_propagation_direction':'[001]',
  'nominal_length_um':15,'nominal_width_B_um':4,'nominal_height_W_um':6,
  'loading_span_L_um_range':[11,14],'initial_notch_length_a0_um_range':[2,2.5],
  'notch_radius_nm':None,'notch_description':'FIB-machined notch; not atomically sharp; radius not specified in this paper',
  'crack_plane_possible_misalignment_degrees':2,
  'FIB_accelerating_voltage_kV':30,'FIB_coarse_current_nA':10,'FIB_final_notch_current_nA':.3,
  'source_pdf_pages':[4,5,21]},
 'loading':{'control':'displacement control','displacement_rate_nm_per_s_range':[5,150],
  'superposed_stiffness_probe_displacement_amplitude_nm':5,'probe_frequency_Hz':None,
  'effective_Kdot_definition':'Slope of nominal KI(t), based on specimen normalization, during initial linear-elastic segment only',
  'constant_Kdot_after_plasticity':False,
  'warning':'Do not simulate all tests as constant-K ramps through developed plasticity; the experiments impose displacement rate and the nominal K rate drops.',
  'A2_example':{'temperature_label':'room temperature','displacement_rate_nm_per_s':150,
    'initial_elastic_Kdot_MPa_sqrt_m_per_s':1.6,'plasticity_sets_in_approximately_s':2,
    'author_described_outcome':'specimen ultimately failed by final cleavage, per Fig. A2 caption',
    'event_time_s':None,'displayed_endpoint_event_localized':False,
    'endpoint_note':'No visible failure drop or separate post-cleavage branch in the plotted black trace; do not identify the extracted last point as the exact cleavage event.',
    'pdf_page':33,'printed_page':32},
  'source_pdf_pages':[5,6,7,33]},
 'environment':{'in_situ_SEM':True,'instrument':'Zeiss DSM962 SEM with two Alemnis nanoindentation platforms',
  'atmosphere':'high vacuum','subambient_pressure_mbar_upper_bound':1e-5,
  'elevated_temperature_environment':'high vacuum SEM chamber to limit oxidation; separate numerical pressure not specified',
  'source_pdf_pages':[5,6]},
 'measurement':{'quantity_name':'conditional fracture toughness K_Iq, not fully size-qualified K_Ic',
  'LEFM':{'definition':'Fq from 95% construction line against initial linear loading; Fq=max load for purely linear response; use initial crack length a0',
    'formula':'K_Iq = Fq L / (B W^(3/2)) * f(a0/W)','source_equation':1},
  'geometry_factor':{'formula':'f(x) = 1.24 + 28.08*x - 59.44*x^2 + 90.40*x^3',
    'x':'a/W','source_equation':2,
    'scope':'3-D elastic FE geometry calibration, averaged over inner 75% of crack front'},
  'Jbasic':{'definition':'Basic elastic-plastic J evaluated at onset of final unstable cleavage; includes preceding plastic work',
    'formula':'J = K_Iq^2*(1-nu^2)/E + eta*A_pl/[B*(W-a)]','eta':2,'source_equation':3},
  'Jcontinuous':{'definition':'Continuous J resistance curve accounting for evolving crack length; Jq evaluated at Delta a=0.2 um to define fracture-initiation toughness',
    'increment_formula':'J_i = K_Iq,i^2*(1-nu^2)/E + [Jpl_(i-1) + eta*(Apl_i-Apl_(i-1))/(B*(W-a_(i-1)))]*[1-(a_i-a_(i-1))/(W-a_(i-1))]',
    'source_equations':[4,5], 'initiation_extension_um':.2,
    'extension_definition':'Delta a is crack extension from initial notch length; not total a',
    'J_to_K_formula':'K_Iq,J = sqrt(Jq*E/(1-nu^2))','source_conversion_equation':6,
    'J_units_in_Fig3':'N/m (equivalent to J/m^2)',
    'K_MPa_sqrt_m_to_J_N_per_m':'J = 1000*K^2*(1-nu^2)/E_GPa',
    'derived_J_of_mean_K_caveat':'Transforming a published mean K gives J of that mean, not necessarily mean J because the transformation is nonlinear.'},
  'source_pdf_pages':[7,8,9,10,13,14]},
 'figure_relationships':[
  {'figure':'Fig. 2(a-c)','observable':'nominal KI versus indenter displacement','caution':'Uses LEFM expression and initial crack length to normalize force; crack advance is not accounted for in these plots. Do not equate ordinate to J-equivalent toughness after plasticity. Cross markers indicate final cleavage; they are not first yield.', 'source_pdf_pages':[10,11,12]},
  {'figure':'Fig. 3(a)','observable':'normalized stiffness versus indenter displacement','dependency':'Three specimens from Fig. 2(a); stiffness supports inferred crack growth','source_pdf_pages':[13]},
  {'figure':'Fig. 3(b)','observable':'continuous J versus Delta a at rate 0.2','dependency':'Same three tests as Fig. 3(a), hence Fig. 2(a); data scatter and fitted trend are not independent observations','source_pdf_pages':[13,14]},
  {'figure':'Fig. 3(c,d)','observable':'continuous J versus Delta a at rates 0.5 and 1.6','dependency':'Selected example specimens; table/figure5 condition means may average additional specimens','source_pdf_pages':[13,14]},
  {'figure':'Fig. 5(a)','observable':'cleavage toughness or maximum nominal KI in absence of final cleavage',
    'filled_symbols':'LEFM or J-basic cleavage toughness','open_symbols':'maximum nominal stress intensity factor for specimens without final cleavage',
    'censoring_caution':'No-cleavage maximum nominal K is not a directly interchangeable lower bound on J-equivalent cleavage toughness; preserve observable and outcome separately.',
    'dependency':'Table 1 reported cleavage values and Fig5(a) filled points overlap. Additional open markers are not numerical Table1 J-basic entries.',
    'error_bars':'minimum-to-maximum span', 'source_pdf_pages':[15,16]},
  {'figure':'Fig. 5(b)','observable':'fracture initiation toughness at Delta a=0.2 um, with early-cleavage substitutions',
    'open_symbols':'continuous-J initiation values','filled_symbols':'LEFM/basic J values where continuous-J approach could not be applied',
    'dependency':'Table1 Jcontinuous values and Fig5(b) overlap; early-cleavage fallback duplicates other Table1 toughness values.',
    'source_pdf_pages':[16,17]},
  {'figure':'Fig. 8(a)','observable':'microscale and literature macroscale cleavage comparison',
    'dependency':'This-work 0.2-rate data repeat Fig5(a); other symbols are imported literature and not new Ast experiments',
    'caution':'Figure caption attributes one macroscale series to Gumbsch et al [14]; preceding body text mentions Riedle et al [13]. Recover original sources before mixing these with Ast measurements.',
    'source_pdf_pages':[20,21]},
  {'figure':'Fig. 8(b)','observable':'Arrhenius plot of loading rate versus inverse BDT temperature',
    'dependency':'Transition temperatures are derived from Fig5(a), not additional independent toughness measurements',
    'reported_UBDT_eV':.36,'source_pdf_pages':[21,22]},
  {'figure':'Figs. 6,7,9','observable':'post-mortem microscopy and GND maps',
    'caution':'Qualitative/field constraints; measured GND density is a lower bound, not total dislocation density.',
    'source_pdf_pages':[9,17,20,23,24]}
 ],
 'fitting_guidance':[
  'Use one physical material parameterization across matched temperatures and rates; retain condition-specific experimental inputs.',
  'Use Table1 numerical values for summary central values; figure digitization adds bounds, no-cleavage maxima and curve shapes.',
  'Group by original observation/specimen or condition so Table1 and figure replicas do not multiply statistical weight.',
  'Do not count interpolated/densified curve points as additional independent measurements.',
  'Keep the authors R-curve fits separate from the measured point clouds.',
  'Record nominal K, J-equivalent K, and initiation/final-cleavage definitions explicitly.',
  'For uncertainty use experimental scatter and digitization uncertainty separately; min/max bars cannot be treated as one-sigma errors.',
  'A no-cleavage observation is a survival/outcome record under displacement-controlled loading, not a finite measured cleavage toughness.',
  'Per-specimen dimensions, rate mapping, raw histories, and subgroup counts are not all supplied; preserve their absence.'
 ]
}
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
(OUT/'interpretation_note.txt').write_text('''Ast 2018 extraction notes
=========================
Table 1 contains 31 T/rate conditions spanning 12 temperatures and 73 tests in total. There are 6 LEFM, 13 J-basic cleavage, and 23 continuous-J initiation values, 42 nonmissing summary measurements. Test counts are total per condition, not proven per-observable sample counts.

All table central values were visually verified against PDF p10 (printed p9). Original printed precision is 0.1 MPa sqrt(m). Source dashes stay empty/null and must not be turned into zero or automatically classified as no-fracture outcomes.

The experiments are displacement controlled. Nominal Kdot of 0.05, 0.2, 0.5, and 1.6 MPa sqrt(m)/s describes the initial elastic segment only. The nominal K rate drops after plasticity. Appendix Fig A2 illustrates this directly. Exact displacement-rate mapping for every condition is not tabulated.

The physical fitting observations have different definitions. Fig2 plots nominal K from force and initial geometry. Table1 J-basic is J-equivalent toughness at final cleavage. J-continuous is J-equivalent toughness evaluated at Delta a=0.2 um, defining onset of stable crack growth. Delta a is extension, not absolute crack length. Fig5(a) open points are maximum nominal K without cleavage, whereas Fig5(b) open points are continuous-J onset values. These two sets of open symbols have different meanings.

Figure5 error bars span the minimum and maximum observed values. They are not standard deviations, standard errors, or confidence intervals. Near the transition, cleaved and non-cleaved specimens coexist. A no-cleavage maximum nominal K should not be inserted as a censored lower bound on J-equivalent K without a consistent observation model.

Table1 and Fig5 are correlated presentations of the same experiments. Fig3(b) and Fig3(a) use selected specimens from Fig2(a). Fig3 onset values underlie the initiation definition but selected specimen curves need not match a condition mean exactly. Fig8(a) repeats Ast 0.2-rate data from Fig5(a); its other curves are literature data. Fig8(b) repeats transition temperatures inferred from Fig5(a). Use dependency groups rather than treating every representation as fresh information.

The four this-work BDT points in Fig8(b) map to rates 0.05, 0.2, 0.5, 1.6 and temperatures 0,21,50,75 C. This is a graphical transition assignment using the experimental temperature grid. Authors explicitly state that the lowest-rate transition is less clearly detected. These are derived classification records, not independently measured K values.

Converting a published mean K to J with J=1000*K^2*(1-nu^2)/E_GPa is a derived transformation of that mean, not necessarily the mean of specimen-level J. Fitting full J curves and derived onset values requires a shared dependency treatment.

No numerical barrier fitting or solver simulation has been performed by this extraction script.
''')
print(json.dumps(metadata['table1'],indent=2))
