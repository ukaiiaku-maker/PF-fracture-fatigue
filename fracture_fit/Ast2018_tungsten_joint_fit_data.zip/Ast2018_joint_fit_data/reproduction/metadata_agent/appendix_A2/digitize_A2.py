"""Digitize the two independently plotted A2 traces, without differentiation."""
from pathlib import Path
import csv
import json
import hashlib
import os
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import label
os.environ.setdefault('MPLCONFIGDIR','/tmp/ast_A2_matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
SRC = ROOT / 'images' / 'p33_img0.png'
im = Image.open(SRC).convert('RGB')
rgb = np.asarray(im)
# Tick/frame centers, independently visually checked against the native image.
# Axis 1: time 0..5 s, nominal K 0..4 MPa sqrt(m).
# Axis 2: time 0..5 s, plotted rate -0.5..2 MPa sqrt(m)/s.
X0, X5, Y0, Y4 = 69.0,482.0,350.0,17.0
PX_PER_S=(X5-X0)/5
PX_PER_K=(Y0-Y4)/4
PX_PER_RATE=(Y0-Y4)/2.5
def time_of(x): return (x-X0)/PX_PER_S
def k_of(y): return (Y0-y)/PX_PER_K
def rate_of(y): return 2.0-(y-Y4)/PX_PER_RATE

black=rgb.max(axis=2)<90
black[:21]=False;black[349:]=False;black[:,:70]=False;black[:,471:]=False
labs,n=label(black)
areas=np.bincount(labs.ravel());areas[0]=0
black=labs==np.argmax(areas)
red=(rgb[:,:,0]>170)&(rgb[:,:,1]<120)&(rgb[:,:,2]<120)
red[:21]=False;red[349:]=False;red[:,:70]=False;red[:,471:]=False
# Remove the horizontal red annotation arrow, which is not a measured trace.
red[158:167,277:327]=False

def trace(mask,curve_id,observable,unit,inverse,split_vertical=False):
    records=[]
    for xlo in range(70,471,2):
        ys,xs=np.nonzero(mask[:,xlo:min(xlo+2,471)])
        if not len(xs): continue
        xs=xs+xlo
        # Keep separated red markers in the same x bin as separate observations;
        # never put an averaged point into the empty space between them.
        uniq=np.unique(ys)
        groups=np.split(uniq,np.flatnonzero(np.diff(uniq)>4)+1) if split_vertical else [uniq]
        for group in groups:
          use=np.isin(ys,group)
          xx=xs[use];yy=ys[use]
          # Median center of plotted pixels. No interpolation, smoothing,
          # derivative, or extrapolation is applied.
          x=float(np.median(xx));y=float(np.median(yy))
          values=[inverse(float(v)) for v in yy]
          records.append(dict(curve_id=curve_id,point_index=len(records)+1,
          time_s=round(time_of(x),6),value=round(inverse(y),6),unit=unit,
          raster_x_px=x,raster_y_px=y,
          time_coordinate_resolution_s=round(1/PX_PER_S,6),
          value_coordinate_resolution=round(abs(inverse(y+1)-inverse(y)),6),
          raster_bin_value_min=round(min(values),6),raster_bin_value_max=round(max(values),6),
          observable=observable,temperature_label='room temperature',
          temperature_C=None,displacement_rate_nm_per_s=150,
          initial_elastic_Kdot_MPa_sqrt_m_per_s=1.6,
          source_figure='A2',source_pdf_page=33,source_printed_page=32,
          history_stage='displayed history; no separate post-cleavage segment identified',
          dependency_group='Ast2018_A2_same_specimen',
          sampling_note='two-pixel raster-bin median; separated red marks retained; not independent original acquisition points'))
    return records

k=trace(black,'A2_nominal_K','nominal_KI','MPa sqrt(m)',k_of)
r=trace(red,'A2_plotted_Kdot','plotted_loading_rate','MPa sqrt(m)/s',rate_of,split_vertical=True)
def write_csv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write_csv('A2_nominal_K_vs_time.csv',k)
write_csv('A2_loading_rate_vs_time.csv',r)
write_csv('A2_all_traces_long.csv',k+r)
(OUT/'A2_all_traces.json').write_text(json.dumps(k+r,indent=2)+'\n')

overlay=im.copy().resize((im.width*3,im.height*3))
draw=ImageDraw.Draw(overlay)
for rows,color in [(k,(0,120,255)),(r,(0,160,90))]:
    for v in rows[::2]:
        x=3*v['raster_x_px'];y=3*v['raster_y_px']
        draw.ellipse((x-3,y-3,x+3,y+3),outline=color,width=1)
overlay.save(OUT/'A2_digitization_overlay.png')

fig,ax=plt.subplots(2,1,figsize=(6.2,6.5),sharex=False)
ax[0].plot([v['time_s'] for v in k],[v['value'] for v in k],color='black',lw=1.5)
ax[0].set_ylabel(r'Nominal $K_I$ (MPa $\sqrt{m}$)')
ax[0].set_xlabel('Time (s)');ax[0].set_xlim(0,5);ax[0].set_ylim(0,4)
ax[1].plot([v['time_s'] for v in r],[v['value'] for v in r],'.',color='#d62728',ms=3)
ax[1].set_ylabel(r'Plotted loading rate (MPa $\sqrt{m}$/s)')
ax[1].set_xlabel('Time (s)');ax[1].set_xlim(0,5);ax[1].set_ylim(-.5,2)
for a in ax:a.grid(False);a.tick_params(direction='in')
fig.tight_layout();fig.savefig(OUT/'A2_reconstructed.png',dpi=220);plt.close(fig)

metadata={
 'source_figure':'Appendix Fig. A2','pdf_page':33,'printed_page':32,
 'source_image_relative':'images/p33_img0.png','source_image_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
 'source_image_dimensions_px':[im.width,im.height],
 'temperature_label':'room temperature','exact_temperature_C':None,
 'temperature_note':'The caption says room temperature; 21 C is the room-temperature condition in Table 1, but is not repeated numerically in the A2 caption.',
 'loading_control':'displacement control','displacement_rate_nm_per_s':150,
 'initial_elastic_Kdot_MPa_sqrt_m_per_s':1.6,
 'axes':{'x':{'pixel_at_0_s':X0,'pixel_at_5_s':X5,'scale':'linear'},
   'left_y':{'pixel_at_0_MPa_sqrt_m':Y0,'pixel_at_4_MPa_sqrt_m':Y4,'scale':'linear'},
   'right_y':{'pixel_at_minus_0p5_MPa_sqrt_m_per_s':Y0,'pixel_at_2_MPa_sqrt_m_per_s':Y4,'scale':'linear'}},
 'curves':{'nominal_K':{'count':len(k),'color':'black','method':'largest connected black curve; two-pixel x-bin median'},
           'loading_rate':{'count':len(r),'color':'red','method':'red pixels; horizontal annotation arrow removed; two-pixel x-bin median with distinct vertical pixel groups retained separately'}},
 'sampling':'No interpolation, smoothing, extrapolation, or differentiation. Both printed traces independently digitized.',
 'uncertainty':'Coordinate resolution is one native pixel. Raster-bin value min/max describe visible pixel support, not experimental scatter or a confidence interval. Digitization cannot recover original acquisition noise or exact timestamps.',
 'event_handling':'Paper states specimen ultimately cleaves; plotted black trace has no visible failure drop or separate post-cleavage branch. No event time, exact pre-event limit, or post-event state is asserted.',
 'interpretation':'Nominal KI is based on Eq1 force/geometry normalization. The paper states LEFM loses validity after plasticity; displayed curve is not a J-equivalent K trajectory. Effective loading rate decreases after plasticity rather than remaining 1.6 throughout.',
 'dependency':'Black K and red rate share an experimental history and rate was derived by paper authors. They are correlated observation channels; do not treat both as independent data. This digitizer did not differentiate the black trace.',
 'excluded_annotations':[{'rectangle_px':[277,158,327,167],'reason':'red horizontal explanatory arrow'}],
 'source_doi':'10.1016/j.matdes.2018.04.009'
}
(OUT/'A2_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'K_points':len(k),'rate_points':len(r),'K_endpoint':k[-1],
 'rate_endpoint':r[-1]},indent=2))
